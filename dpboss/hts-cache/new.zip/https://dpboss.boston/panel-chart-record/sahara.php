<!DOCTYPE html>
<html amp lang="en-in"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<title>SAHARA Panel Chart Records| Online Panel Result</title> <meta name="description" content="On this page, you can get our most sophisticated, and cleanly-compiled SAHARA Panel Chart record to check all live results and historical data records."/>
<link rel="canonical" href="https://dpboss.boston/panel-chart-record/sahara.php">
<meta name="robots" content="follow, all">  	
<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "NewsArticle",
		"mainEntityOfPage":"https://dpboss.boston",
		"author": "dpboss.boston",
		"headline": "Open-source framework for publishing content",
		"datePublished": "2015-10-07T12:02:41Z",
		"dateModified":"2026-03-15T12:02:041Z",
		"image": [
			"logo.jpg"
		],
		"publisher": {
      "@type": "Organization",
      "name": "DPBOSS",
      "logo": {
        "@type": "ImageObject",
        "url": "https://dpboss.boston/logo.png"
      }
    }
	} 
</script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="shortcut icon" href="https://dpboss.boston/fav/favicon.ico">
<style amp-custom>
html{scroll-behavior:smooth}
body{background-color: #fc9;
text-align: center;
font-weight: 700;
padding: 0;
font-family: Helvetica,sans-serif;}
.logo {
background: #fc9;
padding: 0 10px;
display: block;
color: #fff8f8 ;
margin-bottom: 5px;
letter-spacing: 1px;
font-weight: 700;
border: 3px solid #ff0016;
border-radius: .75em;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);}
  .logo amp-img{width:220px;height:auto;padding:6px 0 0}
.button2{background-color:#a0d5ff;color:#220c82;padding:10px 30px;font-size:14px;margin: 0px 0px 5px 0px;border:2px solid #0000005c;font-weight:800;text-decoration: none;text-shadow:1px 1px #00bcd4;box-shadow:0 8px 10px 0 rgba(0,0,0,.2),0 6px 8px 0 rgba(0,0,0,.19);display:inline-block;transition:all .3s}.ad-div11{text-align:center;margin:0 0 10px}.chart-list{border:2px solid #eb008b;margin-bottom:2px;width:50%;margin:0 auto 10px;text-align:center;font-weight:600}.chart-list.ab1{border-color:#003c6c}.chart-list h4{color:#fff;padding:5px 10px 3px;font-size:24px;border-top-left-radius:7px;margin:0}.chart-list.ab1 h4{background-color:#024c88}.chart-list a{display:block;font-size:22px;padding:5px 7px 4px;text-decoration:none}.chart-list a:hover{text-decoration:none}.chart-list.ab1 a{border-bottom:2px solid #024c88;color:#003c6c}.chart-list a:hover{background-color:#fff;text-decoration:underline}@media only screen and (max-width:500px){.chart-list{width:95%}}footer{background-color:#fff;color:red;font-weight:bold;font-size:25px;text-decoration:none;border:4px groove purple;text-shadow:1px 1px gold;margin:3px}footer > div{border-bottom:2px solid #b2ddff;padding:10px 0;margin-bottom:10px}footer > div a{text-decoration:none}footer > div a:hover{text-decoration:none}footer .ftr-icon{text-decoration:none;font-size:35px;text-transform:uppercase;color:#007bff}footer p{margin:10px 0 10px;line-height:35px}footer p span{color:rgb(51,102,255)}
.panel.panel-info{border:1px solid #3f51b5;width:70%;margin:0 auto 0}.panel-heading h1{margin:0;padding:5px}table{border-collapse:collapse}table,th,td{border:1px solid #03a9f4a8}thead{background-color:#ffc107;text-shadow:1px 1px 2px #9a7400ab}tbody td{padding:5px 0;font-family:"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol"}@media only screen and (max-width:770px){.panel.panel-info{width:95%}}.r{color:red}tr td:nth-child(1){font-size:13px}tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23){border-right-width:0px;font-size:13px}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){border-left-width:0px;border-right-width:0px;font-size:23px}tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){border-left-width:0px;font-size:13px}@media only screen and (max-width:500px){.panel.panel-info{width:99%}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){font-size:14px}tr td:nth-child(1),tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23),tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){font-size:9px}th{font-size:11px}}thead tr th:nth-child(1){width:100px}@media only screen and (max-width:770px){tr td:nth-child(1){font-size:9px}tbody tr td:nth-child(3),tbody tr td:nth-child(6),tbody tr td:nth-child(9),tbody tr td:nth-child(12),tbody tr td:nth-child(15),tbody tr td:nth-child(18),tbody tr td:nth-child(21),tbody tr td:nth-child(24),tbody tr td:nth-child(27){border-left-width:0;border-right-width:0;font-size:16px}tbody tr td:nth-child(4),tbody tr td:nth-child(7),tbody tr td:nth-child(10),tbody tr td:nth-child(13),tbody tr td:nth-child(16),tbody tr td:nth-child(19),tbody tr td:nth-child(22),tbody tr td:nth-child(25),tbody tr td:nth-child(28){border-left-width:0;font-size:11px}tbody tr td:nth-child(2),tbody tr td:nth-child(5),tbody tr td:nth-child(8),tbody tr td:nth-child(11),tbody tr td:nth-child(14),tbody tr td:nth-child(17),tbody tr td:nth-child(20),tbody tr td:nth-child(23){border-right-width:0;font-size:11px}thead tr th:nth-child(1){width:55px}.panel.panel-info{width:99%}}
.css-11, .css-16, .css-22, .css-27, .css-33, .css-38, .css-44, .css-49, .css-50, .css-55, .css-61, .css-66, .css-72, .css-83, .css-88, .css-94, .css-99, .css-05, .css-00, .css-77, .css-star {
    color: red;
}
.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chart-00,.chat-05,.chat-50,.chat-16,.chat-61,.chat-27,.chat-72,.chat-38,.chat-83,.chat-49,.chat-94{color:red}

.chart-05,.chart-50,.chart-16,.chart-61,.chart-27,.chart-72,.chart-38,.chart-83,.chart-49,.chart-94{color:red}
@media only screen and (max-width:770px){.panel.panel-info{width:99%}}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
}

.nd td:nth-child(2), .nd td:nth-child(4), .nd td:nth-child(5), .nd td:nth-child(7), .nd td:nth-child(8), .nd td:nth-child(10), .nd td:nth-child(11), .nd td:nth-child(13), .nd td:nth-child(14), .nd td:nth-child(16), .nd td:nth-child(17), .nd td:nth-child(19), .nd td:nth-child(20), .nd td:nth-child(22), .nd td:nth-child(23), .nd td:nth-child(25), .nd td:nth-child(26), .nd td:nth-child(28), .nd td:nth-child(29) {
  writing-mode: vertical-rl;
  text-orientation: upright;
}

.para3 {
  background: linear-gradient(187deg,#fc9 50%,#ffc387 50%);
  border: 2px solid #ff0016;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
  border-style: outset;
  margin-bottom: 3px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
}

.chart-h1{
background: #ff00a2;;
padding: 5px 10px;
text-shadow: 1px 1px 2px #000;
display: block;
color: #fff8f8;
margin-bottom: 3px;
letter-spacing: 1px;
font-weight: 700;
border: 2px solid #fff;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1) , background 150ms cubic-bezier(0,0,.58,1);
font-size: 18px;
margin: 3px 0px;
}

h1{
color: #fff8f8;
}

.logo img {
  margin: 5px 0px;
}

h3{font-size: 16px;color:#fff; text-shadow: 0px 0px;margin: 0px;padding: 5px;}

.chart-result {
  margin: 6px 2px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
  border: 1px solid black;
}
.chart-result div {
  font-size: 22px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
}

.chart-result span {
  color: #880e4f;
  text-shadow: 1px 1px 2px #ffe2c6;
  font-size: 21px;
}

.chart-result a {
  border: 1px solid #e6e6e6;
  background: #522f92;
  color: #fff;
  padding: 5px 7px;
  font-size: 12px;
  margin: 2px 0 -1px;
  display: inline-block;
  transition: all .3s;
  cursor: pointer;
  text-shadow: none;
  text-decoration: none;
}
@media screen and (max-width: 400px) {
.logo img {height: 60px;width: auto;max-width: 100%;}
}

@media screen and (max-width: 300px) {
.logo img {height: 40px;width: auto;max-width: 100%;}
}


.footer-text-div p.faq-title {
  font-weight: 600;
}

.footer-text-div {
  max-width: 100%;
  text-align: center;
  margin: 2px;
  border: 2px solid purple;
  background: white;
  padding: 10px;
}

.small-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}

.footer-text-div p {
  font-weight: 500;
  font-size: 12px;
  padding: 0px;
  margin: 0px;
}

.faq-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}

.newptn p {
writing-mode: vertical-rl;
  text-orientation: upright;
  margin: 0px;
}
</style></head>
<body>
<div class="logo" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://dpboss.boston/">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhsAAABpCAMAAACkjBFsAAAAvVBMVEUAAADrAIz/AKDrAIwAAADuAJHrAI0AAADsAI0AAAAAAADrAI3rAIwAAADsAI33AJkAAADrAI3wAJEAAADtAI7rAI3sAI0AAADrAI0AAAAAAADsAI0AAADsAI70AJPuAI8AAADsAI3uAI8AAAAAAADsAI0AAAAAAAAAAADsAI0AAADsAI3sAI0AAAAAAAAAAADsAI4AAAAAAADrAI3sAI3tAI0AAADrAI3tAI4AAAAAAAAAAAAAAAAAAADsAIxr+UChAAAAPXRSTlMA+wX29h7xDeOBxNPq4aYMF9wRbj/KgC+31CCSYTcXJ6vAL+q3ZE8GQ3Q5sIrKlotGpHlrXE0mnFWd7VgIj72kFgAAEBFJREFUeNrs2k2rozAUBuB8kEwgQYmYEAgqClKKLgQtduX//1nT5CadKdyBWd+cZ9GWQ3e+5JyjIgAAAAAAAApyQwBAMsD/Ig1rD+udVDxQQjo7b1NPEChaCMa8OiOFUvQKMOVKm+U8JlYjUK6m3SsjOL7+wBi/PriSi90gHOWqH14Kiq9vcVm1NQwiRSLsqDT/Jhj0JZapPNsaxo4CDfOi6fUXnL6UHEctQm+h2k8NhKM4xI78IxkvMR5Yrl07WxOPFFW1DQJFIf2hP9uJck7HiLx+MULY00saDhHf1nD/oyj97DC+Msx1NT+suSKqD4ZQPd1daDnSDwSiUZKpCtHI+OhbxrzISfEdCeGYNQ3ryt5ANgrSzx8dZTkYuXWO5mPEtSQuMosKx4jrYBwtSHfyK8PCTzVC5JA4bSv07EgcMQ4TSsoyBIoRLnpCRxsHimHlOFXEkR6mMK9CwWxwcJTjLnG+paHtFBtI6yjOaQmVgO06FMQOe2w5VnElwg4xCP0ucC6tOQr1ZmioVDBxlOOdDb0OJC0u+djg1QMlZHKxaO7w1K0Qv5BNa4qqupSCh3wfGzNDCRm+EqPOAYEi3G67jL2Cmp2gqLc8ry2mrVHWV/F/3G0IFGJbvq65nT6aR0BPht6ak8aafKJ/IARGkZ+F3ePAMea3d+qnvhJ5NOit8TEbWO0EZcNvds50TU0YCsMQQFwAQVBxwW3ccUbEXVvv/7Kq4XCSYG3n6U/q96PPQBapefOdk5AZL9AACKIF+yjQ3q9q8yQSWEX5bhsajOpohXthVp88syE3EJhRIwwbEa1UCxphve4fGydPe+ORG1W9lWP48P59RiZDBbINh9/LIL0O3O9oKS2Lu8MYw05QlUjUoevewuP0cfSmIy8i1VGjM+nB1eM1G6juEa6WZimpm6SGExYeODirU987Vgpw9KNQtyb9Nxy5EZdFRsM0EzWOhHeXkQ9shCOAZWFAxaF1p0S+FY0k6twq77cuedIMj4AV0DYWQuQJ0lgzDJKaHl3PyHAeXTbqi0Vo3H+kO+tv48iftJAtYD2+oBZV5ISEoQfrG+HdvtHZV2s7MB3Ff//OQt5EpH0FB3shBAY4OMjY8I5gG1SGH/UeSx64dBbvlCNnIjVuTzSqCWwsjAQFOWGDTOrc2WPFOj1Y0FYy3LH2bzbyJRJYGFIsMZ/sr4Aa2Q+S9YxDWaH/KMmLF8K22ytb6a1cqXfCkOLsxIwhsBRIPOk6hURDA23jVrS0Gm3fUPB9/9s38iW2Jyr7fbFoP8Rw8Sipbg2FrVL8CRwOWykpLZ13MporcTlEcVXNHg9LUehoNKTcbsiGA2kr6XcYG7VvLJyb1/ja1J8L7Hk3dq/Lp/rLqxt357r0LzpM3e7Sfr6vz7uu253PpG9KX3bjafO/O25fwz1ReXgiIjb3IjkpWtXul3ufy0R9jwAbR5lno/szldoan109M1hnNSkbZCBwP6FVy/0hMS0HKnS2PkhParPPMsub2M7AVvpICstTsWA6hk4va2gC1xmlzz4fw4d8HRgtycNKqM3j+kPKlYIQQ0qoZbAZGqlNLKqPxMJhtlHf9gCgKITm1HeADdQl5ujQB1zJ2OYQaHEF5hzrb7jbamn2gg2scW5zhbHKddnkkBnwTdy/smGXuVvnGbJB5eaajUmFnRPN2Ea/ooBvGI/cYhQqaBuKFUCtKotJToMgG0wmMmC3xII2ooFjI3zjeku8XdZfsIFS0Y1mA7EAebNNscngL2w0xfqftsCGaueXDVKz0DaGu+xf5yiCT8jO/n59AtugGGD4qa2K0J5uuCMbTGWYa7qZKbjYMMRPQ3Ol98fZ2+NXbKA+Ut4G2ZIUjla24PwnNp6frYVsUG3yy4Y0Gt5AhU4gFmkNBVAo1L07Kg0Z16+FELdA+5aBy5wdsvFVKpXWA4ABwv0aJmo8dTcqzFmqM9j74Ud7nhi4ScM8fPtLW2+uVRzgJzbG9LNgzNeQUgCWpWn3y0y6TNIYQPdrqdvLc/LzQZLiUiKT1oQLGsOS51E37jQG3GJgA7TMLRvVXREjwlYTLWXvy2AURasvVUeWjCGlgjsZxKvLKTBHD798iO8uN17N5Fue8lFkzqL95QATHo3ji48v098ZRxtrYJct3qLWGMrwYszT6oJxoD4pUHDBULok/50r/QT1ILDRmuWVDa2DOcQwIkJRD1ewt0qjJ1VPFbQN2YpmaQdbhMto9EmGDanMxmvARgVIgWGwYehgvHG8xugg2JP6gg2qmF7ZIpMsxVB1DCmfEijxiT+wYYKzJLoylnQMMnFO2SB7FlKOfbFoFBYAhdtjm2u0MmS0jb2GMalTwLu7nugbOPcfdv4DpzX4A47kQcz41TTafGID1tPsD2xMmRWVxTzRZUmMKdjP+BUbAsEbEZWLyIbazicbvQXO+sqilslE6w8uKA+WJ0kntkoxwhFajBciMXVP+j0bKptzXex/juM6QwsRNcA5K+g1G/jJdiZW6CoSgdRwes1GCboUIZsDG6BxPtkIcNYrfkQymahxAynbqkQazg3Z4DBa1HE3bKU9s9HCL2+NPiH6A+Z74zYUiANhTr/DBnJ4mQEl4BNcQPpgj9Gaf4+NMfiE6CMltvfF4uQmsaDciOx8GY/paGKR5yupb1T2d4qYbSh1jWA1H3dVCxOSZaO9YTY/yOYLJo7DNJ2AXV3i9MOEbC8+fIMNPYZxQ6qWEip5Dpp7qNCp2/4GGy0+rCERZ/ypVE6WQDn0jdoKzcCZEJGNrYOGYI3ulxW0jWKHoaE5iIwTcZn9Z/muD1gvSlI2e8C5bOKMh6103iXmKi4GXPs1G2b5LhO3x5hHZWNDG0AElQHF12ygt6EulGHGRpvWWOePDdK3CmKywKRZBbANubjQ7hRxtnFitfZG0hyOeCAbTCakGJgEZucyG0x4x6EzOD64qL58xQaTCm1Fj8KHWuJKFFFsv2ZDXEGJRoJsJNSph9yxAX9CAV/CZ0+KAgtDj0iBz2zD0hCuoMMS1JX2ezbghYoqsIFmASA0P7kWjAKdVgLFf2fj6xd757qeJhCEYVkUSETwAKJGQbCeDUk1Gjw83v9ltUSYb5dKbP9Svl9toj6EfZ2ZnRlmBxQmEBswFjMUVFBP+Y6NAdgQjR3YuNxcY+HYaKMzWEvCSyy6IiXRhvJSq7Bp64rsJ7kUF55Gan20wYag56+M5AS3nWcDy/fM11NIg2OV+6BcNlCjuWs3zmJW1eHoGD+0G6HAhmg3UuyGBWOD1T51NIoygZqpLUnkQlilDfugbDw+XoV1GTGOjeEiVqef3FxYY+hH9mY64QmJaEhNPgWrlGEjXMQajlHuCLPxxja7HW5uGzBHfxlvIIAGGymIE7VgbFi+nC54L8hQ89W5cZtM7DHmra/oG2wTQUi4xy/jXbvDA1Ad3LHzgAW6DBPX0hCjxNXPKgpmD/Kiw+RfuAYhOIUW48StOPlsNJBF5WEBG7TzCYvFRnvKjXGqCYFoPDMw+Z2/MyvtyKZItIfxHO+GQi7F3pn32HBo9Y5JeEGaIADhtGhQaEBCjDD+jo05hbtD8TPgZEQdnimeyGHjFXupTHCqZnfM/SLlN5iHdLc/ZXOhyianxXi5O2KVAHkwHVU2lzrGkrGTGTbwRTvSHZzdSSM9xZoRHKmhn8U/3orJjv53bCADfsh4oPkpXfNh/KGdTL40n403+CLujzuDDa7sXyS7YVo9mVY284S0fpWkxB7s25VKZGCXMk3Nhmu1FHiaqVvJZyOkr9xzNiOO3W2WJvgBFPKrj9no02pVyUh16HU/8Sl/U09ZcZDhcy8ZNlbFY4Mb8SU8zubub9uX2K0ocW2VdbntyB5bGf1KwuxisIHb1kF1fCGYjT4S2mqGpqxj+PmQDfVEbmcLZ4GKfZOSYCtx2/GoDlsV67DjCthIrq1obLiorttRm2MmMiTkuUYmTf2KJaVBK/M2hBZGF2fZcBpYi5nQv3HCyndud3zOv394i/HQ1jE4wbo4nbOaYQN9nVtkxu/0bzhCm+Kh+l3/BiCbOHzDkPMHG81TwdjwEESsR0wY6ZNaDVlbxr+wbEzFN7x0KhR3MI/kwyeh7+sp/CG00Y1z+r4uk6Sodrg0F2GVfE2YtBA7zYvT4Zp1nggZ9H09vf2o8hXzzp99Xyp3EdWO01SdbQNsiWxAfaHvCzyAjVidgrFhYab5i8tnvXQJlROPxaUVDWysa8kcDltGq4/WdcVwTZRD3y4IpXLUTaAxWol5TZoowIMNQR14C1EL9PmI6qs5bMC08GrMeTbojcViI0pDUUneIdNprRWJjugy9jEaXtLkg0EcbCTMWlD8EZvns/FG9xnrAksda1bNLNcFzkDsIkfH2F02kItQf4hvPVOMIlwEggmRDWghEt0fVO6x4RSLjZ0tobqezGpxo08NzeTKrYPUsuE95PrONd191+fQkOyuO8+1G/1zzvMpz00x0wC9DtK955vA0pnbeL7dY2OyVXOeT1lxF3EUzMAiL2dOMPHXNlYrIhupwkKx0a2nbGhRYjS8na9wAWYvMOPYFGetyLKk9JbTZU+XrpDcDZjIBh5sC8+ZdFOYrFj2ubZZ2EgLrvxqOU+v6SLS826z0+8XqcQGPdh2pFdk8uKvmYtYvfVTcIf5dVholWZQj7AxWTbUSZHYQO+G1g1qbi3Y79baFdKN99sJOy/ES91vXWVN02TxHNnRPx3M1HRWzt1uDPWwWh2a998wEJLoeP8DNQ94q6D5IL4K9R8v+r8RspqKbXx+Gmu7Fe9NUIq/zWlpWz79bLP/AkriHYpsL8vZs0UTn/FWFF1XZFnmVt2fumltBSOLXctQwM/tefpuUKJRNJFPIUmcNaAk+Gij01SfIM5+6DJeKZXHQBZSEVVR4SbgUKgS/0FVl1a81WXBxpbJ98j1aa1Eo3iqTes3E6HXNUXwE7rftSiZhVpKcvqjFxnaDQ69/vlRnldfRLFg04rdQ91Yvvh1XcFx9OtpYOKUDMqsJ4dnMHf00qu3tJa9jhEqVUjVIqNeN/ZmhbnBx2bd823f7xk7y2UAiBtnvUQ5zvXe30derTw7pbBirvUxHX2RwMyaZ71H0bvltfkVZ0scrBLxo9BNk5XH6hRZjJnITTD8DzIpYFWMoFKqFIm5dMhw66U856CU0BtGkai9K4eHluLk4vQMwyqji1K/2ruXFAZhIADDEqkUAoaKFTdWFLKQduFC0fufrCDtzKTeoPzfJWYymYcKZnr+RUiBUa2SbhQLN+mRngqVvbQ1pXEYo7aU8kpBYm0lpEyEFFjR6zgbrxQYbrua9nJAuNDmeok8A0S46P63hqIojGq+SbdPzAD1iNIp6tcMSC6AyhQTqSgMN5Zy3HMjFYXh9DPFT6SiMCpdHjosVL5ghOi1dyMDVNgHqW7w0QbL9d/99vlOSEEidP5z8JOQgpQLzbGxJ38yfYAfrjuGYQv6enDixmm4+7KmuoGzapzrnpYvAAD+zxsTdnYFikaAUwAAAABJRU5ErkJggg==" alt="Image of dpboss.boston" height="57" width="292">

</a>
</div>
<div class="container-fluid">
<div>
<div class="panel panel-info">
<div class="panel-heading text-center" style="background: #3f51b5;"><h1  style="font-size: 22px;color:#fff; text-shadow: 0px 0px;">SAHARA Panel Chart </h1></div> 
<div class="panel-body">
<table style="width: 100%; text-align:center;" class="panel-chart chart-table" cellpadding="2">
<thead>
<tr>
<th>Date</th>
<th colspan="3">Mon</th>
<th colspan="3">Tue</th>
<th colspan="3">Wed</th>
<th colspan="3">Thu</th>
<th colspan="3">Fri</th>
<th colspan="3">Sat</th>
<th colspan="3">Sun</th>
</tr>
</thead>                	
<tbody>
   
   <tr>
      <td>04-01-2021 <br> To <br> 10-01-2021</td>
      <td class="chart-42">7<br>8<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>3<br>8</td>
      <td class="chart-50">7<br>8<br>0</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>4<br>5</td>
      <td class="chart-26">1<br>5<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">4<br>5<br>7</td>
      <td class="chart-82">1<br>2<br>5</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>3<br>8</td>
      <td class="chart-05">1<br>3<br>6</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">6<br>9<br>0</td>
      <td class="chart-34">2<br>5<br>6</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>4<br>9</td>
      <td class="chart-97">4<br>7<br>8</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>5<br>0</td>
   </tr>
   <tr>
      <td>11-01-2021 <br> To <br> 17-01-2021</td>
      <td class="chart-11">2<br>4<br>5</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>4<br>6</td>
      <td class="chart-52">4<br>5<br>6</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>4<br>7</td>
      <td class="chart-81">5<br>6<br>7</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>4<br>6</td>
      <td class="chart-18">5<br>7<br>9</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">1<br>7<br>0</td>
      <td class="chart-94">4<br>6<br>9</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>4<br>9</td>
      <td class="chart-29">1<br>4<br>7</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>5<br>0</td>
      <td class="chart-61">4<br>4<br>8</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">1<br>3<br>7</td>
   </tr>
   <tr>
      <td>18-01-2021 <br> To <br> 24-01-2021</td>
      <td class="chart-92">3<br>8<br>8</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>0<br>0</td>
      <td class="chart-10">3<br>8<br>0</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">2<br>3<br>5</td>
      <td class="chart-50">1<br>5<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">4<br>8<br>9</td>
      <td class="chart-02">1<br>3<br>6</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>4<br>9</td>
      <td class="chart-36">1<br>5<br>7</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">1<br>2<br>3</td>
      <td class="chart-53">7<br>8<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">4<br>9<br>0</td>
      <td class="chart-80">4<br>5<br>9</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">1<br>3<br>6</td>
   </tr>
   <tr>
      <td>25-01-2021 <br> To <br> 31-01-2021</td>
      <td class="chart-28">1<br>2<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>2<br>5</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-24">1<br>2<br>9</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">6<br>9<br>9</td>
      <td class="chart-89">5<br>6<br>7</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">2<br>3<br>4</td>
      <td class="chart-78">2<br>5<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">3<br>6<br>9</td>
      <td class="chart-25">4<br>8<br>0</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>5<br>9</td>
      <td class="chart-04">1<br>2<br>7</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>6<br>7</td>
   </tr>
   <tr>
      <td>01-02-2021 <br> To <br> 07-02-2021</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-79">3<br>6<br>8</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">5<br>6<br>8</td>
      <td class="chart-93">1<br>2<br>6</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>3<br>9</td>
      <td class="chart-29">1<br>5<br>6</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">3<br>6<br>0</td>
      <td class="chart-58">1<br>5<br>9</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">3<br>6<br>9</td>
      <td class="chart-65">1<br>2<br>3</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">4<br>5<br>6</td>
      <td class="chart-20">1<br>2<br>9</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">5<br>6<br>9</td>
   </tr>
   <tr>
      <td>08-02-2021 <br> To <br> 14-02-2021</td>
      <td class="chart-34">6<br>7<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">7<br>8<br>9</td>
      <td class="chart-98">4<br>5<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>6<br>0</td>
      <td class="chart-98">4<br>5<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>6<br>0</td>
      <td class="chart-47">1<br>3<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">3<br>6<br>8</td>
      <td class="chart-39">3<br>4<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">5<br>5<br>9</td>
      <td class="chart-86">1<br>3<br>4</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">3<br>6<br>7</td>
      <td class="chart-04">1<br>4<br>5</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>4<br>8</td>
   </tr>
   <tr>
      <td>15-02-2021 <br> To <br> 21-02-2021</td>
      <td class="chart-42">7<br>8<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">4<br>8<br>0</td>
      <td class="chart-93">5<br>5<br>9</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">6<br>8<br>9</td>
      <td class="chart-51">7<br>8<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">6<br>7<br>8</td>
      <td class="chart-63">7<br>9<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">3<br>4<br>6</td>
      <td class="chart-28">3<br>4<br>5</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>3<br>4</td>
      <td class="chart-15">1<br>4<br>6</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">2<br>5<br>8</td>
      <td class="chart-39">2<br>4<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>5<br>0</td>
   </tr>
   <tr>
      <td>22-02-2021 <br> To <br> 28-02-2021</td>
      <td class="chart-39">2<br>4<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>5<br>0</td>
      <td class="chart-46">2<br>4<br>8</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>6<br>9</td>
      <td class="chart-33">1<br>5<br>7</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">2<br>5<br>6</td>
      <td class="chart-23">3<br>9<br>0</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">2<br>5<br>6</td>
      <td class="chart-95">3<br>7<br>9</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">4<br>5<br>6</td>
      <td class="chart-19">4<br>8<br>9</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">3<br>7<br>9</td>
      <td class="chart-09">4<br>6<br>0</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>2<br>6</td>
   </tr>
   <tr>
      <td>01-03-2021 <br> To <br> 07-03-2021</td>
      <td class="chart-74">1<br>7<br>9</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">1<br>4<br>9</td>
      <td class="chart-09">2<br>3<br>5</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">4<br>6<br>9</td>
      <td class="chart-42">2<br>4<br>8</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">3<br>4<br>5</td>
      <td class="chart-27">5<br>8<br>9</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">2<br>5<br>0</td>
      <td class="chart-50">3<br>4<br>8</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>2<br>7</td>
      <td class="chart-35">1<br>3<br>9</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">7<br>8<br>0</td>
      <td class="chart-01">3<br>7<br>0</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">4<br>8<br>9</td>
   </tr>
   <tr>
      <td>08-03-2021 <br> To <br> 14-03-2021</td>
      <td class="chart-13">2<br>9<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>5<br>6</td>
      <td class="chart-62">1<br>5<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>2<br>9</td>
      <td class="chart-46">7<br>8<br>9</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">2<br>5<br>9</td>
      <td class="chart-46">7<br>8<br>9</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">2<br>5<br>9</td>
      <td class="chart-34">6<br>8<br>9</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>6<br>7</td>
      <td class="chart-91">2<br>7<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">3<br>8<br>0</td>
      <td class="chart-34">2<br>4<br>7</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>5<br>8</td>
   </tr>
   <tr>
      <td>15-03-2021 <br> To <br> 21-03-2021</td>
      <td class="chart-20">3<br>4<br>5</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>3<br>6</td>
      <td class="chart-71">1<br>7<br>9</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">6<br>7<br>8</td>
      <td class="chart-53">7<br>9<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">7<br>8<br>8</td>
      <td class="chart-09">6<br>7<br>7</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">4<br>6<br>9</td>
      <td class="chart-71">2<br>5<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">6<br>7<br>8</td>
      <td class="chart-42">2<br>3<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>4<br>7</td>
      <td class="chart-20">5<br>7<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>9<br>0</td>
   </tr>
   <tr>
      <td>22-03-2021 <br> To <br> 28-03-2021</td>
      <td class="chart-97">3<br>7<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">4<br>5<br>8</td>
      <td class="chart-17">5<br>6<br>0</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">1<br>6<br>0</td>
      <td class="chart-94">4<br>7<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>5<br>8</td>
      <td class="chart-07">1<br>3<br>6</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">4<br>5<br>8</td>
      <td class="chart-22">2<br>3<br>7</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">1<br>3<br>8</td>
      <td class="chart-63">3<br>3<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">6<br>8<br>9</td>
      <td class="chart-29">5<br>7<br>0</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">6<br>6<br>7</td>
   </tr>
   <tr>
      <td>29-03-2021 <br> To <br> 04-04-2021</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-53">2<br>5<br>8</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">2<br>5<br>6</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-58">1<br>6<br>8</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">4<br>5<br>9</td>
      <td class="chart-14">1<br>4<br>6</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>6<br>7</td>
      <td class="chart-14">1<br>3<br>7</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">7<br>8<br>9</td>
      <td class="chart-90">2<br>7<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">3<br>7<br>0</td>
   </tr>
   <tr>
      <td>05-04-2021 <br> To <br> 11-04-2021</td>
      <td class="chart-63">1<br>7<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">2<br>5<br>6</td>
      <td class="chart-05">6<br>6<br>8</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>5<br>8</td>
      <td class="chart-67">2<br>5<br>9</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>2<br>4</td>
      <td class="chart-37">3<br>4<br>6</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>6<br>0</td>
      <td class="chart-41">1<br>6<br>7</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">1<br>3<br>7</td>
      <td class="chart-19">4<br>8<br>9</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">4<br>5<br>0</td>
      <td class="chart-43">4<br>0<br>0</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">3<br>4<br>6</td>
   </tr>
   <tr>
      <td>12-04-2021 <br> To <br> 18-04-2021</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-23">6<br>8<br>8</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">7<br>7<br>9</td>
      <td class="chart-93">5<br>5<br>9</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>6<br>6</td>
      <td class="chart-76">1<br>2<br>4</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">2<br>4<br>0</td>
      <td class="chart-52">4<br>5<br>6</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">2<br>0<br>0</td>
      <td class="chart-31">2<br>5<br>6</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">2<br>3<br>6</td>
      <td class="chart-21">4<br>8<br>0</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">4<br>7<br>0</td>
   </tr>
   <tr>
      <td>19-04-2021 <br> To <br> 25-04-2021</td>
      <td class="chart-52">2<br>5<br>8</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>2<br>9</td>
      <td class="chart-65">6<br>0<br>0</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">6<br>9<br>0</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">3<br>9<br>9</td>
      <td class="chart-41">7<br>8<br>9</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>6<br>0</td>
      <td class="chart-37">1<br>3<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">2<br>5<br>0</td>
      <td class="chart-74">3<br>6<br>8</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">7<br>8<br>9</td>
      <td class="chart-97">4<br>6<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>6<br>9</td>
   </tr>
   <tr>
      <td>26-04-2021 <br> To <br> 02-05-2021</td>
      <td class="chart-41">3<br>4<br>7</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">4<br>8<br>9</td>
      <td class="chart-27">1<br>2<br>9</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">2<br>7<br>8</td>
      <td class="chart-93">3<br>6<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">2<br>5<br>6</td>
      <td class="chart-44">7<br>8<br>9</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">1<br>4<br>9</td>
      <td class="chart-91">6<br>6<br>7</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">1<br>3<br>7</td>
      <td class="chart-02">6<br>6<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">3<br>4<br>5</td>
      <td class="chart-87">8<br>0<br>0</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>7<br>9</td>
   </tr>
   <tr>
      <td>03-05-2021 <br> To <br> 09-05-2021</td>
      <td class="chart-85">1<br>3<br>4</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">3<br>4<br>8</td>
      <td class="chart-52">1<br>2<br>2</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>3<br>8</td>
      <td class="chart-58">6<br>9<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">1<br>8<br>9</td>
      <td class="chart-36">1<br>2<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">1<br>2<br>3</td>
      <td class="chart-25">6<br>7<br>9</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">2<br>5<br>8</td>
      <td class="chart-40">1<br>3<br>0</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>2<br>7</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>2<br>3</td>
   </tr>
   <tr>
      <td>10-05-2021 <br> To <br> 16-05-2021</td>
      <td class="chart-37">1<br>3<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>7<br>9</td>
      <td class="chart-98">4<br>5<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>6<br>0</td>
      <td class="chart-39">7<br>8<br>8</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">2<br>8<br>9</td>
      <td class="chart-54">2<br>6<br>7</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>6<br>7</td>
      <td class="chart-48">1<br>3<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">3<br>7<br>8</td>
      <td class="chart-40">6<br>9<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">3<br>8<br>9</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>2<br>3</td>
   </tr>
   <tr>
      <td>17-05-2021 <br> To <br> 23-05-2021</td>
      <td class="chart-64">3<br>6<br>7</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">1<br>5<br>8</td>
      <td class="chart-31">6<br>7<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">6<br>7<br>8</td>
      <td class="chart-96">4<br>6<br>9</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">1<br>7<br>8</td>
      <td class="chart-28">6<br>7<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>3<br>4</td>
      <td class="chart-73">1<br>7<br>9</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>8<br>0</td>
      <td class="chart-73">1<br>7<br>9</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>8<br>0</td>
      <td class="chart-73">1<br>6<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">6<br>7<br>0</td>
   </tr>
   <tr>
      <td>24-05-2021 <br> To <br> 30-05-2021</td>
      <td class="chart-53">1<br>4<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>4<br>8</td>
      <td class="chart-97">1<br>8<br>0</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>5<br>0</td>
      <td class="chart-75">4<br>5<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">6<br>9<br>0</td>
      <td class="chart-13">5<br>6<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>4<br>7</td>
      <td class="chart-14">1<br>2<br>8</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">6<br>8<br>0</td>
      <td class="chart-75">2<br>5<br>0</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">7<br>8<br>0</td>
      <td class="chart-70">1<br>6<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">4<br>7<br>9</td>
   </tr>
   <tr>
      <td>31-05-2021 <br> To <br> 06-06-2021</td>
      <td class="chart-06">1<br>3<br>6</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>6<br>9</td>
      <td class="chart-13">1<br>2<br>8</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>5<br>6</td>
      <td class="chart-25">1<br>2<br>9</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>6<br>8</td>
      <td class="chart-35">2<br>5<br>6</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">6<br>9<br>0</td>
      <td class="chart-48">1<br>5<br>8</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">3<br>6<br>9</td>
      <td class="chart-23">1<br>5<br>6</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">1<br>3<br>9</td>
      <td class="chart-95">1<br>8<br>0</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">2<br>3<br>0</td>
   </tr>
   <tr>
      <td>07-06-2021 <br> To <br> 13-06-2021</td>
      <td class="chart-32">5<br>8<br>0</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">2<br>4<br>6</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">3<br>6<br>7</td>
      <td class="chart-29">1<br>3<br>8</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">3<br>6<br>0</td>
      <td class="chart-14">4<br>8<br>9</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">2<br>4<br>8</td>
      <td class="chart-47">7<br>8<br>9</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>2<br>4</td>
      <td class="chart-94">5<br>6<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>6<br>7</td>
      <td class="chart-42">1<br>3<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
   </tr>
   <tr>
      <td>14-06-2021 <br> To <br> 20-06-2021</td>
      <td class="chart-23">5<br>7<br>0</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">2<br>3<br>8</td>
      <td class="chart-46">2<br>4<br>8</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">4<br>5<br>7</td>
      <td class="chart-95">1<br>2<br>6</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">6<br>9<br>0</td>
      <td class="chart-64">3<br>4<br>9</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">1<br>5<br>8</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-62">1<br>5<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>2<br>9</td>
      <td class="chart-62">2<br>5<br>9</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">2<br>3<br>7</td>
   </tr>
   <tr>
      <td>21-06-2021 <br> To <br> 27-06-2021</td>
      <td class="chart-71">1<br>6<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">5<br>6<br>0</td>
      <td class="chart-47">2<br>3<br>9</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">2<br>5<br>0</td>
      <td class="chart-68">4<br>5<br>7</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">5<br>6<br>7</td>
      <td class="chart-03">4<br>6<br>0</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>3<br>9</td>
      <td class="chart-08">5<br>7<br>8</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">2<br>6<br>0</td>
      <td class="chart-35">2<br>5<br>6</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">2<br>3<br>0</td>
      <td class="chart-97">3<br>7<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">4<br>5<br>8</td>
   </tr>
   <tr>
      <td>28-06-2021 <br> To <br> 04-07-2021</td>
      <td class="chart-92">2<br>3<br>4</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">6<br>7<br>9</td>
      <td class="chart-63">3<br>6<br>7</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">6<br>7<br>0</td>
      <td class="chart-97">1<br>3<br>5</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">3<br>4<br>0</td>
      <td class="chart-87">5<br>6<br>7</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">2<br>7<br>8</td>
      <td class="chart-98">1<br>8<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">1<br>2<br>5</td>
      <td class="chart-98">2<br>7<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">3<br>6<br>9</td>
      <td class="chart-59">1<br>5<br>9</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">2<br>7<br>0</td>
   </tr>
   <tr>
      <td>05-07-2021 <br> To <br> 11-07-2021</td>
      <td class="chart-24">4<br>8<br>0</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">1<br>3<br>0</td>
      <td class="chart-22">1<br>2<br>9</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">5<br>7<br>0</td>
      <td class="chart-24">4<br>8<br>0</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">1<br>3<br>0</td>
      <td class="chart-28">1<br>3<br>8</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">5<br>6<br>7</td>
      <td class="chart-87">5<br>6<br>7</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">2<br>5<br>0</td>
      <td class="chart-45">7<br>8<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">4<br>4<br>7</td>
      <td class="chart-51">2<br>5<br>8</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">1<br>2<br>8</td>
   </tr>
   <tr>
      <td>12-07-2021 <br> To <br> 18-07-2021</td>
      <td class="chart-02">2<br>3<br>5</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>4<br>7</td>
      <td class="chart-58">3<br>4<br>8</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">5<br>6<br>7</td>
      <td class="chart-43">7<br>8<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">2<br>3<br>8</td>
      <td class="chart-14">6<br>7<br>8</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>6<br>7</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-39">3<br>4<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>7<br>8</td>
      <td class="chart-21">2<br>3<br>7</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">1<br>3<br>7</td>
   </tr>
   <tr>
      <td>19-07-2021 <br> To <br> 25-07-2021</td>
      <td class="chart-45">7<br>8<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>5<br>8</td>
      <td class="chart-91">4<br>7<br>8</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">3<br>8<br>0</td>
      <td class="chart-42">3<br>5<br>6</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>4<br>7</td>
      <td class="chart-61">2<br>5<br>9</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>4<br>5</td>
      <td class="chart-30">2<br>3<br>8</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>6<br>9</td>
      <td class="chart-60">1<br>7<br>8</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">5<br>6<br>9</td>
      <td class="chart-78">4<br>5<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>3<br>4</td>
   </tr>
   <tr>
      <td>26-07-2021 <br> To <br> 01-08-2021</td>
      <td class="chart-84">3<br>7<br>8</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>4<br>9</td>
      <td class="chart-10">5<br>8<br>8</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">4<br>7<br>9</td>
      <td class="chart-82">2<br>7<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>4<br>7</td>
      <td class="chart-26">5<br>8<br>9</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">2<br>5<br>9</td>
      <td class="chart-45">7<br>8<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>4<br>9</td>
      <td class="chart-78">2<br>6<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">4<br>6<br>8</td>
      <td class="chart-04">3<br>7<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>6<br>6</td>
   </tr>
   <tr>
      <td>02-08-2021 <br> To <br> 08-08-2021</td>
      <td class="chart-61">1<br>6<br>9</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">1<br>3<br>7</td>
      <td class="chart-45">1<br>4<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">7<br>8<br>0</td>
      <td class="chart-73">1<br>7<br>9</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">2<br>5<br>6</td>
      <td class="chart-08">6<br>6<br>8</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>8<br>9</td>
      <td class="chart-02">2<br>4<br>4</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">6<br>8<br>8</td>
      <td class="chart-51">1<br>4<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">6<br>6<br>9</td>
      <td class="chart-47">1<br>4<br>9</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>8<br>8</td>
   </tr>
   <tr>
      <td>09-08-2021 <br> To <br> 15-08-2021</td>
      <td class="chart-13">1<br>3<br>7</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">3<br>0<br>0</td>
      <td class="chart-84">3<br>6<br>9</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">3<br>4<br>7</td>
      <td class="chart-09">5<br>7<br>8</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">5<br>6<br>8</td>
      <td class="chart-58">6<br>9<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">5<br>5<br>8</td>
      <td class="chart-44">1<br>6<br>7</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">1<br>3<br>0</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>6<br>9</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>16-08-2021 <br> To <br> 22-08-2021</td>
      <td class="chart-19">2<br>9<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>3<br>5</td>
      <td class="chart-99">4<br>5<br>0</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">5<br>6<br>8</td>
      <td class="chart-08">1<br>1<br>8</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">5<br>6<br>7</td>
      <td class="chart-04">6<br>7<br>7</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>4<br>9</td>
      <td class="chart-04">6<br>7<br>7</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>4<br>9</td>
      <td class="chart-69">1<br>2<br>3</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">1<br>9<br>9</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>23-08-2021 <br> To <br> 29-08-2021</td>
      <td class="chart-23">3<br>3<br>6</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">3<br>4<br>6</td>
      <td class="chart-75">2<br>7<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">1<br>4<br>0</td>
      <td class="chart-75">3<br>6<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">2<br>5<br>8</td>
      <td class="chart-75">1<br>8<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">4<br>5<br>6</td>
      <td class="chart-45">1<br>4<br>8</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">4<br>5<br>6</td>
      <td class="chart-96">2<br>8<br>9</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">2<br>5<br>9</td>
      <td class="chart-60">2<br>6<br>8</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">4<br>6<br>0</td>
   </tr>
   <tr>
      <td>30-08-2021 <br> To <br> 05-09-2021</td>
      <td class="chart-47">1<br>6<br>7</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">2<br>5<br>0</td>
      <td class="chart-31">1<br>3<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">6<br>7<br>8</td>
      <td class="chart-98">5<br>7<br>7</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">3<br>6<br>9</td>
      <td class="chart-06">1<br>2<br>7</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>2<br>3</td>
      <td class="chart-54">7<br>8<br>0</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">6<br>8<br>0</td>
      <td class="chart-73">5<br>6<br>6</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">2<br>3<br>8</td>
      <td class="chart-26">1<br>5<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>5<br>0</td>
   </tr>
   <tr>
      <td>06-09-2021 <br> To <br> 12-09-2021</td>
      <td class="chart-31">2<br>3<br>8</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">3<br>9<br>9</td>
      <td class="chart-57">1<br>1<br>3</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">3<br>4<br>0</td>
      <td class="chart-43">7<br>7<br>0</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">2<br>3<br>8</td>
      <td class="chart-78">1<br>8<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">4<br>5<br>9</td>
      <td class="chart-08">6<br>7<br>7</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>7<br>0</td>
      <td class="chart-78">7<br>0<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">3<br>6<br>9</td>
      <td class="chart-53">7<br>8<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>4<br>8</td>
   </tr>
   <tr>
      <td>13-09-2021 <br> To <br> 19-09-2021</td>
      <td class="chart-78">2<br>6<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>7<br>0</td>
      <td class="chart-82">4<br>5<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>2<br>9</td>
      <td class="chart-82">4<br>5<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>2<br>9</td>
      <td class="chart-65">1<br>7<br>8</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>5<br>8</td>
      <td class="chart-56">2<br>6<br>7</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>5<br>0</td>
      <td class="chart-62">1<br>6<br>9</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>2<br>9</td>
      <td class="chart-06">3<br>7<br>0</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">2<br>5<br>9</td>
   </tr>
   <tr>
      <td>20-09-2021 <br> To <br> 26-09-2021</td>
      <td class="chart-28">1<br>5<br>6</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">5<br>6<br>7</td>
      <td class="chart-32">2<br>5<br>6</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>3<br>8</td>
      <td class="chart-02">1<br>3<br>6</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>5<br>6</td>
      <td class="chart-40">6<br>8<br>0</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">5<br>6<br>9</td>
      <td class="chart-89">5<br>5<br>8</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">1<br>2<br>6</td>
      <td class="chart-10">1<br>3<br>7</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">6<br>7<br>7</td>
      <td class="chart-08">4<br>6<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">3<br>7<br>8</td>
   </tr>
   <tr>
      <td>27-09-2021 <br> To <br> 03-10-2021</td>
      <td class="chart-90">5<br>6<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">3<br>8<br>9</td>
      <td class="chart-01">4<br>7<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">4<br>8<br>9</td>
      <td class="chart-98">1<br>3<br>5</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>7<br>9</td>
      <td class="chart-98">1<br>3<br>5</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>7<br>9</td>
      <td class="chart-75">4<br>6<br>7</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">3<br>4<br>8</td>
      <td class="chart-45">1<br>6<br>7</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>5<br>8</td>
      <td class="chart-78">2<br>5<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">2<br>7<br>9</td>
   </tr>
   <tr>
      <td>04-10-2021 <br> To <br> 10-10-2021</td>
      <td class="chart-71">1<br>2<br>4</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">3<br>8<br>0</td>
      <td class="chart-34">1<br>4<br>8</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">3<br>5<br>6</td>
      <td class="chart-18">2<br>9<br>0</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">2<br>6<br>0</td>
      <td class="chart-49">6<br>8<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>9<br>9</td>
      <td class="chart-42">3<br>3<br>8</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>2<br>9</td>
      <td class="chart-83">1<br>3<br>4</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>3<br>9</td>
      <td class="chart-14">4<br>8<br>9</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>1<br>2</td>
   </tr>
   <tr>
      <td>11-10-2021 <br> To <br> 17-10-2021</td>
      <td class="chart-20">1<br>3<br>8</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>9<br>0</td>
      <td class="chart-24">5<br>8<br>9</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">1<br>5<br>8</td>
      <td class="chart-37">6<br>7<br>0</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">8<br>9<br>0</td>
      <td class="chart-39">2<br>5<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>6<br>9</td>
      <td class="chart-76">1<br>7<br>9</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">1<br>1<br>4</td>
      <td class="chart-54">2<br>4<br>9</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>5<br>8</td>
      <td class="chart-55">3<br>3<br>9</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">4<br>5<br>6</td>
   </tr>
   <tr>
      <td>18-10-2021 <br> To <br> 24-10-2021</td>
      <td class="chart-23">6<br>8<br>8</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">1<br>2<br>0</td>
      <td class="chart-54">2<br>4<br>9</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">7<br>8<br>9</td>
      <td class="chart-27">2<br>5<br>5</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">3<br>5<br>9</td>
      <td class="chart-06">5<br>7<br>8</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>6<br>9</td>
      <td class="chart-66">4<br>5<br>7</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-18">1<br>0<br>0</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">1<br>8<br>9</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>25-10-2021 <br> To <br> 31-10-2021</td>
      <td class="chart-35">2<br>5<br>6</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">2<br>4<br>9</td>
      <td class="chart-67">2<br>4<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>7<br>9</td>
      <td class="chart-47">6<br>8<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">4<br>4<br>9</td>
      <td class="chart-93">1<br>8<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">3<br>5<br>5</td>
      <td class="chart-00">2<br>8<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">5<br>5<br>0</td>
      <td class="chart-84">2<br>6<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">7<br>8<br>9</td>
      <td class="chart-75">7<br>0<br>0</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">3<br>3<br>9</td>
   </tr>
   <tr>
      <td>01-11-2021 <br> To <br> 07-11-2021</td>
      <td class="chart-44">4<br>5<br>5</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">4<br>4<br>6</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>7<br>8</td>
      <td class="chart-37">6<br>8<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>1<br>5</td>
      <td class="chart-37">6<br>8<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>1<br>5</td>
      <td class="chart-47">5<br>9<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">3<br>5<br>9</td>
      <td class="chart-39">1<br>5<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">1<br>2<br>6</td>
      <td class="chart-83">2<br>3<br>3</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">3<br>3<br>7</td>
   </tr>
   <tr>
      <td>08-11-2021 <br> To <br> 14-11-2021</td>
      <td class="chart-14">1<br>4<br>6</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">2<br>2<br>0</td>
      <td class="chart-45">2<br>5<br>7</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">4<br>5<br>6</td>
      <td class="chart-61">1<br>7<br>8</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">5<br>8<br>8</td>
      <td class="chart-02">1<br>3<br>6</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">6<br>7<br>9</td>
      <td class="chart-92">4<br>6<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>4<br>7</td>
      <td class="chart-98">9<br>0<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">3<br>7<br>8</td>
      <td class="chart-62">3<br>4<br>9</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">3<br>4<br>5</td>
   </tr>
   <tr>
      <td>15-11-2021 <br> To <br> 21-11-2021</td>
      <td class="chart-80">2<br>6<br>0</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">5<br>7<br>8</td>
      <td class="chart-89">3<br>7<br>8</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">5<br>6<br>8</td>
      <td class="chart-42">5<br>9<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">5<br>8<br>9</td>
      <td class="chart-72">8<br>9<br>0</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">4<br>8<br>0</td>
      <td class="chart-39">3<br>4<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>6<br>9</td>
      <td class="chart-80">4<br>5<br>9</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">2<br>3<br>5</td>
      <td class="chart-37">2<br>5<br>6</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>6<br>0</td>
   </tr>
   <tr>
      <td>22-11-2021 <br> To <br> 28-11-2021</td>
      <td class="chart-33">6<br>7<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">1<br>3<br>9</td>
      <td class="chart-58">7<br>8<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">3<br>7<br>8</td>
      <td class="chart-24">6<br>8<br>8</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">2<br>5<br>7</td>
      <td class="chart-83">4<br>6<br>8</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>2<br>0</td>
      <td class="chart-78">1<br>3<br>3</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">4<br>5<br>9</td>
      <td class="chart-27">1<br>5<br>6</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">4<br>5<br>8</td>
      <td class="chart-05">4<br>6<br>0</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">4<br>5<br>6</td>
   </tr>
   <tr>
      <td>29-11-2021 <br> To <br> 05-12-2021</td>
      <td class="chart-10">2<br>4<br>5</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>6<br>9</td>
      <td class="chart-70">2<br>7<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">3<br>8<br>9</td>
      <td class="chart-39">3<br>3<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">3<br>6<br>0</td>
      <td class="chart-06">5<br>7<br>8</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>1<br>4</td>
      <td class="chart-60">1<br>2<br>3</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>3<br>6</td>
      <td class="chart-26">2<br>0<br>0</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>7<br>8</td>
      <td class="chart-03">1<br>4<br>5</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">6<br>7<br>0</td>
   </tr>
   <tr>
      <td>06-12-2021 <br> To <br> 12-12-2021</td>
      <td class="chart-20">2<br>4<br>6</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">5<br>7<br>8</td>
      <td class="chart-29">5<br>8<br>9</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>6<br>9</td>
      <td class="chart-35">2<br>5<br>6</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">2<br>5<br>8</td>
      <td class="chart-66">2<br>5<br>9</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-01">2<br>8<br>0</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>3<br>7</td>
      <td class="chart-37">6<br>8<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">4<br>6<br>7</td>
      <td class="chart-03">5<br>6<br>9</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">3<br>4<br>6</td>
   </tr>
   <tr>
      <td>13-12-2021 <br> To <br> 19-12-2021</td>
      <td class="chart-76">4<br>5<br>8</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">3<br>4<br>9</td>
      <td class="chart-09">1<br>3<br>6</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>2<br>6</td>
      <td class="chart-98">1<br>3<br>5</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">1<br>2<br>5</td>
      <td class="chart-31">1<br>3<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">1<br>3<br>7</td>
      <td class="chart-38">6<br>7<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">4<br>5<br>9</td>
      <td class="chart-69">1<br>2<br>3</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">1<br>2<br>6</td>
      <td class="chart-56">2<br>4<br>9</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>7<br>8</td>
   </tr>
   <tr>
      <td>20-12-2021 <br> To <br> 26-12-2021</td>
      <td class="chart-65">2<br>5<br>9</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>3<br>0</td>
      <td class="chart-89">4<br>5<br>9</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">4<br>5<br>0</td>
      <td class="chart-54">3<br>5<br>7</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">7<br>8<br>9</td>
      <td class="chart-38">2<br>2<br>9</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">2<br>7<br>9</td>
      <td class="chart-30">1<br>3<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>2<br>7</td>
      <td class="chart-10">1<br>3<br>7</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">1<br>3<br>6</td>
      <td class="chart-07">5<br>6<br>9</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">3<br>6<br>8</td>
   </tr>
   <tr>
      <td>27-12-2021 <br> To <br> 02-01-2022</td>
      <td class="chart-98">2<br>7<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">1<br>7<br>0</td>
      <td class="chart-60">1<br>2<br>3</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">3<br>8<br>9</td>
      <td class="chart-14">3<br>9<br>9</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">7<br>8<br>9</td>
      <td class="chart-56">4<br>5<br>6</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>5<br>0</td>
      <td class="chart-13">5<br>7<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>4<br>7</td>
      <td class="chart-98">1<br>3<br>5</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">4<br>6<br>8</td>
      <td class="chart-44">5<br>9<br>0</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">4<br>0<br>0</td>
   </tr>
   <tr>
      <td>03-01-2022 <br> To <br> 09-01-2022</td>
      <td class="chart-89">5<br>6<br>7</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">1<br>8<br>0</td>
      <td class="chart-15">4<br>8<br>9</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">2<br>3<br>0</td>
      <td class="chart-79">1<br>7<br>9</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">1<br>3<br>5</td>
      <td class="chart-26">7<br>7<br>8</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>7<br>8</td>
      <td class="chart-04">3<br>8<br>9</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">7<br>8<br>9</td>
      <td class="chart-53">1<br>5<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">5<br>8<br>0</td>
      <td class="chart-11">6<br>6<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">5<br>7<br>9</td>
   </tr>
   <tr>
      <td>10-01-2022 <br> To <br> 16-01-2022</td>
      <td class="chart-40">1<br>4<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">2<br>3<br>5</td>
      <td class="chart-23">1<br>4<br>7</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">5<br>8<br>0</td>
      <td class="chart-36">1<br>2<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">2<br>5<br>9</td>
      <td class="chart-73">1<br>2<br>4</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">4<br>9<br>0</td>
      <td class="chart-74">4<br>6<br>7</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">6<br>8<br>0</td>
      <td class="chart-29">4<br>8<br>0</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>2<br>6</td>
      <td class="chart-95">4<br>6<br>9</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">2<br>4<br>9</td>
   </tr>
   <tr>
      <td>17-01-2022 <br> To <br> 23-01-2022</td>
      <td class="chart-02">1<br>3<br>6</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">6<br>8<br>8</td>
      <td class="chart-19">5<br>6<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">3<br>8<br>8</td>
      <td class="chart-97">4<br>7<br>8</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>6<br>9</td>
      <td class="chart-16">4<br>8<br>9</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">3<br>4<br>9</td>
      <td class="chart-38">6<br>8<br>9</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>6<br>7</td>
      <td class="chart-30">2<br>2<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>6<br>8</td>
      <td class="chart-90">2<br>8<br>9</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">1<br>0<br>0</td>
   </tr>
   <tr>
      <td>24-01-2022 <br> To <br> 30-01-2022</td>
      <td class="chart-89">1<br>3<br>4</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">5<br>6<br>8</td>
      <td class="chart-26">3<br>4<br>5</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>5<br>0</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-28">1<br>5<br>6</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">5<br>6<br>7</td>
      <td class="chart-22">3<br>8<br>9</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">4<br>8<br>0</td>
      <td class="chart-48">7<br>8<br>9</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">1<br>8<br>9</td>
      <td class="chart-00">2<br>9<br>9</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>9<br>0</td>
   </tr>
   <tr>
      <td>31-01-2022 <br> To <br> 06-02-2022</td>
      <td class="chart-00">1<br>9<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">4<br>6<br>0</td>
      <td class="chart-64">7<br>9<br>0</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">7<br>8<br>9</td>
      <td class="chart-79">2<br>2<br>3</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">1<br>2<br>6</td>
      <td class="chart-56">4<br>5<br>6</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>6<br>9</td>
      <td class="chart-86">1<br>2<br>5</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">3<br>5<br>8</td>
      <td class="chart-28">1<br>3<br>8</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">3<br>7<br>8</td>
      <td class="chart-83">1<br>7<br>0</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>7<br>0</td>
   </tr>
   <tr>
      <td>07-02-2022 <br> To <br> 13-02-2022</td>
      <td class="chart-84">4<br>6<br>8</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>4<br>9</td>
      <td class="chart-74">2<br>5<br>0</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">2<br>4<br>8</td>
      <td class="chart-02">5<br>7<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>5<br>6</td>
      <td class="chart-47">2<br>4<br>8</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>1<br>5</td>
      <td class="chart-28">1<br>2<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>7<br>0</td>
      <td class="chart-94">4<br>6<br>9</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">4<br>0<br>0</td>
      <td class="chart-87">4<br>5<br>9</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">2<br>5<br>0</td>
   </tr>
   <tr>
      <td>14-02-2022 <br> To <br> 20-02-2022</td>
      <td class="chart-66">3<br>5<br>8</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">2<br>4<br>0</td>
      <td class="chart-20">1<br>4<br>7</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">3<br>7<br>0</td>
      <td class="chart-80">4<br>6<br>8</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">2<br>3<br>5</td>
      <td class="chart-12">1<br>3<br>7</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>0<br>0</td>
      <td class="chart-78">2<br>2<br>3</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">5<br>5<br>8</td>
      <td class="chart-34">6<br>7<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>4<br>9</td>
      <td class="chart-64">1<br>5<br>0</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">4<br>5<br>5</td>
   </tr>
   <tr>
      <td>21-02-2022 <br> To <br> 27-02-2022</td>
      <td class="chart-76">2<br>7<br>8</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">1<br>6<br>9</td>
      <td class="chart-13">5<br>7<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">3<br>4<br>6</td>
      <td class="chart-61">2<br>4<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">6<br>7<br>8</td>
      <td class="chart-64">7<br>9<br>0</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">7<br>8<br>9</td>
      <td class="chart-75">2<br>7<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">1<br>6<br>8</td>
      <td class="chart-39">2<br>5<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">1<br>3<br>5</td>
      <td class="chart-99">1<br>8<br>0</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">4<br>5<br>0</td>
   </tr>
   <tr>
      <td>28-02-2022 <br> To <br> 06-03-2022</td>
      <td class="chart-62">4<br>5<br>7</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>2<br>9</td>
      <td class="chart-90">3<br>7<br>9</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">4<br>7<br>9</td>
      <td class="chart-43">1<br>6<br>7</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">5<br>8<br>0</td>
      <td class="chart-70">2<br>5<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>3<br>6</td>
      <td class="chart-83">5<br>6<br>7</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>7<br>0</td>
      <td class="chart-25">2<br>4<br>6</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">2<br>5<br>8</td>
      <td class="chart-93">2<br>7<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">6<br>8<br>9</td>
   </tr>
   <tr>
      <td>07-03-2022 <br> To <br> 13-03-2022</td>
      <td class="chart-50">4<br>5<br>6</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">5<br>7<br>8</td>
      <td class="chart-82">2<br>6<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">5<br>7<br>0</td>
      <td class="chart-21">1<br>3<br>8</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">6<br>7<br>8</td>
      <td class="chart-94">9<br>0<br>0</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">2<br>2<br>0</td>
      <td class="chart-19">5<br>8<br>8</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>8<br>0</td>
      <td class="chart-90">6<br>6<br>7</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>5<br>0</td>
      <td class="chart-16">1<br>0<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">2<br>4<br>0</td>
   </tr>
   <tr>
      <td>14-03-2022 <br> To <br> 20-03-2022</td>
      <td class="chart-12">2<br>9<br>0</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">6<br>7<br>9</td>
      <td class="chart-94">5<br>6<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>4<br>9</td>
      <td class="chart-50">1<br>5<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>9<br>0</td>
      <td class="chart-33">1<br>3<br>9</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">2<br>5<br>6</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-51">3<br>3<br>9</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">3<br>9<br>9</td>
      <td class="chart-00">4<br>7<br>9</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">4<br>6<br>0</td>
   </tr>
   <tr>
      <td>21-03-2022 <br> To <br> 27-03-2022</td>
      <td class="chart-25">4<br>8<br>0</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>6<br>8</td>
      <td class="chart-14">5<br>6<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>6<br>7</td>
      <td class="chart-84">1<br>3<br>4</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">5<br>9<br>0</td>
      <td class="chart-19">3<br>8<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">2<br>3<br>4</td>
      <td class="chart-95">1<br>3<br>5</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">3<br>3<br>9</td>
      <td class="chart-44">3<br>3<br>8</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">1<br>3<br>0</td>
      <td class="chart-44">2<br>5<br>7</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">4<br>0<br>0</td>
   </tr>
   <tr>
      <td>28-03-2022 <br> To <br> 03-04-2022</td>
      <td class="chart-11">2<br>9<br>0</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-05">1<br>2<br>7</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>5<br>8</td>
      <td class="chart-95">4<br>6<br>9</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">4<br>5<br>6</td>
      <td class="chart-81">1<br>3<br>4</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>4<br>6</td>
      <td class="chart-10">1<br>3<br>7</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">1<br>9<br>0</td>
      <td class="chart-99">9<br>0<br>0</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">1<br>3<br>5</td>
      <td class="chart-49">3<br>5<br>6</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">5<br>5<br>9</td>
   </tr>
   <tr>
      <td>04-04-2022 <br> To <br> 10-04-2022</td>
      <td class="chart-65">2<br>5<br>9</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">7<br>9<br>9</td>
      <td class="chart-25">1<br>4<br>7</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>5<br>9</td>
      <td class="chart-13">1<br>3<br>7</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">6<br>7<br>0</td>
      <td class="chart-41">6<br>8<br>0</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>5<br>8</td>
      <td class="chart-14">6<br>6<br>9</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>5<br>8</td>
      <td class="chart-68">1<br>6<br>9</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">3<br>6<br>9</td>
      <td class="chart-74">8<br>9<br>0</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">3<br>5<br>6</td>
   </tr>
   <tr>
      <td>11-04-2022 <br> To <br> 17-04-2022</td>
      <td class="chart-45">1<br>3<br>0</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>4<br>9</td>
      <td class="chart-31">6<br>8<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">6<br>7<br>8</td>
      <td class="chart-79">2<br>5<br>0</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">2<br>8<br>9</td>
      <td class="chart-12">1<br>4<br>6</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">1<br>3<br>8</td>
      <td class="chart-89">3<br>6<br>9</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">1<br>2<br>6</td>
      <td class="chart-06">5<br>7<br>8</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">7<br>9<br>0</td>
      <td class="chart-05">1<br>2<br>7</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">4<br>4<br>7</td>
   </tr>
   <tr>
      <td>18-04-2022 <br> To <br> 24-04-2022</td>
      <td class="chart-15">6<br>6<br>9</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">4<br>5<br>6</td>
      <td class="chart-73">1<br>7<br>9</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">2<br>5<br>6</td>
      <td class="chart-49">1<br>6<br>7</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">2<br>8<br>9</td>
      <td class="chart-13">2<br>9<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">6<br>8<br>9</td>
      <td class="chart-96">5<br>6<br>8</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">1<br>6<br>9</td>
      <td class="chart-38">1<br>5<br>7</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>6<br>7</td>
      <td class="chart-62">2<br>6<br>8</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">2<br>0<br>0</td>
   </tr>
   <tr>
      <td>25-04-2022 <br> To <br> 01-05-2022</td>
      <td class="chart-70">2<br>7<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>2<br>7</td>
      <td class="chart-90">3<br>8<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">6<br>6<br>8</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">6<br>7<br>7</td>
      <td class="chart-86">2<br>7<br>9</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>2<br>3</td>
      <td class="chart-85">5<br>6<br>7</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">7<br>8<br>0</td>
      <td class="chart-45">2<br>3<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>3<br>0</td>
      <td class="chart-82">4<br>5<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">5<br>8<br>9</td>
   </tr>
   <tr>
      <td>02-05-2022 <br> To <br> 08-05-2022</td>
      <td class="chart-15">1<br>2<br>8</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">7<br>8<br>0</td>
      <td class="chart-17">1<br>5<br>5</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">2<br>5<br>0</td>
      <td class="chart-67">3<br>4<br>9</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>8<br>8</td>
      <td class="chart-94">4<br>6<br>9</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">5<br>9<br>0</td>
      <td class="chart-48">2<br>5<br>7</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">2<br>6<br>0</td>
      <td class="chart-81">5<br>5<br>8</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">3<br>8<br>0</td>
      <td class="chart-77">2<br>6<br>9</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">2<br>7<br>8</td>
   </tr>
   <tr>
      <td>09-05-2022 <br> To <br> 15-05-2022</td>
      <td class="chart-96">4<br>6<br>9</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">1<br>2<br>3</td>
      <td class="chart-23">6<br>7<br>9</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">2<br>5<br>6</td>
      <td class="chart-42">6<br>8<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">4<br>9<br>9</td>
      <td class="chart-73">8<br>9<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">6<br>7<br>0</td>
      <td class="chart-04">5<br>7<br>8</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>6<br>7</td>
      <td class="chart-60">3<br>5<br>8</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">2<br>3<br>5</td>
      <td class="chart-45">4<br>0<br>0</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>6<br>7</td>
   </tr>
   <tr>
      <td>16-05-2022 <br> To <br> 22-05-2022</td>
      <td class="chart-31">5<br>8<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">2<br>4<br>5</td>
      <td class="chart-31">5<br>8<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">2<br>4<br>5</td>
      <td class="chart-57">7<br>8<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">4<br>6<br>7</td>
      <td class="chart-04">4<br>6<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">7<br>8<br>9</td>
      <td class="chart-16">5<br>7<br>9</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">2<br>5<br>9</td>
      <td class="chart-48">1<br>3<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">1<br>8<br>9</td>
      <td class="chart-61">2<br>4<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">6<br>7<br>8</td>
   </tr>
   <tr>
      <td>23-05-2022 <br> To <br> 29-05-2022</td>
      <td class="chart-81">3<br>6<br>9</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>3<br>7</td>
      <td class="chart-26">1<br>4<br>7</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>7<br>8</td>
      <td class="chart-54">1<br>6<br>8</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>3<br>0</td>
      <td class="chart-17">4<br>8<br>9</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">4<br>6<br>7</td>
      <td class="chart-32">5<br>8<br>0</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>5<br>6</td>
      <td class="chart-53">3<br>3<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">6<br>8<br>9</td>
      <td class="chart-72">3<br>5<br>9</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">6<br>7<br>9</td>
   </tr>
   <tr>
      <td>30-05-2022 <br> To <br> 05-06-2022</td>
      <td class="chart-95">5<br>5<br>9</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">5<br>0<br>0</td>
      <td class="chart-57">1<br>2<br>2</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">1<br>7<br>9</td>
      <td class="chart-93">2<br>7<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">3<br>4<br>6</td>
      <td class="chart-41">4<br>5<br>5</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">1<br>3<br>7</td>
      <td class="chart-54">3<br>5<br>7</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">2<br>3<br>9</td>
      <td class="chart-71">4<br>5<br>8</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">2<br>4<br>5</td>
      <td class="chart-71">4<br>5<br>8</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">2<br>4<br>5</td>
   </tr>
   <tr>
      <td>06-06-2022 <br> To <br> 12-06-2022</td>
      <td class="chart-72">3<br>6<br>8</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">1<br>4<br>7</td>
      <td class="chart-54">2<br>4<br>9</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>1<br>2</td>
      <td class="chart-03">5<br>7<br>8</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">2<br>5<br>6</td>
      <td class="chart-73">2<br>5<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">2<br>4<br>7</td>
      <td class="chart-45">3<br>4<br>7</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">7<br>8<br>0</td>
      <td class="chart-04">4<br>6<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>5<br>7</td>
      <td class="chart-04">4<br>6<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>5<br>7</td>
   </tr>
   <tr>
      <td>13-06-2022 <br> To <br> 19-06-2022</td>
      <td class="chart-05">5<br>6<br>9</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>4<br>9</td>
      <td class="chart-73">1<br>2<br>4</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">6<br>8<br>9</td>
      <td class="chart-93">4<br>6<br>9</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>3<br>9</td>
      <td class="chart-52">2<br>6<br>7</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">2<br>5<br>5</td>
      <td class="chart-55">1<br>6<br>8</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">4<br>4<br>7</td>
      <td class="chart-03">4<br>6<br>0</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>4<br>8</td>
      <td class="chart-81">1<br>7<br>0</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>1<br>9</td>
   </tr>
   <tr>
      <td>20-06-2022 <br> To <br> 26-06-2022</td>
      <td class="chart-18">2<br>4<br>5</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">1<br>8<br>9</td>
      <td class="chart-66">3<br>6<br>7</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">1<br>1<br>4</td>
      <td class="chart-05">1<br>3<br>6</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">4<br>5<br>6</td>
      <td class="chart-26">3<br>4<br>5</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">7<br>9<br>0</td>
      <td class="chart-65">2<br>4<br>0</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">3<br>3<br>9</td>
      <td class="chart-29">2<br>4<br>6</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>1<br>7</td>
      <td class="chart-21">3<br>9<br>0</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">1<br>5<br>5</td>
   </tr>
   <tr>
      <td>27-06-2022 <br> To <br> 03-07-2022</td>
      <td class="chart-14">2<br>4<br>5</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">6<br>9<br>9</td>
      <td class="chart-56">3<br>4<br>8</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">3<br>3<br>0</td>
      <td class="chart-04">2<br>3<br>5</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">7<br>8<br>9</td>
      <td class="chart-64">2<br>5<br>9</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">5<br>9<br>0</td>
      <td class="chart-32">1<br>3<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>2<br>9</td>
      <td class="chart-36">6<br>7<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">8<br>9<br>9</td>
      <td class="chart-70">3<br>5<br>9</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">4<br>6<br>0</td>
   </tr>
   <tr>
      <td>04-07-2022 <br> To <br> 10-07-2022</td>
      <td class="chart-12">4<br>8<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">5<br>8<br>9</td>
      <td class="chart-90">1<br>2<br>6</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">1<br>9<br>0</td>
      <td class="chart-48">2<br>4<br>8</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">5<br>5<br>8</td>
      <td class="chart-05">1<br>4<br>5</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>6<br>7</td>
      <td class="chart-26">3<br>9<br>0</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>2<br>3</td>
      <td class="chart-10">4<br>8<br>9</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">2<br>3<br>5</td>
      <td class="chart-43">7<br>8<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">4<br>9<br>0</td>
   </tr>
   <tr>
      <td>11-07-2022 <br> To <br> 17-07-2022</td>
      <td class="chart-20">1<br>5<br>6</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>9<br>0</td>
      <td class="chart-05">2<br>8<br>0</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">3<br>4<br>8</td>
      <td class="chart-76">2<br>7<br>8</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">7<br>9<br>0</td>
      <td class="chart-27">1<br>4<br>7</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>2<br>4</td>
      <td class="chart-38">1<br>2<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>6<br>7</td>
      <td class="chart-18">1<br>4<br>6</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">4<br>6<br>8</td>
      <td class="chart-00">1<br>2<br>7</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">2<br>9<br>9</td>
   </tr>
   <tr>
      <td>18-07-2022 <br> To <br> 24-07-2022</td>
      <td class="chart-92">1<br>2<br>6</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>4<br>6</td>
      <td class="chart-97">3<br>6<br>0</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>6<br>9</td>
      <td class="chart-92">1<br>8<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>4<br>7</td>
      <td class="chart-50">2<br>3<br>0</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>2<br>7</td>
      <td class="chart-12">5<br>7<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>3<br>7</td>
      <td class="chart-24">1<br>5<br>6</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">6<br>8<br>0</td>
      <td class="chart-87">2<br>6<br>0</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>7<br>9</td>
   </tr>
   <tr>
      <td>25-07-2022 <br> To <br> 31-07-2022</td>
      <td class="chart-17">1<br>4<br>6</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">3<br>6<br>8</td>
      <td class="chart-86">4<br>5<br>9</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>6<br>9</td>
      <td class="chart-41">1<br>5<br>8</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">4<br>8<br>9</td>
      <td class="chart-82">1<br>7<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>3<br>7</td>
      <td class="chart-40">7<br>8<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>4<br>5</td>
      <td class="chart-84">5<br>6<br>7</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>6<br>7</td>
      <td class="chart-27">3<br>4<br>5</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>6<br>0</td>
   </tr>
   <tr>
      <td>01-08-2022 <br> To <br> 07-08-2022</td>
      <td class="chart-36">2<br>4<br>7</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">6<br>0<br>0</td>
      <td class="chart-30">6<br>7<br>0</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">6<br>7<br>7</td>
      <td class="chart-52">4<br>5<br>6</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">4<br>8<br>0</td>
      <td class="chart-32">6<br>8<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>5<br>6</td>
      <td class="chart-81">1<br>8<br>9</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>3<br>7</td>
      <td class="chart-53">2<br>6<br>7</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>5<br>7</td>
      <td class="chart-55">1<br>4<br>0</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">2<br>3<br>0</td>
   </tr>
   <tr>
      <td>08-08-2022 <br> To <br> 14-08-2022</td>
      <td class="chart-19">2<br>9<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">4<br>6<br>9</td>
      <td class="chart-17">1<br>4<br>6</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">3<br>7<br>7</td>
      <td class="chart-39">1<br>6<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">3<br>8<br>8</td>
      <td class="chart-60">8<br>8<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">2<br>3<br>5</td>
      <td class="chart-28">4<br>8<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">4<br>5<br>9</td>
      <td class="chart-23">1<br>2<br>9</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">1<br>6<br>6</td>
      <td class="chart-88">4<br>6<br>8</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">2<br>7<br>9</td>
   </tr>
   <tr>
      <td>15-08-2022 <br> To <br> 21-08-2022</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-72">2<br>6<br>9</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">5<br>8<br>9</td>
      <td class="chart-32">2<br>4<br>7</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>4<br>7</td>
      <td class="chart-56">2<br>4<br>9</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">8<br>9<br>9</td>
      <td class="chart-31">1<br>6<br>6</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">1<br>1<br>9</td>
      <td class="chart-38">1<br>5<br>7</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>8<br>9</td>
      <td class="chart-52">6<br>9<br>0</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>4<br>7</td>
   </tr>
   <tr>
      <td>22-08-2022 <br> To <br> 28-08-2022</td>
      <td class="chart-95">4<br>5<br>0</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">2<br>3<br>0</td>
      <td class="chart-27">2<br>4<br>6</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>7<br>9</td>
      <td class="chart-14">1<br>4<br>6</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>3<br>0</td>
      <td class="chart-78">4<br>4<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">5<br>6<br>7</td>
      <td class="chart-04">3<br>8<br>9</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">6<br>8<br>0</td>
      <td class="chart-44">7<br>8<br>9</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">3<br>4<br>7</td>
      <td class="chart-74">2<br>6<br>9</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">2<br>3<br>9</td>
   </tr>
   <tr>
      <td>29-08-2022 <br> To <br> 04-09-2022</td>
      <td class="chart-11">1<br>3<br>7</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">2<br>9<br>0</td>
      <td class="chart-09">1<br>3<br>6</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>3<br>5</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>5<br>0</td>
      <td class="chart-99">9<br>0<br>0</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">2<br>8<br>9</td>
      <td class="chart-38">1<br>3<br>9</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>2<br>5</td>
      <td class="chart-12">4<br>8<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">3<br>9<br>0</td>
      <td class="chart-53">1<br>5<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>4<br>8</td>
   </tr>
   <tr>
      <td>05-09-2022 <br> To <br> 11-09-2022</td>
      <td class="chart-07">5<br>7<br>8</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">7<br>0<br>0</td>
      <td class="chart-39">5<br>9<br>9</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">6<br>6<br>9</td>
      <td class="chart-75">8<br>9<br>0</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">2<br>4<br>9</td>
      <td class="chart-24">1<br>2<br>9</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">7<br>8<br>9</td>
      <td class="chart-84">3<br>6<br>9</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">7<br>7<br>0</td>
      <td class="chart-55">1<br>5<br>9</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">4<br>5<br>6</td>
      <td class="chart-98">5<br>7<br>7</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">5<br>5<br>8</td>
   </tr>
   <tr>
      <td>12-09-2022 <br> To <br> 18-09-2022</td>
      <td class="chart-44">1<br>4<br>9</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">6<br>8<br>0</td>
      <td class="chart-83">1<br>3<br>4</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">4<br>9<br>0</td>
      <td class="chart-13">2<br>9<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">1<br>3<br>9</td>
      <td class="chart-41">1<br>6<br>7</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>8<br>8</td>
      <td class="chart-82">1<br>2<br>5</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>8<br>8</td>
      <td class="chart-83">4<br>5<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>2<br>0</td>
      <td class="chart-55">4<br>5<br>6</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>5<br>9</td>
   </tr>
   <tr>
      <td>19-09-2022 <br> To <br> 25-09-2022</td>
      <td class="chart-92">9<br>0<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>2<br>9</td>
      <td class="chart-92">9<br>0<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>2<br>9</td>
      <td class="chart-28">2<br>0<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">4<br>5<br>9</td>
      <td class="chart-81">5<br>6<br>7</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">6<br>6<br>9</td>
      <td class="chart-53">1<br>5<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>3<br>9</td>
      <td class="chart-03">2<br>8<br>0</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>5<br>7</td>
      <td class="chart-12">4<br>8<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">6<br>8<br>8</td>
   </tr>
   <tr>
      <td>26-09-2022 <br> To <br> 02-10-2022</td>
      <td class="chart-73">4<br>5<br>8</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">6<br>8<br>9</td>
      <td class="chart-68">3<br>6<br>7</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">1<br>2<br>5</td>
      <td class="chart-60">7<br>9<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">3<br>8<br>9</td>
      <td class="chart-42">5<br>9<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
      <td class="chart-50">2<br>4<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>3<br>6</td>
      <td class="chart-50">7<br>8<br>0</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>1<br>8</td>
      <td class="chart-82">1<br>8<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">5<br>7<br>0</td>
   </tr>
   <tr>
      <td>03-10-2022 <br> To <br> 09-10-2022</td>
      <td class="chart-05">1<br>9<br>0</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>3<br>0</td>
      <td class="chart-20">1<br>2<br>9</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>3<br>6</td>
      <td class="chart-57">6<br>9<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">1<br>6<br>0</td>
      <td class="chart-77">4<br>5<br>8</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">2<br>2<br>3</td>
      <td class="chart-79">3<br>6<br>8</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">4<br>5<br>0</td>
      <td class="chart-18">6<br>7<br>8</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">3<br>6<br>9</td>
      <td class="chart-29">4<br>8<br>0</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>3<br>5</td>
   </tr>
   <tr>
      <td>10-10-2022 <br> To <br> 16-10-2022</td>
      <td class="chart-17">3<br>8<br>0</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">2<br>7<br>8</td>
      <td class="chart-47">6<br>9<br>9</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">3<br>7<br>7</td>
      <td class="chart-25">3<br>4<br>5</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">6<br>9<br>0</td>
      <td class="chart-40">1<br>4<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">3<br>7<br>0</td>
      <td class="chart-79">4<br>6<br>7</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">3<br>6<br>0</td>
      <td class="chart-62">1<br>6<br>9</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>3<br>8</td>
      <td class="chart-65">1<br>2<br>3</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">1<br>5<br>9</td>
   </tr>
   <tr>
      <td>17-10-2022 <br> To <br> 23-10-2022</td>
      <td class="chart-99">4<br>6<br>9</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">1<br>8<br>0</td>
      <td class="chart-32">6<br>8<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>3<br>8</td>
      <td class="chart-89">2<br>6<br>0</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">3<br>6<br>0</td>
      <td class="chart-16">1<br>4<br>6</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">7<br>9<br>0</td>
      <td class="chart-90">2<br>8<br>9</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">4<br>6<br>0</td>
      <td class="chart-20">4<br>9<br>9</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>3<br>6</td>
      <td class="chart-50">2<br>4<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>9<br>0</td>
   </tr>
   <tr>
      <td>24-10-2022 <br> To <br> 30-10-2022</td>
      <td class="chart-09">1<br>2<br>7</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>4<br>4</td>
      <td class="chart-06">3<br>7<br>0</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">2<br>6<br>8</td>
      <td class="chart-94">2<br>7<br>0</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">3<br>3<br>8</td>
      <td class="chart-94">4<br>7<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">3<br>3<br>8</td>
      <td class="chart-00">1<br>4<br>5</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>2<br>7</td>
      <td class="chart-61">7<br>9<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>2<br>7</td>
      <td class="chart-46">5<br>9<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">8<br>9<br>9</td>
   </tr>
   <tr>
      <td>31-10-2022 <br> To <br> 06-11-2022</td>
      <td class="chart-04">4<br>6<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>3<br>9</td>
      <td class="chart-86">1<br>2<br>5</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>2<br>3</td>
      <td class="chart-33">1<br>3<br>9</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">2<br>3<br>8</td>
      <td class="chart-62">1<br>5<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>3<br>8</td>
      <td class="chart-26">6<br>7<br>9</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">2<br>5<br>9</td>
      <td class="chart-84">1<br>3<br>4</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>6<br>7</td>
      <td class="chart-89">2<br>6<br>0</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">4<br>5<br>0</td>
   </tr>
   <tr>
      <td>07-11-2022 <br> To <br> 13-11-2022</td>
      <td class="chart-60">2<br>4<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">5<br>7<br>8</td>
      <td class="chart-10">5<br>6<br>0</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">3<br>7<br>0</td>
      <td class="chart-35">6<br>7<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">6<br>9<br>0</td>
      <td class="chart-20">1<br>4<br>7</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">2<br>8<br>0</td>
      <td class="chart-46">2<br>3<br>9</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>7<br>8</td>
      <td class="chart-31">1<br>3<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">1<br>3<br>7</td>
      <td class="chart-85">3<br>5<br>0</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">1<br>6<br>8</td>
   </tr>
   <tr>
      <td>14-11-2022 <br> To <br> 20-11-2022</td>
      <td class="chart-14">2<br>4<br>5</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">3<br>5<br>6</td>
      <td class="chart-29">2<br>3<br>7</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">2<br>7<br>0</td>
      <td class="chart-17">2<br>9<br>0</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">3<br>6<br>8</td>
      <td class="chart-63">1<br>2<br>3</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>2<br>0</td>
      <td class="chart-48">6<br>8<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">5<br>6<br>7</td>
      <td class="chart-39">2<br>3<br>8</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">5<br>5<br>9</td>
      <td class="chart-91">1<br>2<br>6</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">5<br>7<br>9</td>
   </tr>
   <tr>
      <td>21-11-2022 <br> To <br> 27-11-2022</td>
      <td class="chart-70">2<br>5<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>9<br>0</td>
      <td class="chart-11">2<br>9<br>0</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">3<br>8<br>0</td>
      <td class="chart-12">2<br>4<br>5</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">1<br>3<br>8</td>
      <td class="chart-57">4<br>5<br>6</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">2<br>6<br>9</td>
      <td class="chart-50">1<br>5<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">2<br>8<br>0</td>
      <td class="chart-60">7<br>9<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>9<br>0</td>
      <td class="chart-77">4<br>6<br>7</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">7<br>0<br>0</td>
   </tr>
   <tr>
      <td>28-11-2022 <br> To <br> 04-12-2022</td>
      <td class="chart-36">5<br>8<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">4<br>5<br>7</td>
      <td class="chart-29">1<br>5<br>6</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>5<br>0</td>
      <td class="chart-01">4<br>6<br>0</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">3<br>8<br>0</td>
      <td class="chart-05">1<br>9<br>0</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">7<br>8<br>0</td>
      <td class="chart-47">5<br>9<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">4<br>5<br>8</td>
      <td class="chart-10">3<br>3<br>5</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>6<br>9</td>
      <td class="chart-67">7<br>9<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">2<br>5<br>0</td>
   </tr>
   <tr>
      <td>05-12-2022 <br> To <br> 11-12-2022</td>
      <td class="chart-84">1<br>3<br>4</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">6<br>8<br>0</td>
      <td class="chart-63">4<br>4<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">3<br>4<br>6</td>
      <td class="chart-04">4<br>7<br>9</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>5<br>8</td>
      <td class="chart-42">3<br>4<br>7</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
      <td class="chart-30">3<br>3<br>7</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>9<br>0</td>
      <td class="chart-32">1<br>5<br>7</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">2<br>3<br>7</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>12-12-2022 <br> To <br> 18-12-2022</td>
      <td class="chart-26">1<br>2<br>9</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>7<br>8</td>
      <td class="chart-97">4<br>5<br>0</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">3<br>5<br>9</td>
      <td class="chart-10">1<br>3<br>7</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>6<br>9</td>
      <td class="chart-19">1<br>2<br>8</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">2<br>8<br>9</td>
      <td class="chart-41">5<br>9<br>0</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">2<br>4<br>5</td>
      <td class="chart-95">4<br>6<br>9</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">2<br>5<br>8</td>
      <td class="chart-39">1<br>2<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>5<br>0</td>
   </tr>
   <tr>
      <td>19-12-2022 <br> To <br> 25-12-2022</td>
      <td class="chart-61">3<br>6<br>7</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>2<br>7</td>
      <td class="chart-65">2<br>6<br>8</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>3<br>0</td>
      <td class="chart-28">2<br>3<br>7</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">4<br>4<br>0</td>
      <td class="chart-15">3<br>8<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">1<br>2<br>2</td>
      <td class="chart-85">4<br>6<br>8</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">7<br>8<br>0</td>
      <td class="chart-27">4<br>8<br>0</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">5<br>6<br>6</td>
      <td class="chart-85">3<br>5<br>0</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">3<br>5<br>7</td>
   </tr>
   <tr>
      <td>26-12-2022 <br> To <br> 01-01-2023</td>
      <td class="chart-67">2<br>4<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">4<br>5<br>8</td>
      <td class="chart-01">6<br>7<br>7</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">5<br>7<br>9</td>
      <td class="chart-69">3<br>6<br>7</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">2<br>3<br>4</td>
      <td class="chart-46">2<br>4<br>8</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">4<br>6<br>6</td>
      <td class="chart-00">3<br>7<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">6<br>6<br>8</td>
      <td class="chart-34">1<br>5<br>7</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>5<br>8</td>
      <td class="chart-80">3<br>6<br>9</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">2<br>8<br>0</td>
   </tr>
   <tr>
      <td>02-01-2023 <br> To <br> 08-01-2023</td>
      <td class="chart-61">3<br>4<br>9</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>3<br>6</td>
      <td class="chart-30">1<br>3<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>5<br>0</td>
      <td class="chart-01">4<br>7<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">4<br>7<br>0</td>
      <td class="chart-08">1<br>9<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">4<br>6<br>8</td>
      <td class="chart-77">5<br>6<br>6</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">3<br>6<br>8</td>
      <td class="chart-84">1<br>7<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">5<br>9<br>0</td>
      <td class="chart-84">8<br>0<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">2<br>5<br>7</td>
   </tr>
   <tr>
      <td>09-01-2023 <br> To <br> 15-01-2023</td>
      <td class="chart-56">4<br>5<br>6</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">7<br>9<br>0</td>
      <td class="chart-12">4<br>7<br>0</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">6<br>7<br>9</td>
      <td class="chart-88">9<br>9<br>0</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">5<br>6<br>7</td>
      <td class="chart-07">3<br>7<br>0</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">3<br>6<br>8</td>
      <td class="chart-08">6<br>7<br>7</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">3<br>6<br>9</td>
      <td class="chart-74">4<br>6<br>7</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">2<br>2<br>0</td>
      <td class="chart-61">3<br>6<br>7</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">5<br>7<br>9</td>
   </tr>
   <tr>
      <td>16-01-2023 <br> To <br> 22-01-2023</td>
      <td class="chart-21">2<br>3<br>7</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">3<br>8<br>0</td>
      <td class="chart-67">8<br>9<br>9</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>7<br>9</td>
      <td class="chart-28">6<br>7<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>3<br>4</td>
      <td class="chart-63">2<br>4<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">2<br>5<br>6</td>
      <td class="chart-49">5<br>9<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">2<br>7<br>0</td>
      <td class="chart-64">2<br>5<br>9</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">1<br>4<br>9</td>
      <td class="chart-96">1<br>3<br>5</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">7<br>9<br>0</td>
   </tr>
   <tr>
      <td>23-01-2023 <br> To <br> 29-01-2023</td>
      <td class="chart-34">6<br>7<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">3<br>5<br>6</td>
      <td class="chart-91">2<br>2<br>5</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">1<br>3<br>7</td>
      <td class="chart-11">1<br>0<br>0</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">2<br>9<br>0</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-36">1<br>2<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">5<br>5<br>6</td>
      <td class="chart-30">6<br>8<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">3<br>7<br>0</td>
      <td class="chart-01">5<br>6<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>0<br>0</td>
   </tr>
   <tr>
      <td>30-01-2023 <br> To <br> 05-02-2023</td>
      <td class="chart-78">1<br>7<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">5<br>6<br>7</td>
      <td class="chart-36">1<br>4<br>8</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">7<br>9<br>0</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>9<br>0</td>
      <td class="chart-30">3<br>4<br>6</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>3<br>6</td>
      <td class="chart-12">1<br>2<br>8</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">3<br>9<br>0</td>
      <td class="chart-61">1<br>7<br>8</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>3<br>6</td>
      <td class="chart-69">2<br>5<br>9</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">5<br>7<br>7</td>
   </tr>
   <tr>
      <td>06-02-2023 <br> To <br> 12-02-2023</td>
      <td class="chart-19">6<br>7<br>8</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>9<br>9</td>
      <td class="chart-34">1<br>6<br>6</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">7<br>8<br>9</td>
      <td class="chart-54">7<br>8<br>0</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">2<br>2<br>0</td>
      <td class="chart-52">1<br>5<br>9</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">5<br>7<br>0</td>
      <td class="chart-24">4<br>8<br>0</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">6<br>8<br>0</td>
      <td class="chart-38">1<br>2<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>3<br>4</td>
      <td class="chart-83">3<br>6<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>5<br>7</td>
   </tr>
   <tr>
      <td>13-02-2023 <br> To <br> 19-02-2023</td>
      <td class="chart-55">3<br>4<br>8</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>6<br>8</td>
      <td class="chart-00">1<br>3<br>6</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>4<br>5</td>
      <td class="chart-35">1<br>2<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">2<br>5<br>8</td>
      <td class="chart-57">1<br>4<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">4<br>5<br>8</td>
      <td class="chart-96">3<br>6<br>0</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">3<br>5<br>8</td>
      <td class="chart-72">4<br>4<br>9</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">7<br>7<br>8</td>
      <td class="chart-86">2<br>8<br>8</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">3<br>6<br>7</td>
   </tr>
   <tr>
      <td>20-02-2023 <br> To <br> 26-02-2023</td>
      <td class="chart-20">6<br>7<br>9</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">2<br>8<br>0</td>
      <td class="chart-31">1<br>5<br>7</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">2<br>3<br>6</td>
      <td class="chart-71">8<br>9<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">2<br>3<br>6</td>
      <td class="chart-15">1<br>4<br>6</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">7<br>8<br>0</td>
      <td class="chart-86">3<br>5<br>0</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">2<br>6<br>8</td>
      <td class="chart-90">6<br>6<br>7</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>5<br>0</td>
      <td class="chart-61">1<br>7<br>8</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>4<br>5</td>
   </tr>
   <tr>
      <td>27-02-2023 <br> To <br> 05-03-2023</td>
      <td class="chart-97">2<br>8<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">4<br>6<br>7</td>
      <td class="chart-70">1<br>2<br>4</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>1<br>8</td>
      <td class="chart-44">2<br>6<br>6</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">1<br>4<br>9</td>
      <td class="chart-18">1<br>2<br>8</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">3<br>7<br>8</td>
      <td class="chart-95">4<br>7<br>8</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">6<br>9<br>0</td>
      <td class="chart-70">2<br>6<br>9</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">5<br>7<br>8</td>
      <td class="chart-73">1<br>3<br>3</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">1<br>4<br>8</td>
   </tr>
   <tr>
      <td>06-03-2023 <br> To <br> 12-03-2023</td>
      <td class="chart-80">5<br>6<br>7</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">3<br>7<br>0</td>
      <td class="chart-85">2<br>2<br>4</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">2<br>5<br>8</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-46">3<br>5<br>6</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">4<br>5<br>7</td>
      <td class="chart-59">6<br>9<br>0</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">2<br>3<br>4</td>
      <td class="chart-67">3<br>5<br>8</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">4<br>6<br>7</td>
      <td class="chart-92">4<br>6<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">5<br>8<br>9</td>
   </tr>
   <tr>
      <td>13-03-2023 <br> To <br> 19-03-2023</td>
      <td class="chart-32">2<br>2<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">4<br>8<br>0</td>
      <td class="chart-82">5<br>6<br>7</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-86">5<br>6<br>7</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">7<br>9<br>0</td>
      <td class="chart-25">1<br>2<br>9</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">2<br>4<br>9</td>
      <td class="chart-22">2<br>5<br>5</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">3<br>9<br>0</td>
      <td class="chart-16">2<br>3<br>6</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">1<br>5<br>0</td>
      <td class="chart-68">6<br>0<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">2<br>8<br>8</td>
   </tr>
   <tr>
      <td>20-03-2023 <br> To <br> 26-03-2023</td>
      <td class="chart-63">1<br>7<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">5<br>8<br>0</td>
      <td class="chart-30">6<br>8<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>2<br>7</td>
      <td class="chart-52">1<br>7<br>7</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">4<br>8<br>0</td>
      <td class="chart-55">2<br>3<br>0</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">6<br>9<br>0</td>
      <td class="chart-03">5<br>6<br>9</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>3<br>9</td>
      <td class="chart-70">2<br>7<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>3<br>6</td>
      <td class="chart-82">3<br>5<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">5<br>7<br>0</td>
   </tr>
   <tr>
      <td>27-03-2023 <br> To <br> 02-04-2023</td>
      <td class="chart-72">1<br>2<br>4</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">5<br>8<br>9</td>
      <td class="chart-80">1<br>7<br>0</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">1<br>1<br>8</td>
      <td class="chart-61">1<br>5<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">1<br>3<br>7</td>
      <td class="chart-99">3<br>7<br>9</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">4<br>7<br>8</td>
      <td class="chart-83">3<br>6<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>4<br>7</td>
      <td class="chart-52">2<br>3<br>0</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">2<br>0<br>0</td>
      <td class="chart-44">2<br>5<br>7</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">1<br>6<br>7</td>
   </tr>
   <tr>
      <td>03-04-2023 <br> To <br> 09-04-2023</td>
      <td class="chart-92">5<br>6<br>8</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">6<br>7<br>9</td>
      <td class="chart-81">4<br>5<br>9</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>3<br>7</td>
      <td class="chart-93">2<br>7<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>6<br>6</td>
      <td class="chart-61">2<br>4<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">3<br>8<br>0</td>
      <td class="chart-97">3<br>7<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">3<br>5<br>9</td>
      <td class="chart-96">4<br>7<br>8</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">7<br>9<br>0</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>1<br>8</td>
   </tr>
   <tr>
      <td>10-04-2023 <br> To <br> 16-04-2023</td>
      <td class="chart-19">1<br>4<br>6</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>3<br>5</td>
      <td class="chart-13">4<br>8<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">4<br>9<br>0</td>
      <td class="chart-68">7<br>9<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">3<br>6<br>9</td>
      <td class="chart-53">4<br>5<br>6</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>4<br>8</td>
      <td class="chart-20">3<br>3<br>6</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>9<br>0</td>
      <td class="chart-16">5<br>6<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">7<br>9<br>0</td>
      <td class="chart-23">3<br>4<br>5</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">6<br>8<br>9</td>
   </tr>
   <tr>
      <td>17-04-2023 <br> To <br> 23-04-2023</td>
      <td class="chart-38">2<br>4<br>7</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">2<br>7<br>9</td>
      <td class="chart-98">2<br>7<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">4<br>6<br>8</td>
      <td class="chart-16">1<br>3<br>7</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">2<br>6<br>8</td>
      <td class="chart-32">3<br>0<br>0</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">3<br>4<br>5</td>
      <td class="chart-91">4<br>6<br>9</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">5<br>7<br>9</td>
      <td class="chart-58">1<br>5<br>9</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">1<br>7<br>0</td>
      <td class="chart-17">4<br>7<br>0</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">1<br>2<br>4</td>
   </tr>
   <tr>
      <td>24-04-2023 <br> To <br> 30-04-2023</td>
      <td class="chart-58">7<br>8<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">5<br>6<br>7</td>
      <td class="chart-92">1<br>8<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">5<br>8<br>9</td>
      <td class="chart-95">4<br>5<br>0</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">1<br>5<br>9</td>
      <td class="chart-40">3<br>5<br>6</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">4<br>6<br>0</td>
      <td class="chart-96">3<br>6<br>0</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">6<br>0<br>0</td>
      <td class="chart-44">1<br>6<br>7</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">3<br>5<br>6</td>
      <td class="chart-31">7<br>7<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">6<br>7<br>8</td>
   </tr>
   <tr>
      <td>01-05-2023 <br> To <br> 07-05-2023</td>
      <td class="chart-03">3<br>8<br>9</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>4<br>8</td>
      <td class="chart-53">3<br>6<br>6</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">3<br>4<br>6</td>
      <td class="chart-60">7<br>9<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">5<br>7<br>8</td>
      <td class="chart-37">3<br>4<br>6</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">2<br>5<br>0</td>
      <td class="chart-69">6<br>0<br>0</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">1<br>9<br>9</td>
      <td class="chart-86">4<br>5<br>9</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>2<br>3</td>
      <td class="chart-55">2<br>4<br>9</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>4<br>0</td>
   </tr>
   <tr>
      <td>08-05-2023 <br> To <br> 14-05-2023</td>
      <td class="chart-61">2<br>6<br>8</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">6<br>6<br>9</td>
      <td class="chart-82">1<br>8<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-27">2<br>3<br>7</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">8<br>9<br>0</td>
      <td class="chart-10">2<br>3<br>6</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">3<br>7<br>0</td>
      <td class="chart-04">1<br>9<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>4<br>9</td>
      <td class="chart-62">7<br>9<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">5<br>8<br>9</td>
      <td class="chart-44">6<br>8<br>0</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">3<br>5<br>6</td>
   </tr>
   <tr>
      <td>15-05-2023 <br> To <br> 21-05-2023</td>
      <td class="chart-51">2<br>6<br>7</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>4<br>5</td>
      <td class="chart-54">7<br>8<br>0</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>4<br>9</td>
      <td class="chart-98">3<br>7<br>9</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">1<br>3<br>4</td>
      <td class="chart-28">3<br>9<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">4<br>5<br>9</td>
      <td class="chart-52">7<br>8<br>0</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">6<br>7<br>9</td>
      <td class="chart-11">1<br>2<br>8</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">2<br>3<br>6</td>
      <td class="chart-99">4<br>6<br>9</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">6<br>6<br>7</td>
   </tr>
   <tr>
      <td>22-05-2023 <br> To <br> 28-05-2023</td>
      <td class="chart-39">2<br>3<br>8</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">1<br>8<br>0</td>
      <td class="chart-86">1<br>2<br>5</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">7<br>9<br>0</td>
      <td class="chart-87">4<br>6<br>8</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">7<br>0<br>0</td>
      <td class="chart-10">4<br>7<br>0</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>7<br>8</td>
      <td class="chart-56">4<br>5<br>6</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>5<br>0</td>
      <td class="chart-66">1<br>5<br>0</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">2<br>6<br>8</td>
      <td class="chart-82">2<br>2<br>4</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">3<br>4<br>5</td>
   </tr>
   <tr>
      <td>29-05-2023 <br> To <br> 04-06-2023</td>
      <td class="chart-99">5<br>6<br>8</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">1<br>8<br>0</td>
      <td class="chart-54">3<br>5<br>7</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">6<br>8<br>0</td>
      <td class="chart-01">1<br>4<br>5</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">6<br>7<br>8</td>
      <td class="chart-88">5<br>6<br>7</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">1<br>7<br>9</td>
      <td class="chart-61">4<br>5<br>7</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">3<br>8<br>0</td>
      <td class="chart-67">2<br>5<br>9</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>7<br>9</td>
      <td class="chart-82">5<br>5<br>8</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>0<br>0</td>
   </tr>
   <tr>
      <td>05-06-2023 <br> To <br> 11-06-2023</td>
      <td class="chart-09">6<br>7<br>7</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>4<br>4</td>
      <td class="chart-46">5<br>9<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">7<br>9<br>0</td>
      <td class="chart-50">1<br>2<br>2</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">5<br>6<br>9</td>
      <td class="chart-40">6<br>9<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>3<br>6</td>
      <td class="chart-49">7<br>7<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">3<br>6<br>0</td>
      <td class="chart-97">4<br>7<br>8</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">3<br>5<br>9</td>
      <td class="chart-88">3<br>6<br>9</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">1<br>8<br>9</td>
   </tr>
   <tr>
      <td>12-06-2023 <br> To <br> 18-06-2023</td>
      <td class="chart-43">7<br>8<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">5<br>8<br>0</td>
      <td class="chart-81">4<br>5<br>9</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">4<br>7<br>0</td>
      <td class="chart-56">7<br>8<br>0</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>7<br>8</td>
      <td class="chart-15">2<br>3<br>6</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">2<br>4<br>9</td>
      <td class="chart-34">6<br>7<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">2<br>3<br>9</td>
      <td class="chart-57">1<br>5<br>9</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">5<br>5<br>7</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">3<br>6<br>0</td>
   </tr>
   <tr>
      <td>19-06-2023 <br> To <br> 25-06-2023</td>
      <td class="chart-28">5<br>7<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">5<br>6<br>7</td>
      <td class="chart-68">7<br>9<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">1<br>7<br>0</td>
      <td class="chart-03">4<br>6<br>0</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">6<br>7<br>0</td>
      <td class="chart-41">6<br>8<br>0</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">6<br>7<br>8</td>
      <td class="chart-27">2<br>3<br>7</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">8<br>9<br>0</td>
      <td class="chart-41">7<br>8<br>9</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>7<br>9</td>
      <td class="chart-68">2<br>6<br>8</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">4<br>6<br>8</td>
   </tr>
   <tr>
      <td>26-06-2023 <br> To <br> 02-07-2023</td>
      <td class="chart-11">1<br>3<br>7</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">2<br>4<br>5</td>
      <td class="chart-32">6<br>8<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">5<br>7<br>0</td>
      <td class="chart-74">8<br>9<br>0</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">2<br>5<br>7</td>
      <td class="chart-80">5<br>6<br>7</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">5<br>7<br>8</td>
      <td class="chart-71">7<br>0<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">1<br>3<br>7</td>
      <td class="chart-38">1<br>3<br>9</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>6<br>7</td>
      <td class="chart-78">1<br>7<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">3<br>6<br>9</td>
   </tr>
   <tr>
      <td>03-07-2023 <br> To <br> 09-07-2023</td>
      <td class="chart-51">1<br>4<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">1<br>2<br>8</td>
      <td class="chart-40">7<br>7<br>0</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">5<br>6<br>9</td>
      <td class="chart-57">6<br>9<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">3<br>4<br>0</td>
      <td class="chart-69">4<br>5<br>7</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">2<br>7<br>0</td>
      <td class="chart-12">4<br>8<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">4<br>8<br>0</td>
      <td class="chart-08">4<br>7<br>9</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>3<br>4</td>
      <td class="chart-08">2<br>8<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">3<br>6<br>9</td>
   </tr>
   <tr>
      <td>10-07-2023 <br> To <br> 16-07-2023</td>
      <td class="chart-21">6<br>8<br>8</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">5<br>7<br>9</td>
      <td class="chart-37">2<br>2<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">3<br>5<br>9</td>
      <td class="chart-94">5<br>6<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">2<br>6<br>6</td>
      <td class="chart-96">6<br>6<br>7</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">3<br>6<br>7</td>
      <td class="chart-29">3<br>9<br>0</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>3<br>5</td>
      <td class="chart-45">2<br>5<br>7</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">7<br>8<br>0</td>
      <td class="chart-59">1<br>5<br>9</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">3<br>6<br>0</td>
   </tr>
   <tr>
      <td>17-07-2023 <br> To <br> 23-07-2023</td>
      <td class="chart-06">5<br>6<br>9</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>5<br>0</td>
      <td class="chart-94">2<br>7<br>0</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>6<br>7</td>
      <td class="chart-41">3<br>4<br>6</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">3<br>3<br>5</td>
      <td class="chart-83">1<br>2<br>5</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>4<br>7</td>
      <td class="chart-38">4<br>4<br>5</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>6<br>7</td>
      <td class="chart-83">2<br>7<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>7<br>0</td>
      <td class="chart-15">4<br>7<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">1<br>4<br>0</td>
   </tr>
   <tr>
      <td>24-07-2023 <br> To <br> 30-07-2023</td>
      <td class="chart-62">3<br>4<br>9</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">5<br>7<br>0</td>
      <td class="chart-47">1<br>3<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>2<br>4</td>
      <td class="chart-26">6<br>7<br>9</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">2<br>5<br>9</td>
      <td class="chart-05">1<br>3<br>6</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">1<br>4<br>0</td>
      <td class="chart-89">3<br>7<br>8</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">5<br>6<br>8</td>
      <td class="chart-10">2<br>3<br>6</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">1<br>3<br>6</td>
      <td class="chart-54">5<br>0<br>0</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>5<br>8</td>
   </tr>
   <tr>
      <td>31-07-2023 <br> To <br> 06-08-2023</td>
      <td class="chart-51">2<br>3<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">4<br>8<br>9</td>
      <td class="chart-42">7<br>8<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>3<br>8</td>
      <td class="chart-08">1<br>9<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>7<br>0</td>
      <td class="chart-16">1<br>3<br>7</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">2<br>5<br>9</td>
      <td class="chart-89">1<br>2<br>5</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">1<br>3<br>5</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">2<br>5<br>9</td>
      <td class="chart-09">1<br>4<br>5</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">3<br>7<br>9</td>
   </tr>
   <tr>
      <td>07-08-2023 <br> To <br> 13-08-2023</td>
      <td class="chart-92">2<br>8<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>2<br>8</td>
      <td class="chart-03">5<br>6<br>9</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">1<br>5<br>7</td>
      <td class="chart-08">1<br>3<br>6</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">5<br>6<br>7</td>
      <td class="chart-66">2<br>4<br>0</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">1<br>6<br>9</td>
      <td class="chart-35">5<br>8<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">2<br>6<br>7</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-82">4<br>4<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">3<br>9<br>0</td>
   </tr>
   <tr>
      <td>14-08-2023 <br> To <br> 20-08-2023</td>
      <td class="chart-84">5<br>6<br>7</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">3<br>4<br>7</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-79">1<br>2<br>4</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">4<br>6<br>9</td>
      <td class="chart-83">1<br>2<br>5</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>7<br>0</td>
      <td class="chart-47">2<br>2<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">7<br>0<br>0</td>
      <td class="chart-30">1<br>5<br>7</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">4<br>7<br>9</td>
      <td class="chart-95">2<br>7<br>0</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">1<br>7<br>7</td>
   </tr>
   <tr>
      <td>21-08-2023 <br> To <br> 27-08-2023</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>2<br>8</td>
      <td class="chart-60">1<br>7<br>8</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>9<br>0</td>
      <td class="chart-78">3<br>7<br>7</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>8<br>9</td>
      <td class="chart-64">1<br>2<br>3</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">1<br>3<br>0</td>
      <td class="chart-41">6<br>8<br>0</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">3<br>8<br>0</td>
      <td class="chart-32">1<br>5<br>7</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>5<br>6</td>
      <td class="chart-13">5<br>7<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">1<br>4<br>8</td>
   </tr>
   <tr>
      <td>28-08-2023 <br> To <br> 03-09-2023</td>
      <td class="chart-92">4<br>6<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>4<br>7</td>
      <td class="chart-71">3<br>4<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">2<br>3<br>6</td>
      <td class="chart-81">1<br>7<br>0</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>2<br>8</td>
      <td class="chart-51">2<br>3<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>4<br>5</td>
      <td class="chart-64">1<br>7<br>8</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">6<br>9<br>9</td>
      <td class="chart-06">1<br>3<br>6</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">4<br>5<br>7</td>
      <td class="chart-55">2<br>6<br>7</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>5<br>9</td>
   </tr>
   <tr>
      <td>04-09-2023 <br> To <br> 10-09-2023</td>
      <td class="chart-42">3<br>4<br>7</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
      <td class="chart-39">1<br>2<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">2<br>3<br>4</td>
      <td class="chart-37">1<br>4<br>8</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">2<br>5<br>0</td>
      <td class="chart-97">2<br>8<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">4<br>6<br>7</td>
      <td class="chart-47">5<br>9<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">4<br>5<br>8</td>
      <td class="chart-08">3<br>7<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">4<br>6<br>8</td>
      <td class="chart-27">7<br>7<br>8</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>8<br>8</td>
   </tr>
   <tr>
      <td>11-09-2023 <br> To <br> 17-09-2023</td>
      <td class="chart-30">1<br>2<br>0</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>7<br>8</td>
      <td class="chart-53">2<br>6<br>7</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>3<br>9</td>
      <td class="chart-38">2<br>4<br>7</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">3<br>7<br>8</td>
      <td class="chart-70">3<br>5<br>9</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>3<br>6</td>
      <td class="chart-90">4<br>5<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">2<br>2<br>6</td>
      <td class="chart-11">1<br>3<br>7</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>1<br>9</td>
      <td class="chart-30">2<br>5<br>6</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>4<br>5</td>
   </tr>
   <tr>
      <td>18-09-2023 <br> To <br> 24-09-2023</td>
      <td class="chart-60">7<br>9<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">2<br>3<br>5</td>
      <td class="chart-92">5<br>6<br>8</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">5<br>7<br>0</td>
      <td class="chart-30">6<br>8<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>4<br>5</td>
      <td class="chart-97">2<br>8<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">4<br>6<br>7</td>
      <td class="chart-61">4<br>6<br>6</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">6<br>7<br>8</td>
      <td class="chart-35">2<br>5<br>6</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">3<br>3<br>9</td>
      <td class="chart-73">2<br>7<br>8</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>8<br>0</td>
   </tr>
   <tr>
      <td>25-09-2023 <br> To <br> 01-10-2023</td>
      <td class="chart-51">6<br>9<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">5<br>7<br>9</td>
      <td class="chart-91">4<br>5<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">1<br>3<br>7</td>
      <td class="chart-02">5<br>6<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">3<br>9<br>0</td>
      <td class="chart-67">1<br>2<br>3</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>2<br>4</td>
      <td class="chart-40">7<br>7<br>0</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">3<br>8<br>9</td>
      <td class="chart-99">5<br>6<br>8</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">4<br>7<br>8</td>
      <td class="chart-40">1<br>6<br>7</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">2<br>2<br>6</td>
   </tr>
   <tr>
      <td>02-10-2023 <br> To <br> 08-10-2023</td>
      <td class="chart-67">2<br>6<br>8</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">8<br>9<br>0</td>
      <td class="chart-64">1<br>2<br>3</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">2<br>5<br>7</td>
      <td class="chart-83">4<br>5<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">3<br>4<br>6</td>
      <td class="chart-27">1<br>1<br>0</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">7<br>0<br>0</td>
      <td class="chart-75">1<br>7<br>9</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">2<br>5<br>8</td>
      <td class="chart-11">5<br>7<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>4<br>6</td>
      <td class="chart-35">1<br>2<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">7<br>8<br>0</td>
   </tr>
   <tr>
      <td>09-10-2023 <br> To <br> 15-10-2023</td>
      <td class="chart-63">1<br>7<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">4<br>9<br>0</td>
      <td class="chart-07">3<br>7<br>0</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">3<br>7<br>7</td>
      <td class="chart-83">4<br>6<br>8</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">7<br>8<br>8</td>
      <td class="chart-24">3<br>4<br>5</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">2<br>3<br>9</td>
      <td class="chart-21">1<br>2<br>9</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">3<br>8<br>0</td>
      <td class="chart-85">3<br>6<br>9</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">2<br>3<br>0</td>
      <td class="chart-44">1<br>5<br>8</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">2<br>4<br>8</td>
   </tr>
   <tr>
      <td>16-10-2023 <br> To <br> 22-10-2023</td>
      <td class="chart-28">5<br>8<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>2<br>5</td>
      <td class="chart-15">3<br>4<br>4</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">7<br>8<br>0</td>
      <td class="chart-88">2<br>6<br>0</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">1<br>8<br>9</td>
      <td class="chart-21">3<br>9<br>0</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">5<br>8<br>8</td>
      <td class="chart-43">6<br>8<br>0</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">2<br>3<br>8</td>
      <td class="chart-38">1<br>2<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>8<br>9</td>
      <td class="chart-90">2<br>7<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">1<br>1<br>8</td>
   </tr>
   <tr>
      <td>23-10-2023 <br> To <br> 29-10-2023</td>
      <td class="chart-55">2<br>4<br>9</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>6<br>8</td>
      <td class="chart-72">3<br>6<br>8</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">6<br>7<br>9</td>
      <td class="chart-21">1<br>3<br>8</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">5<br>7<br>9</td>
      <td class="chart-57">1<br>4<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">8<br>9<br>0</td>
      <td class="chart-78">3<br>5<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>8<br>9</td>
      <td class="chart-16">5<br>7<br>9</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">1<br>2<br>3</td>
      <td class="chart-41">3<br>4<br>7</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">1<br>1<br>9</td>
   </tr>
   <tr>
      <td>30-10-2023 <br> To <br> 05-11-2023</td>
      <td class="chart-98">3<br>6<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">4<br>6<br>8</td>
      <td class="chart-53">1<br>4<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>2<br>0</td>
      <td class="chart-91">3<br>6<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">5<br>6<br>0</td>
      <td class="chart-45">1<br>5<br>8</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">1<br>4<br>0</td>
      <td class="chart-00">1<br>1<br>8</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">2<br>3<br>5</td>
      <td class="chart-20">5<br>7<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">4<br>8<br>8</td>
      <td class="chart-77">8<br>9<br>0</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">1<br>2<br>4</td>
   </tr>
   <tr>
      <td>06-11-2023 <br> To <br> 12-11-2023</td>
      <td class="chart-04">1<br>2<br>7</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">7<br>8<br>9</td>
      <td class="chart-94">5<br>6<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>6<br>7</td>
      <td class="chart-68">4<br>5<br>7</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">3<br>5<br>0</td>
      <td class="chart-83">2<br>7<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">3<br>5<br>5</td>
      <td class="chart-83">4<br>5<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>5<br>6</td>
      <td class="chart-54">7<br>9<br>9</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>4<br>9</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>13-11-2023 <br> To <br> 19-11-2023</td>
      <td class="chart-51">1<br>6<br>8</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">3<br>9<br>9</td>
      <td class="chart-33">3<br>0<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">7<br>7<br>9</td>
      <td class="chart-93">5<br>7<br>7</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">6<br>7<br>0</td>
      <td class="chart-33">5<br>8<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">1<br>3<br>9</td>
      <td class="chart-69">8<br>8<br>0</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">3<br>6<br>0</td>
      <td class="chart-49">3<br>4<br>7</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">9<br>0<br>0</td>
      <td class="chart-78">4<br>6<br>7</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">3<br>7<br>8</td>
   </tr>
   <tr>
      <td>20-11-2023 <br> To <br> 26-11-2023</td>
      <td class="chart-19">6<br>6<br>9</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>2<br>6</td>
      <td class="chart-51">7<br>8<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>3<br>6</td>
      <td class="chart-27">6<br>7<br>9</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>2<br>4</td>
      <td class="chart-10">5<br>7<br>9</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">3<br>7<br>0</td>
      <td class="chart-21">1<br>3<br>8</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">1<br>2<br>8</td>
      <td class="chart-49">1<br>5<br>8</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>2<br>6</td>
      <td class="chart-44">1<br>3<br>0</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">6<br>8<br>0</td>
   </tr>
   <tr>
      <td>27-11-2023 <br> To <br> 03-12-2023</td>
      <td class="chart-09">4<br>6<br>0</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>3<br>5</td>
      <td class="chart-12">2<br>9<br>0</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>3<br>7</td>
      <td class="chart-27">1<br>3<br>8</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>2<br>4</td>
      <td class="chart-32">1<br>4<br>8</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">6<br>7<br>9</td>
      <td class="chart-17">1<br>3<br>7</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">1<br>2<br>4</td>
      <td class="chart-60">7<br>9<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>2<br>7</td>
      <td class="chart-61">1<br>5<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>4<br>5</td>
   </tr>
   <tr>
      <td>04-12-2023 <br> To <br> 10-12-2023</td>
      <td class="chart-00">1<br>9<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-33">1<br>5<br>7</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">1<br>4<br>8</td>
      <td class="chart-06">2<br>8<br>0</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">7<br>9<br>0</td>
      <td class="chart-83">2<br>6<br>0</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>7<br>0</td>
      <td class="chart-39">1<br>5<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">2<br>7<br>0</td>
      <td class="chart-28">1<br>4<br>7</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">2<br>6<br>0</td>
      <td class="chart-54">2<br>5<br>8</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>5<br>8</td>
   </tr>
   <tr>
      <td>11-12-2023 <br> To <br> 17-12-2023</td>
      <td class="chart-81">1<br>2<br>5</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">2<br>9<br>0</td>
      <td class="chart-25">1<br>5<br>6</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">7<br>8<br>0</td>
      <td class="chart-06">1<br>4<br>5</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>2<br>3</td>
      <td class="chart-25">1<br>4<br>7</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>4<br>0</td>
      <td class="chart-62">1<br>5<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">1<br>5<br>6</td>
      <td class="chart-95">1<br>2<br>6</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">1<br>4<br>0</td>
      <td class="chart-29">3<br>4<br>5</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>2<br>6</td>
   </tr>
   <tr>
      <td>18-12-2023 <br> To <br> 24-12-2023</td>
      <td class="chart-71">8<br>9<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">6<br>7<br>8</td>
      <td class="chart-68">1<br>5<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">1<br>7<br>0</td>
      <td class="chart-03">5<br>6<br>9</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">6<br>7<br>0</td>
      <td class="chart-92">4<br>5<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>4<br>6</td>
      <td class="chart-72">1<br>2<br>4</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">5<br>7<br>0</td>
      <td class="chart-48">3<br>5<br>6</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">3<br>7<br>8</td>
      <td class="chart-87">9<br>9<br>0</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">7<br>0<br>0</td>
   </tr>
   <tr>
      <td>25-12-2023 <br> To <br> 31-12-2023</td>
      <td class="chart-20">3<br>9<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>3<br>6</td>
      <td class="chart-69">1<br>5<br>0</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">4<br>5<br>0</td>
      <td class="chart-02">5<br>7<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">5<br>7<br>0</td>
      <td class="chart-84">1<br>2<br>5</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>3<br>0</td>
      <td class="chart-06">1<br>9<br>0</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">1<br>2<br>3</td>
      <td class="chart-31">6<br>7<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">1<br>2<br>8</td>
      <td class="chart-86">3<br>5<br>0</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">8<br>8<br>0</td>
   </tr>
   <tr>
      <td>01-01-2024 <br> To <br> 07-01-2024</td>
      <td class="chart-66">4<br>5<br>7</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-45">6<br>8<br>0</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>3<br>0</td>
      <td class="chart-82">1<br>3<br>4</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>2<br>9</td>
      <td class="chart-10">1<br>4<br>6</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>6<br>9</td>
      <td class="chart-28">5<br>8<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>2<br>5</td>
      <td class="chart-78">1<br>7<br>9</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>7<br>0</td>
      <td class="chart-28">1<br>4<br>7</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">3<br>6<br>9</td>
   </tr>
   <tr>
      <td>08-01-2024 <br> To <br> 14-01-2024</td>
      <td class="chart-33">1<br>2<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">5<br>8<br>0</td>
      <td class="chart-59">1<br>5<br>9</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">1<br>8<br>0</td>
      <td class="chart-54">7<br>8<br>0</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">6<br>8<br>0</td>
      <td class="chart-48">5<br>9<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">1<br>7<br>0</td>
      <td class="chart-00">4<br>6<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>9<br>0</td>
      <td class="chart-70">8<br>9<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">3<br>7<br>0</td>
      <td class="chart-04">2<br>3<br>5</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">6<br>8<br>0</td>
   </tr>
   <tr>
      <td>15-01-2024 <br> To <br> 21-01-2024</td>
      <td class="chart-65">1<br>5<br>0</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">1<br>4<br>0</td>
      <td class="chart-85">1<br>2<br>5</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">7<br>8<br>0</td>
      <td class="chart-20">3<br>4<br>5</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">2<br>8<br>0</td>
      <td class="chart-18">1<br>3<br>7</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">5<br>6<br>7</td>
      <td class="chart-59">1<br>4<br>0</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">1<br>2<br>6</td>
      <td class="chart-82">1<br>8<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">3<br>9<br>0</td>
      <td class="chart-69">2<br>4<br>0</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">2<br>7<br>0</td>
   </tr>
   <tr>
      <td>22-01-2024 <br> To <br> 28-01-2024</td>
      <td class="chart-31">1<br>3<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">1<br>3<br>7</td>
      <td class="chart-55">4<br>5<br>6</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">2<br>3<br>0</td>
      <td class="chart-12">2<br>9<br>0</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>4<br>6</td>
      <td class="chart-48">2<br>2<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">2<br>6<br>0</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-58">6<br>9<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">3<br>7<br>8</td>
      <td class="chart-73">1<br>6<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>9<br>9</td>
   </tr>
   <tr>
      <td>29-01-2024 <br> To <br> 04-02-2024</td>
      <td class="chart-32">4<br>9<br>0</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">6<br>7<br>9</td>
      <td class="chart-15">5<br>6<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">2<br>5<br>8</td>
      <td class="chart-28">1<br>3<br>8</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">1<br>3<br>4</td>
      <td class="chart-86">1<br>3<br>4</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>2<br>3</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">4<br>6<br>0</td>
      <td class="chart-27">3<br>9<br>0</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">2<br>2<br>3</td>
      <td class="chart-96">2<br>3<br>4</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">4<br>4<br>8</td>
   </tr>
   <tr>
      <td>05-02-2024 <br> To <br> 11-02-2024</td>
      <td class="chart-32">1<br>3<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">2<br>3<br>7</td>
      <td class="chart-10">4<br>8<br>9</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">1<br>3<br>6</td>
      <td class="chart-12">3<br>3<br>5</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>4<br>6</td>
      <td class="chart-99">2<br>7<br>0</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">3<br>6<br>0</td>
      <td class="chart-25">1<br>5<br>6</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">7<br>8<br>0</td>
      <td class="chart-40">2<br>5<br>7</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">3<br>7<br>0</td>
      <td class="chart-42">1<br>5<br>8</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">5<br>8<br>9</td>
   </tr>
   <tr>
      <td>12-02-2024 <br> To <br> 18-02-2024</td>
      <td class="chart-69">1<br>7<br>8</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">5<br>6<br>8</td>
      <td class="chart-32">1<br>4<br>8</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">6<br>7<br>9</td>
      <td class="chart-85">3<br>5<br>0</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">1<br>4<br>0</td>
      <td class="chart-67">7<br>9<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">2<br>5<br>0</td>
      <td class="chart-80">1<br>2<br>5</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">5<br>7<br>8</td>
      <td class="chart-59">3<br>4<br>8</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">4<br>7<br>8</td>
      <td class="chart-97">3<br>6<br>0</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">2<br>5<br>0</td>
   </tr>
   <tr>
      <td>19-02-2024 <br> To <br> 25-02-2024</td>
      <td class="chart-47">3<br>5<br>6</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">4<br>5<br>8</td>
      <td class="chart-23">6<br>6<br>0</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">6<br>7<br>0</td>
      <td class="chart-99">3<br>7<br>9</td>
      <td class="chart-bold chart-99">99</td>
      <td class="chart-99">4<br>5<br>0</td>
      <td class="chart-17">1<br>4<br>6</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">3<br>4<br>0</td>
      <td class="chart-48">1<br>3<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">4<br>5<br>9</td>
      <td class="chart-90">5<br>6<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>6<br>9</td>
      <td class="chart-00">4<br>6<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">6<br>7<br>7</td>
   </tr>
   <tr>
      <td>26-02-2024 <br> To <br> 03-03-2024</td>
      <td class="chart-80">5<br>6<br>7</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">2<br>8<br>0</td>
      <td class="chart-89">1<br>2<br>5</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">5<br>6<br>8</td>
      <td class="chart-74">5<br>5<br>7</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">7<br>8<br>9</td>
      <td class="chart-13">5<br>6<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">1<br>5<br>7</td>
      <td class="chart-19">4<br>7<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>1<br>7</td>
      <td class="chart-42">1<br>6<br>7</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>3<br>8</td>
      <td class="chart-35">7<br>8<br>8</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">5<br>0<br>0</td>
   </tr>
   <tr>
      <td>04-03-2024 <br> To <br> 10-03-2024</td>
      <td class="chart-88">4<br>6<br>8</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">1<br>7<br>0</td>
      <td class="chart-31">4<br>9<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">3<br>8<br>0</td>
      <td class="chart-18">1<br>4<br>6</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">3<br>6<br>9</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">2<br>8<br>9</td>
      <td class="chart-28">2<br>3<br>7</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">3<br>5<br>0</td>
      <td class="chart-10">6<br>7<br>8</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">5<br>7<br>8</td>
      <td class="chart-36">2<br>4<br>7</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">1<br>2<br>3</td>
   </tr>
   <tr>
      <td>11-03-2024 <br> To <br> 17-03-2024</td>
      <td class="chart-32">1<br>2<br>0</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">1<br>4<br>7</td>
      <td class="chart-90">2<br>7<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">1<br>9<br>0</td>
      <td class="chart-11">5<br>7<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>2<br>8</td>
      <td class="chart-79">4<br>6<br>7</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">1<br>8<br>0</td>
      <td class="chart-09">5<br>7<br>8</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">2<br>2<br>5</td>
      <td class="chart-85">1<br>8<br>9</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">7<br>8<br>0</td>
      <td class="chart-20">2<br>3<br>7</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>9<br>0</td>
   </tr>
   <tr>
      <td>18-03-2024 <br> To <br> 24-03-2024</td>
      <td class="chart-66">5<br>5<br>6</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">1<br>5<br>0</td>
      <td class="chart-13">1<br>3<br>7</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">1<br>5<br>7</td>
      <td class="chart-08">5<br>7<br>8</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">4<br>5<br>9</td>
      <td class="chart-74">1<br>7<br>9</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">2<br>3<br>9</td>
      <td class="chart-85">1<br>7<br>0</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">1<br>5<br>9</td>
      <td class="chart-40">1<br>4<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>9<br>0</td>
      <td class="chart-53">2<br>3<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">6<br>7<br>0</td>
   </tr>
   <tr>
      <td>25-03-2024 <br> To <br> 31-03-2024</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-22">1<br>3<br>8</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">4<br>8<br>0</td>
      <td class="chart-20">3<br>9<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>3<br>6</td>
      <td class="chart-09">5<br>7<br>8</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>3<br>5</td>
      <td class="chart-16">2<br>9<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">1<br>2<br>3</td>
      <td class="chart-58">6<br>9<br>0</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">5<br>6<br>7</td>
      <td class="chart-09">6<br>6<br>8</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>4<br>4</td>
   </tr>
   <tr>
      <td>01-04-2024 <br> To <br> 07-04-2024</td>
      <td class="chart-63">4<br>5<br>7</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>3<br>9</td>
      <td class="chart-58">2<br>4<br>9</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">2<br>6<br>0</td>
      <td class="chart-27">2<br>4<br>6</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">8<br>9<br>0</td>
      <td class="chart-35">6<br>7<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">1<br>5<br>9</td>
      <td class="chart-40">3<br>4<br>7</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">3<br>8<br>9</td>
      <td class="chart-14">4<br>8<br>9</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">7<br>8<br>9</td>
      <td class="chart-49">5<br>9<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">4<br>7<br>8</td>
   </tr>
   <tr>
      <td>08-04-2024 <br> To <br> 14-04-2024</td>
      <td class="chart-39">1<br>5<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">3<br>6<br>0</td>
      <td class="chart-44">6<br>8<br>0</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">2<br>2<br>0</td>
      <td class="chart-00">5<br>6<br>9</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">5<br>5<br>0</td>
      <td class="chart-24">6<br>7<br>9</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">2<br>5<br>7</td>
      <td class="chart-03">5<br>7<br>8</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">4<br>9<br>0</td>
      <td class="chart-27">1<br>4<br>7</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">4<br>6<br>7</td>
      <td class="chart-83">4<br>5<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>2<br>0</td>
   </tr>
   <tr>
      <td>15-04-2024 <br> To <br> 21-04-2024</td>
      <td class="chart-20">1<br>3<br>8</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">5<br>6<br>9</td>
      <td class="chart-89">5<br>6<br>7</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">1<br>2<br>6</td>
      <td class="chart-78">8<br>9<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">5<br>6<br>7</td>
      <td class="chart-90">2<br>3<br>4</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">3<br>8<br>9</td>
      <td class="chart-17">1<br>3<br>7</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">2<br>6<br>9</td>
      <td class="chart-26">2<br>4<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">2<br>5<br>9</td>
      <td class="chart-50">2<br>4<br>9</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>2<br>7</td>
   </tr>
   <tr>
      <td>22-04-2024 <br> To <br> 28-04-2024</td>
      <td class="chart-02">1<br>9<br>0</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">3<br>9<br>0</td>
      <td class="chart-90">5<br>6<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>7<br>8</td>
      <td class="chart-41">1<br>4<br>9</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>8<br>8</td>
      <td class="chart-13">2<br>4<br>5</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">6<br>8<br>9</td>
      <td class="chart-43">3<br>5<br>6</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">1<br>3<br>9</td>
      <td class="chart-02">4<br>6<br>0</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">3<br>4<br>5</td>
      <td class="chart-82">4<br>6<br>8</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>4<br>6</td>
   </tr>
   <tr>
      <td>29-04-2024 <br> To <br> 05-05-2024</td>
      <td class="chart-80">1<br>2<br>5</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">2<br>8<br>0</td>
      <td class="chart-43">1<br>3<br>0</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">1<br>4<br>8</td>
      <td class="chart-90">4<br>5<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>6<br>9</td>
      <td class="chart-97">4<br>7<br>8</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">1<br>2<br>4</td>
      <td class="chart-55">2<br>6<br>7</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>5<br>9</td>
      <td class="chart-96">1<br>8<br>0</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">2<br>4<br>0</td>
      <td class="chart-07">2<br>9<br>9</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">4<br>5<br>8</td>
   </tr>
   <tr>
      <td>06-05-2024 <br> To <br> 12-05-2024</td>
      <td class="chart-84">1<br>7<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>4<br>9</td>
      <td class="chart-86">3<br>7<br>8</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>7<br>8</td>
      <td class="chart-08">1<br>9<br>0</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>3<br>4</td>
      <td class="chart-51">1<br>5<br>9</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">3<br>8<br>0</td>
      <td class="chart-91">3<br>7<br>9</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">2<br>4<br>5</td>
      <td class="chart-86">3<br>6<br>9</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">2<br>5<br>9</td>
      <td class="chart-36">2<br>3<br>8</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">4<br>5<br>7</td>
   </tr>
   <tr>
      <td>13-05-2024 <br> To <br> 19-05-2024</td>
      <td class="chart-15">1<br>3<br>7</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">4<br>5<br>6</td>
      <td class="chart-70">2<br>7<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>2<br>7</td>
      <td class="chart-49">1<br>3<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>2<br>6</td>
      <td class="chart-07">5<br>7<br>8</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">2<br>6<br>9</td>
      <td class="chart-51">2<br>5<br>8</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">5<br>7<br>9</td>
      <td class="chart-02">5<br>6<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">3<br>4<br>5</td>
      <td class="chart-16">5<br>6<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">1<br>6<br>9</td>
   </tr>
   <tr>
      <td>20-05-2024 <br> To <br> 26-05-2024</td>
      <td class="chart-74">1<br>2<br>4</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">1<br>4<br>9</td>
      <td class="chart-60">3<br>6<br>7</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>3<br>6</td>
      <td class="chart-79">8<br>9<br>0</td>
      <td class="chart-bold chart-79">79</td>
      <td class="chart-79">1<br>2<br>6</td>
      <td class="chart-45">3<br>5<br>6</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">3<br>5<br>7</td>
      <td class="chart-01">3<br>8<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>4<br>6</td>
      <td class="chart-97">1<br>4<br>4</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">1<br>6<br>0</td>
      <td class="chart-00">2<br>2<br>6</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">3<br>7<br>0</td>
   </tr>
   <tr>
      <td>27-05-2024 <br> To <br> 02-06-2024</td>
      <td class="chart-26">5<br>7<br>0</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">2<br>4<br>0</td>
      <td class="chart-14">4<br>7<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>5<br>8</td>
      <td class="chart-69">1<br>1<br>4</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">1<br>3<br>5</td>
      <td class="chart-94">2<br>3<br>4</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">4<br>0<br>0</td>
      <td class="chart-26">1<br>3<br>8</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">6<br>0<br>0</td>
      <td class="chart-89">1<br>3<br>4</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">5<br>6<br>8</td>
      <td class="chart-41">1<br>6<br>7</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>7<br>9</td>
   </tr>
   <tr>
      <td>03-06-2024 <br> To <br> 09-06-2024</td>
      <td class="chart-52">3<br>5<br>7</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">2<br>2<br>9</td>
      <td class="chart-76">8<br>9<br>0</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">3<br>3<br>0</td>
      <td class="chart-17">3<br>3<br>5</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">2<br>5<br>0</td>
      <td class="chart-02">1<br>9<br>0</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>2<br>9</td>
      <td class="chart-63">1<br>7<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>4<br>8</td>
      <td class="chart-84">3<br>5<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">7<br>8<br>9</td>
      <td class="chart-83">1<br>2<br>5</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>8<br>9</td>
   </tr>
   <tr>
      <td>10-06-2024 <br> To <br> 16-06-2024</td>
      <td class="chart-57">4<br>5<br>6</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">2<br>6<br>9</td>
      <td class="chart-66">3<br>5<br>8</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-71">2<br>5<br>0</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">5<br>6<br>0</td>
      <td class="chart-30">2<br>5<br>6</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>4<br>5</td>
      <td class="chart-34">1<br>2<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">2<br>5<br>7</td>
      <td class="chart-57">2<br>4<br>9</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">4<br>6<br>7</td>
      <td class="chart-71">1<br>2<br>4</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">4<br>8<br>9</td>
   </tr>
   <tr>
      <td>17-06-2024 <br> To <br> 23-06-2024</td>
      <td class="chart-80">1<br>3<br>4</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">4<br>6<br>0</td>
      <td class="chart-92">5<br>6<br>8</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">4<br>8<br>0</td>
      <td class="chart-02">5<br>7<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">2<br>3<br>7</td>
      <td class="chart-73">8<br>9<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>8<br>0</td>
      <td class="chart-51">1<br>5<br>9</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>3<br>6</td>
      <td class="chart-78">4<br>5<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>3<br>4</td>
      <td class="chart-26">2<br>4<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">1<br>1<br>4</td>
   </tr>
   <tr>
      <td>24-06-2024 <br> To <br> 30-06-2024</td>
      <td class="chart-41">3<br>5<br>6</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">5<br>7<br>9</td>
      <td class="chart-83">3<br>5<br>0</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>3<br>9</td>
      <td class="chart-20">6<br>7<br>9</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">4<br>7<br>9</td>
      <td class="chart-92">4<br>5<br>0</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>3<br>7</td>
      <td class="chart-97">4<br>6<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">8<br>9<br>0</td>
      <td class="chart-82">3<br>5<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-86">5<br>6<br>7</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">2<br>5<br>9</td>
   </tr>
   <tr>
      <td>01-07-2024 <br> To <br> 07-07-2024</td>
      <td class="chart-63">1<br>5<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">4<br>9<br>0</td>
      <td class="chart-96">9<br>0<br>0</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">4<br>5<br>7</td>
      <td class="chart-00">3<br>7<br>0</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">5<br>7<br>8</td>
      <td class="chart-47">7<br>8<br>9</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">8<br>9<br>0</td>
      <td class="chart-65">3<br>4<br>9</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>6<br>7</td>
      <td class="chart-43">2<br>5<br>7</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">4<br>9<br>0</td>
      <td class="chart-42">7<br>8<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
   </tr>
   <tr>
      <td>08-07-2024 <br> To <br> 14-07-2024</td>
      <td class="chart-49">6<br>8<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">2<br>3<br>4</td>
      <td class="chart-65">1<br>2<br>3</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>6<br>7</td>
      <td class="chart-26">2<br>4<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">3<br>4<br>9</td>
      <td class="chart-54">4<br>5<br>6</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">3<br>5<br>6</td>
      <td class="chart-81">3<br>7<br>8</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">6<br>7<br>8</td>
      <td class="chart-12">1<br>2<br>8</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>4<br>6</td>
      <td class="chart-92">2<br>3<br>4</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">4<br>8<br>0</td>
   </tr>
   <tr>
      <td>15-07-2024 <br> To <br> 21-07-2024</td>
      <td class="chart-64">7<br>9<br>0</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">7<br>8<br>9</td>
      <td class="chart-96">5<br>6<br>8</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">2<br>5<br>9</td>
      <td class="chart-14">5<br>6<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">5<br>9<br>0</td>
      <td class="chart-20">2<br>4<br>6</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">2<br>3<br>5</td>
      <td class="chart-19">5<br>6<br>0</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">1<br>2<br>6</td>
      <td class="chart-29">1<br>4<br>7</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>7<br>8</td>
      <td class="chart-70">1<br>8<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">5<br>7<br>8</td>
   </tr>
   <tr>
      <td>22-07-2024 <br> To <br> 28-07-2024</td>
      <td class="chart-94">1<br>2<br>6</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">5<br>9<br>0</td>
      <td class="chart-86">4<br>6<br>8</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">3<br>4<br>9</td>
      <td class="chart-85">5<br>6<br>7</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">6<br>9<br>0</td>
      <td class="chart-29">4<br>8<br>0</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>5<br>0</td>
      <td class="chart-41">1<br>5<br>8</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">1<br>3<br>7</td>
      <td class="chart-45">5<br>9<br>0</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">2<br>3<br>0</td>
      <td class="chart-68">7<br>9<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">2<br>7<br>9</td>
   </tr>
   <tr>
      <td>29-07-2024 <br> To <br> 04-08-2024</td>
      <td class="chart-42">2<br>3<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>4<br>7</td>
      <td class="chart-02">1<br>3<br>6</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">5<br>7<br>0</td>
      <td class="chart-16">1<br>3<br>7</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">2<br>5<br>9</td>
      <td class="chart-18">2<br>3<br>6</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">5<br>6<br>7</td>
      <td class="chart-36">1<br>3<br>9</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">3<br>6<br>7</td>
      <td class="chart-89">2<br>7<br>9</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">4<br>7<br>8</td>
      <td class="chart-14">3<br>8<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">2<br>3<br>9</td>
   </tr>
   <tr>
      <td>05-08-2024 <br> To <br> 11-08-2024</td>
      <td class="chart-82">2<br>7<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>3<br>8</td>
      <td class="chart-49">1<br>5<br>8</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">5<br>6<br>8</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">4<br>7<br>0</td>
      <td class="chart-58">4<br>5<br>6</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">2<br>6<br>0</td>
      <td class="chart-87">3<br>5<br>0</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>6<br>0</td>
      <td class="chart-65">1<br>5<br>0</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">2<br>5<br>8</td>
      <td class="chart-55">4<br>5<br>6</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">1<br>4<br>0</td>
   </tr>
   <tr>
      <td>12-08-2024 <br> To <br> 18-08-2024</td>
      <td class="chart-94">3<br>7<br>9</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>4<br>9</td>
      <td class="chart-32">2<br>5<br>6</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">3<br>4<br>5</td>
      <td class="chart-63">1<br>6<br>9</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">5<br>8<br>0</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-42">3<br>5<br>6</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">6<br>7<br>9</td>
      <td class="chart-72">4<br>6<br>7</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">6<br>7<br>9</td>
      <td class="chart-17">6<br>7<br>8</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">8<br>9<br>0</td>
   </tr>
   <tr>
      <td>19-08-2024 <br> To <br> 25-08-2024</td>
      <td class="chart-43">7<br>8<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">2<br>5<br>6</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">5<br>5<br>6</td>
      <td class="chart-31">4<br>9<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">5<br>7<br>9</td>
      <td class="chart-38">5<br>8<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>2<br>5</td>
      <td class="chart-16">5<br>6<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">3<br>5<br>8</td>
      <td class="chart-66">4<br>5<br>7</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">7<br>9<br>0</td>
      <td class="chart-39">5<br>8<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">5<br>6<br>8</td>
   </tr>
   <tr>
      <td>26-08-2024 <br> To <br> 01-09-2024</td>
      <td class="chart-27">7<br>7<br>8</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">4<br>6<br>7</td>
      <td class="chart-47">1<br>3<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>7<br>9</td>
      <td class="chart-35">1<br>3<br>9</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">7<br>8<br>0</td>
      <td class="chart-72">3<br>6<br>8</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">1<br>4<br>7</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">3<br>7<br>9</td>
      <td class="chart-29">1<br>5<br>6</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">4<br>6<br>9</td>
      <td class="chart-97">2<br>3<br>4</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">1<br>2<br>4</td>
   </tr>
   <tr>
      <td>02-09-2024 <br> To <br> 08-09-2024</td>
      <td class="chart-46">5<br>9<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>5<br>0</td>
      <td class="chart-54">4<br>5<br>6</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">5<br>9<br>0</td>
      <td class="chart-67">3<br>5<br>8</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">3<br>5<br>9</td>
      <td class="chart-16">5<br>6<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">3<br>5<br>8</td>
      <td class="chart-57">2<br>6<br>7</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">7<br>0<br>0</td>
      <td class="chart-32">6<br>8<br>9</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">2<br>3<br>7</td>
      <td class="chart-84">5<br>6<br>7</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">3<br>5<br>6</td>
   </tr>
   <tr>
      <td>09-09-2024 <br> To <br> 15-09-2024</td>
      <td class="chart-26">4<br>8<br>0</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">8<br>8<br>0</td>
      <td class="chart-13">1<br>3<br>7</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">1<br>2<br>0</td>
      <td class="chart-38">6<br>7<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>3<br>4</td>
      <td class="chart-51">2<br>3<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>9<br>0</td>
      <td class="chart-13">5<br>7<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">5<br>8<br>0</td>
      <td class="chart-90">5<br>6<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">5<br>7<br>8</td>
      <td class="chart-69">4<br>5<br>7</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">4<br>6<br>9</td>
   </tr>
   <tr>
      <td>16-09-2024 <br> To <br> 22-09-2024</td>
      <td class="chart-78">7<br>0<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">4<br>5<br>9</td>
      <td class="chart-82">3<br>5<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>4<br>7</td>
      <td class="chart-92">3<br>7<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">4<br>8<br>0</td>
      <td class="chart-95">5<br>7<br>7</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">6<br>9<br>0</td>
      <td class="chart-36">1<br>6<br>6</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">1<br>7<br>8</td>
      <td class="chart-54">3<br>4<br>8</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>6<br>7</td>
      <td class="chart-97">1<br>2<br>6</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">5<br>5<br>7</td>
   </tr>
   <tr>
      <td>23-09-2024 <br> To <br> 29-09-2024</td>
      <td class="chart-98">4<br>7<br>8</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">4<br>6<br>8</td>
      <td class="chart-84">5<br>6<br>7</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>3<br>0</td>
      <td class="chart-36">4<br>4<br>5</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">4<br>5<br>7</td>
      <td class="chart-25">2<br>0<br>0</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">2<br>4<br>9</td>
      <td class="chart-29">6<br>7<br>9</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>8<br>0</td>
      <td class="chart-30">5<br>8<br>0</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">1<br>2<br>7</td>
      <td class="chart-44">7<br>7<br>0</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">6<br>9<br>9</td>
   </tr>
   <tr>
      <td>30-09-2024 <br> To <br> 06-10-2024</td>
      <td class="chart-11">5<br>7<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-84">2<br>6<br>0</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">5<br>9<br>0</td>
      <td class="chart-88">1<br>3<br>4</td>
      <td class="chart-bold chart-88">88</td>
      <td class="chart-88">4<br>6<br>8</td>
      <td class="chart-22">5<br>8<br>9</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">4<br>8<br>0</td>
      <td class="chart-04">1<br>2<br>7</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">6<br>8<br>0</td>
      <td class="chart-39">2<br>4<br>7</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">5<br>6<br>8</td>
      <td class="chart-37">2<br>5<br>6</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">2<br>6<br>9</td>
   </tr>
   <tr>
      <td>07-10-2024 <br> To <br> 13-10-2024</td>
      <td class="chart-86">2<br>2<br>4</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">4<br>5<br>7</td>
      <td class="chart-14">5<br>6<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">2<br>4<br>8</td>
      <td class="chart-19">1<br>4<br>6</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">4<br>5<br>0</td>
      <td class="chart-73">1<br>6<br>0</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">1<br>3<br>9</td>
      <td class="chart-45">2<br>3<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">7<br>8<br>0</td>
      <td class="chart-78">4<br>5<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">5<br>6<br>7</td>
      <td class="chart-15">2<br>4<br>5</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">4<br>5<br>6</td>
   </tr>
   <tr>
      <td>14-10-2024 <br> To <br> 20-10-2024</td>
      <td class="chart-37">2<br>4<br>7</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">4<br>5<br>8</td>
      <td class="chart-75">2<br>2<br>3</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">3<br>5<br>7</td>
      <td class="chart-78">4<br>6<br>7</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">3<br>5<br>0</td>
      <td class="chart-22">5<br>8<br>9</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">3<br>9<br>0</td>
      <td class="chart-39">1<br>6<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">1<br>2<br>6</td>
      <td class="chart-36">4<br>9<br>0</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">7<br>9<br>0</td>
      <td class="chart-53">4<br>4<br>7</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>5<br>7</td>
   </tr>
   <tr>
      <td>21-10-2024 <br> To <br> 27-10-2024</td>
      <td class="chart-42">6<br>8<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">2<br>5<br>5</td>
      <td class="chart-92">4<br>7<br>8</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>0<br>0</td>
      <td class="chart-77">1<br>7<br>9</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">5<br>5<br>7</td>
      <td class="chart-15">3<br>8<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">6<br>9<br>0</td>
      <td class="chart-17">5<br>7<br>9</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">1<br>6<br>0</td>
      <td class="chart-92">4<br>6<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">3<br>4<br>5</td>
      <td class="chart-80">3<br>7<br>8</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">6<br>7<br>7</td>
   </tr>
   <tr>
      <td>28-10-2024 <br> To <br> 03-11-2024</td>
      <td class="chart-95">5<br>6<br>8</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">2<br>4<br>9</td>
      <td class="chart-93">9<br>0<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>2<br>0</td>
      <td class="chart-31">2<br>3<br>8</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">3<br>8<br>0</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-35">1<br>5<br>7</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">1<br>5<br>9</td>
      <td class="chart-57">7<br>8<br>0</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">8<br>9<br>0</td>
      <td class="chart-36">6<br>8<br>9</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">1<br>5<br>0</td>
   </tr>
   <tr>
      <td>04-11-2024 <br> To <br> 10-11-2024</td>
      <td class="chart-59">7<br>9<br>9</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">3<br>7<br>9</td>
      <td class="chart-65">1<br>7<br>8</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">1<br>5<br>9</td>
      <td class="chart-21">6<br>7<br>9</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">2<br>9<br>0</td>
      <td class="chart-39">2<br>5<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">2<br>3<br>4</td>
      <td class="chart-47">1<br>6<br>7</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">2<br>7<br>8</td>
      <td class="chart-82">3<br>7<br>8</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>2<br>8</td>
      <td class="chart-03">1<br>2<br>7</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">5<br>8<br>0</td>
   </tr>
   <tr>
      <td>11-11-2024 <br> To <br> 17-11-2024</td>
      <td class="chart-16">1<br>4<br>6</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">3<br>4<br>9</td>
      <td class="chart-18">2<br>9<br>0</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">3<br>7<br>8</td>
      <td class="chart-75">1<br>8<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">7<br>8<br>0</td>
      <td class="chart-37">6<br>7<br>0</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>3<br>3</td>
      <td class="chart-92">1<br>2<br>6</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">2<br>5<br>5</td>
      <td class="chart-40">2<br>5<br>7</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">5<br>6<br>9</td>
      <td class="chart-72">7<br>0<br>0</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">4<br>8<br>0</td>
   </tr>
   <tr>
      <td>18-11-2024 <br> To <br> 24-11-2024</td>
      <td class="chart-02">4<br>8<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>2<br>9</td>
      <td class="chart-84">5<br>6<br>7</td>
      <td class="chart-bold chart-84">84</td>
      <td class="chart-84">1<br>3<br>0</td>
      <td class="chart-77">1<br>7<br>9</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">2<br>5<br>0</td>
      <td class="chart-95">1<br>4<br>4</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">1<br>4<br>0</td>
      <td class="chart-43">2<br>4<br>8</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">7<br>8<br>8</td>
      <td class="chart-53">1<br>6<br>8</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">4<br>9<br>0</td>
      <td class="chart-81">1<br>3<br>4</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">1<br>3<br>7</td>
   </tr>
   <tr>
      <td>25-11-2024 <br> To <br> 01-12-2024</td>
      <td class="chart-25">3<br>3<br>6</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">4<br>5<br>6</td>
      <td class="chart-30">1<br>2<br>0</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">4<br>7<br>9</td>
      <td class="chart-75">2<br>7<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">1<br>7<br>7</td>
      <td class="chart-48">1<br>3<br>0</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">3<br>6<br>9</td>
      <td class="chart-12">4<br>8<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">3<br>9<br>0</td>
      <td class="chart-50">2<br>6<br>7</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>9<br>0</td>
      <td class="chart-45">2<br>3<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">1<br>5<br>9</td>
   </tr>
   <tr>
      <td>02-12-2024 <br> To <br> 08-12-2024</td>
      <td class="chart-63">1<br>6<br>9</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>4<br>8</td>
      <td class="chart-01">4<br>7<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>2<br>8</td>
      <td class="chart-49">1<br>3<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">4<br>5<br>0</td>
      <td class="chart-56">6<br>9<br>0</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>1<br>4</td>
      <td class="chart-07">2<br>8<br>0</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">1<br>2<br>4</td>
      <td class="chart-29">1<br>2<br>9</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">9<br>0<br>0</td>
      <td class="chart-06">6<br>7<br>7</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">3<br>3<br>0</td>
   </tr>
   <tr>
      <td>09-12-2024 <br> To <br> 15-12-2024</td>
      <td class="chart-12">2<br>4<br>5</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">5<br>7<br>0</td>
      <td class="chart-82">4<br>4<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-35">1<br>5<br>7</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">6<br>9<br>0</td>
      <td class="chart-61">1<br>2<br>3</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">3<br>4<br>4</td>
      <td class="chart-93">2<br>2<br>5</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">2<br>4<br>7</td>
      <td class="chart-33">6<br>7<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">2<br>2<br>9</td>
      <td class="chart-11">5<br>6<br>0</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">5<br>8<br>8</td>
   </tr>
   <tr>
      <td>16-12-2024 <br> To <br> 22-12-2024</td>
      <td class="chart-74">3<br>4<br>0</td>
      <td class="chart-bold chart-74">74</td>
      <td class="chart-74">6<br>9<br>9</td>
      <td class="chart-92">4<br>6<br>9</td>
      <td class="chart-bold chart-92">92</td>
      <td class="chart-92">1<br>2<br>9</td>
      <td class="chart-02">4<br>7<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">4<br>8<br>0</td>
      <td class="chart-18">4<br>8<br>9</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">2<br>6<br>0</td>
      <td class="chart-53">4<br>4<br>7</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">2<br>3<br>8</td>
      <td class="chart-67">3<br>6<br>7</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">2<br>6<br>9</td>
      <td class="chart-42">5<br>9<br>0</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">2<br>2<br>8</td>
   </tr>
   <tr>
      <td>23-12-2024 <br> To <br> 29-12-2024</td>
      <td class="chart-30">7<br>7<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">2<br>3<br>5</td>
      <td class="chart-91">1<br>3<br>5</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">2<br>3<br>6</td>
      <td class="chart-16">4<br>7<br>0</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">5<br>5<br>6</td>
      <td class="chart-87">4<br>5<br>9</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">2<br>2<br>3</td>
      <td class="chart-12">2<br>3<br>6</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">3<br>9<br>0</td>
      <td class="chart-04">1<br>3<br>6</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">2<br>3<br>9</td>
      <td class="chart-29">5<br>8<br>9</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">1<br>4<br>4</td>
   </tr>
   <tr>
      <td>30-12-2024 <br> To <br> 05-01-2025</td>
      <td class="chart-50">1<br>6<br>8</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">5<br>7<br>8</td>
      <td class="chart-77">1<br>3<br>3</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">1<br>2<br>4</td>
      <td class="chart-02">5<br>6<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>1<br>0</td>
      <td class="chart-93">9<br>0<br>0</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">6<br>8<br>9</td>
      <td class="chart-81">1<br>2<br>5</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">3<br>9<br>9</td>
      <td class="chart-46">4<br>5<br>5</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>7<br>8</td>
      <td class="chart-52">1<br>4<br>0</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">2<br>0<br>0</td>
   </tr>
   <tr>
      <td>06-01-2025 <br> To <br> 12-01-2025</td>
      <td class="chart-83">1<br>8<br>9</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>4<br>7</td>
      <td class="chart-21">2<br>4<br>6</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">2<br>9<br>0</td>
      <td class="chart-64">8<br>9<br>9</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">3<br>4<br>7</td>
      <td class="chart-08">4<br>8<br>8</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">2<br>8<br>8</td>
      <td class="chart-61">4<br>5<br>7</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">1<br>2<br>8</td>
      <td class="chart-34">5<br>8<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">1<br>3<br>0</td>
      <td class="chart-85">1<br>8<br>9</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">2<br>6<br>7</td>
   </tr>
   <tr>
      <td>13-01-2025 <br> To <br> 19-01-2025</td>
      <td class="chart-40">2<br>3<br>9</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>2<br>7</td>
      <td class="chart-31">3<br>4<br>6</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">5<br>6<br>0</td>
      <td class="chart-50">7<br>8<br>0</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">1<br>9<br>0</td>
      <td class="chart-82">3<br>5<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-01">5<br>7<br>8</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>0<br>0</td>
      <td class="chart-27">2<br>3<br>7</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">1<br>6<br>0</td>
      <td class="chart-19">2<br>4<br>5</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">2<br>7<br>0</td>
   </tr>
   <tr>
      <td>20-01-2025 <br> To <br> 26-01-2025</td>
      <td class="chart-08">1<br>4<br>5</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">3<br>6<br>9</td>
      <td class="chart-20">1<br>5<br>6</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">3<br>7<br>0</td>
      <td class="chart-90">1<br>1<br>7</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">2<br>9<br>9</td>
      <td class="chart-86">1<br>7<br>0</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">3<br>3<br>0</td>
      <td class="chart-49">2<br>4<br>8</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>2<br>6</td>
      <td class="chart-13">4<br>8<br>9</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">3<br>4<br>6</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
   </tr>
   <tr>
      <td>27-01-2025 <br> To <br> 02-02-2025</td>
      <td class="chart-19">2<br>3<br>6</td>
      <td class="chart-bold chart-19">19</td>
      <td class="chart-19">4<br>5<br>0</td>
      <td class="chart-14">1<br>2<br>8</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">6<br>8<br>0</td>
      <td class="chart-18">1<br>1<br>9</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">1<br>8<br>9</td>
      <td class="chart-23">1<br>1<br>0</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">3<br>0<br>0</td>
      <td class="chart-67">2<br>4<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">1<br>2<br>4</td>
      <td class="chart-09">2<br>3<br>5</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">2<br>7<br>0</td>
      <td class="chart-46">2<br>2<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>7<br>8</td>
   </tr>
   <tr>
      <td>03-02-2025 <br> To <br> 09-02-2025</td>
      <td class="chart-95">3<br>6<br>0</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">1<br>1<br>3</td>
      <td class="chart-57">2<br>6<br>7</td>
      <td class="chart-bold chart-57">57</td>
      <td class="chart-57">3<br>6<br>8</td>
      <td class="chart-62">1<br>5<br>0</td>
      <td class="chart-bold chart-62">62</td>
      <td class="chart-62">2<br>5<br>5</td>
      <td class="chart-98">1<br>4<br>4</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">3<br>7<br>8</td>
      <td class="chart-51">6<br>9<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">2<br>4<br>5</td>
      <td class="chart-20">5<br>7<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">4<br>7<br>9</td>
      <td class="chart-77">8<br>9<br>0</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">5<br>6<br>6</td>
   </tr>
   <tr>
      <td>10-02-2025 <br> To <br> 16-02-2025</td>
      <td class="chart-28">3<br>9<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">2<br>7<br>9</td>
      <td class="chart-37">1<br>4<br>8</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>7<br>9</td>
      <td class="chart-43">1<br>1<br>2</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">2<br>5<br>6</td>
      <td class="chart-70">3<br>7<br>7</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">5<br>7<br>8</td>
      <td class="chart-61">4<br>5<br>7</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">3<br>3<br>5</td>
      <td class="chart-52">2<br>4<br>9</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>3<br>8</td>
      <td class="chart-98">5<br>7<br>7</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">8<br>0<br>0</td>
   </tr>
   <tr>
      <td>17-02-2025 <br> To <br> 23-02-2025</td>
      <td class="chart-44">7<br>8<br>9</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">2<br>5<br>7</td>
      <td class="chart-06">1<br>3<br>6</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">4<br>6<br>6</td>
      <td class="chart-46">1<br>3<br>0</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">2<br>4<br>0</td>
      <td class="chart-09">2<br>2<br>6</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">2<br>8<br>9</td>
      <td class="chart-11">4<br>8<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>5<br>5</td>
      <td class="chart-95">1<br>3<br>5</td>
      <td class="chart-bold chart-95">95</td>
      <td class="chart-95">4<br>5<br>6</td>
      <td class="chart-78">3<br>6<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">2<br>2<br>4</td>
   </tr>
   <tr>
      <td>24-02-2025 <br> To <br> 02-03-2025</td>
      <td class="chart-53">1<br>6<br>8</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">5<br>8<br>0</td>
      <td class="chart-07">2<br>9<br>9</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">1<br>6<br>0</td>
      <td class="chart-75">3<br>6<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">1<br>4<br>0</td>
      <td class="chart-46">3<br>4<br>7</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>2<br>3</td>
      <td class="chart-30">1<br>3<br>9</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>6<br>9</td>
      <td class="chart-82">1<br>7<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>2<br>8</td>
      <td class="chart-43">2<br>3<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">5<br>9<br>9</td>
   </tr>
   <tr>
      <td>03-03-2025 <br> To <br> 09-03-2025</td>
      <td class="chart-40">2<br>6<br>6</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">2<br>3<br>5</td>
      <td class="chart-71">1<br>2<br>4</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">3<br>8<br>0</td>
      <td class="chart-38">6<br>7<br>0</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">5<br>5<br>8</td>
      <td class="chart-91">3<br>6<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">1<br>5<br>5</td>
      <td class="chart-63">4<br>5<br>7</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>4<br>8</td>
      <td class="chart-54">4<br>5<br>6</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>5<br>8</td>
      <td class="chart-28">1<br>2<br>9</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">3<br>5<br>0</td>
   </tr>
   <tr>
      <td>10-03-2025 <br> To <br> 16-03-2025</td>
      <td class="chart-09">3<br>8<br>9</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">4<br>7<br>8</td>
      <td class="chart-35">1<br>5<br>7</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">3<br>4<br>8</td>
      <td class="chart-11">3<br>4<br>4</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">2<br>9<br>0</td>
      <td class="chart-23">5<br>8<br>9</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">2<br>4<br>7</td>
      <td class="chart-**"></td>
      <td class="chart-bold chart-**">**</td>
      <td class="chart-**"></td>
      <td class="chart-90">5<br>7<br>7</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">1<br>2<br>7</td>
      <td class="chart-61">2<br>5<br>9</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">4<br>7<br>0</td>
   </tr>
   <tr>
      <td>17-03-2025 <br> To <br> 23-03-2025</td>
      <td class="chart-14">6<br>7<br>8</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>3<br>0</td>
      <td class="chart-25">2<br>5<br>5</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">4<br>4<br>7</td>
      <td class="chart-56">3<br>6<br>6</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>6<br>9</td>
      <td class="chart-29">6<br>7<br>9</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">2<br>3<br>4</td>
      <td class="chart-87">4<br>5<br>9</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>6<br>0</td>
      <td class="chart-68">3<br>4<br>9</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">1<br>8<br>9</td>
      <td class="chart-53">2<br>5<br>8</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">3<br>4<br>6</td>
   </tr>
   <tr>
      <td>24-03-2025 <br> To <br> 30-03-2025</td>
      <td class="chart-50">2<br>6<br>7</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">3<br>7<br>0</td>
      <td class="chart-77">3<br>5<br>9</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">3<br>7<br>7</td>
      <td class="chart-54">4<br>5<br>6</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">2<br>2<br>0</td>
      <td class="chart-63">4<br>5<br>7</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">3<br>3<br>7</td>
      <td class="chart-82">2<br>2<br>4</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">1<br>2<br>9</td>
      <td class="chart-48">1<br>5<br>8</td>
      <td class="chart-bold chart-48">48</td>
      <td class="chart-48">1<br>7<br>0</td>
      <td class="chart-44">2<br>3<br>9</td>
      <td class="chart-bold chart-44">44</td>
      <td class="chart-44">6<br>9<br>9</td>
   </tr>
   <tr>
      <td>31-03-2025 <br> To <br> 06-04-2025</td>
      <td class="chart-13">1<br>4<br>6</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">6<br>8<br>9</td>
      <td class="chart-69">2<br>4<br>0</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">2<br>8<br>9</td>
      <td class="chart-12">1<br>2<br>8</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">6<br>8<br>8</td>
      <td class="chart-55">3<br>3<br>9</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">2<br>3<br>0</td>
      <td class="chart-85">1<br>3<br>4</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">7<br>8<br>0</td>
      <td class="chart-38">5<br>9<br>9</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">3<br>7<br>8</td>
      <td class="chart-39">2<br>5<br>6</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>5<br>0</td>
   </tr>
   <tr>
      <td>07-04-2025 <br> To <br> 13-04-2025</td>
      <td class="chart-40">1<br>3<br>0</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">2<br>2<br>6</td>
      <td class="chart-60">1<br>6<br>9</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">1<br>4<br>5</td>
      <td class="chart-83">5<br>6<br>7</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">1<br>3<br>9</td>
      <td class="chart-26">2<br>3<br>7</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">4<br>4<br>8</td>
      <td class="chart-16">3<br>3<br>5</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">7<br>9<br>0</td>
      <td class="chart-02">2<br>3<br>5</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>4<br>7</td>
      <td class="chart-66">8<br>8<br>0</td>
      <td class="chart-bold chart-66">66</td>
      <td class="chart-66">1<br>2<br>3</td>
   </tr>
   <tr>
      <td>14-04-2025 <br> To <br> 20-04-2025</td>
      <td class="chart-15">2<br>9<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">1<br>7<br>7</td>
      <td class="chart-86">3<br>5<br>0</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">2<br>5<br>9</td>
      <td class="chart-15">4<br>7<br>0</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">2<br>5<br>8</td>
      <td class="chart-42">4<br>4<br>6</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">3<br>9<br>0</td>
      <td class="chart-35">1<br>2<br>0</td>
      <td class="chart-bold chart-35">35</td>
      <td class="chart-35">3<br>4<br>8</td>
      <td class="chart-27">7<br>7<br>8</td>
      <td class="chart-bold chart-27">27</td>
      <td class="chart-27">5<br>5<br>7</td>
      <td class="chart-18">4<br>8<br>9</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">2<br>6<br>0</td>
   </tr>
   <tr>
      <td>21-04-2025 <br> To <br> 27-04-2025</td>
      <td class="chart-73">1<br>1<br>5</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">3<br>4<br>6</td>
      <td class="chart-46">3<br>4<br>7</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">1<br>7<br>8</td>
      <td class="chart-04">5<br>6<br>9</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">1<br>1<br>2</td>
      <td class="chart-72">4<br>6<br>7</td>
      <td class="chart-bold chart-72">72</td>
      <td class="chart-72">1<br>5<br>6</td>
      <td class="chart-76">2<br>7<br>8</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">1<br>5<br>0</td>
      <td class="chart-28">4<br>8<br>0</td>
      <td class="chart-bold chart-28">28</td>
      <td class="chart-28">2<br>3<br>3</td>
      <td class="chart-34">2<br>4<br>7</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">7<br>8<br>9</td>
   </tr>
   <tr>
      <td>28-04-2025 <br> To <br> 04-05-2025</td>
      <td class="chart-81">1<br>2<br>5</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">5<br>6<br>0</td>
      <td class="chart-68">8<br>9<br>9</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">3<br>6<br>9</td>
      <td class="chart-30">1<br>4<br>8</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">5<br>7<br>8</td>
      <td class="chart-51">2<br>4<br>9</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">3<br>4<br>4</td>
      <td class="chart-90">3<br>6<br>0</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">2<br>3<br>5</td>
      <td class="chart-63">1<br>7<br>8</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">1<br>3<br>9</td>
      <td class="chart-49">2<br>5<br>7</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>8<br>0</td>
   </tr>
   <tr>
      <td>05-05-2025 <br> To <br> 11-05-2025</td>
      <td class="chart-33">3<br>0<br>0</td>
      <td class="chart-bold chart-33">33</td>
      <td class="chart-33">1<br>2<br>0</td>
      <td class="chart-01">4<br>7<br>9</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">2<br>4<br>5</td>
      <td class="chart-78">3<br>4<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>7<br>0</td>
      <td class="chart-40">1<br>6<br>7</td>
      <td class="chart-bold chart-40">40</td>
      <td class="chart-40">1<br>9<br>0</td>
      <td class="chart-22">6<br>7<br>9</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">1<br>3<br>8</td>
      <td class="chart-56">2<br>3<br>0</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">5<br>5<br>6</td>
      <td class="chart-37">1<br>4<br>8</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">1<br>6<br>0</td>
   </tr>
   <tr>
      <td>12-05-2025 <br> To <br> 18-05-2025</td>
      <td class="chart-14">3<br>8<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">1<br>4<br>9</td>
      <td class="chart-30">1<br>5<br>7</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">3<br>7<br>0</td>
      <td class="chart-52">1<br>2<br>2</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">5<br>8<br>9</td>
      <td class="chart-85">2<br>7<br>9</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">3<br>5<br>7</td>
      <td class="chart-61">2<br>4<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">1<br>1<br>9</td>
      <td class="chart-12">2<br>3<br>6</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">2<br>3<br>7</td>
      <td class="chart-47">2<br>6<br>6</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">3<br>5<br>9</td>
   </tr>
   <tr>
      <td>19-05-2025 <br> To <br> 25-05-2025</td>
      <td class="chart-05">1<br>4<br>5</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">2<br>6<br>7</td>
      <td class="chart-93">5<br>6<br>8</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">2<br>3<br>8</td>
      <td class="chart-78">3<br>6<br>8</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">4<br>4<br>0</td>
      <td class="chart-41">7<br>8<br>9</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">1<br>2<br>8</td>
      <td class="chart-23">1<br>2<br>9</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">3<br>0<br>0</td>
      <td class="chart-85">1<br>2<br>5</td>
      <td class="chart-bold chart-85">85</td>
      <td class="chart-85">6<br>9<br>0</td>
      <td class="chart-56">2<br>5<br>8</td>
      <td class="chart-bold chart-56">56</td>
      <td class="chart-56">1<br>7<br>8</td>
   </tr>
   <tr>
      <td>26-05-2025 <br> To <br> 01-06-2025</td>
      <td class="chart-14">4<br>7<br>0</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">2<br>5<br>7</td>
      <td class="chart-52">7<br>8<br>0</td>
      <td class="chart-bold chart-52">52</td>
      <td class="chart-52">1<br>4<br>7</td>
      <td class="chart-63">4<br>6<br>6</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">6<br>8<br>9</td>
      <td class="chart-34">5<br>8<br>0</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">3<br>5<br>6</td>
      <td class="chart-91">1<br>4<br>4</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">4<br>8<br>9</td>
      <td class="chart-13">2<br>9<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">6<br>7<br>0</td>
      <td class="chart-70">4<br>5<br>8</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">3<br>8<br>9</td>
   </tr>
   <tr>
      <td>02-06-2025 <br> To <br> 08-06-2025</td>
      <td class="chart-83">1<br>1<br>6</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>4<br>7</td>
      <td class="chart-06">5<br>6<br>9</td>
      <td class="chart-bold chart-06">06</td>
      <td class="chart-06">3<br>6<br>7</td>
      <td class="chart-21">1<br>1<br>0</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">5<br>7<br>9</td>
      <td class="chart-82">1<br>8<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">3<br>9<br>0</td>
      <td class="chart-45">2<br>5<br>7</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">3<br>4<br>8</td>
      <td class="chart-16">1<br>2<br>8</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">1<br>5<br>0</td>
      <td class="chart-91">5<br>6<br>8</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">3<br>8<br>0</td>
   </tr>
   <tr>
      <td>09-06-2025 <br> To <br> 15-06-2025</td>
      <td class="chart-53">8<br>8<br>9</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>4<br>8</td>
      <td class="chart-70">1<br>6<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">1<br>9<br>0</td>
      <td class="chart-36">3<br>4<br>6</td>
      <td class="chart-bold chart-36">36</td>
      <td class="chart-36">4<br>5<br>7</td>
      <td class="chart-34">7<br>7<br>9</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">2<br>4<br>8</td>
      <td class="chart-60">3<br>3<br>0</td>
      <td class="chart-bold chart-60">60</td>
      <td class="chart-60">2<br>3<br>5</td>
      <td class="chart-18">1<br>3<br>7</td>
      <td class="chart-bold chart-18">18</td>
      <td class="chart-18">2<br>7<br>9</td>
      <td class="chart-50">2<br>3<br>0</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">5<br>5<br>0</td>
   </tr>
   <tr>
      <td>16-06-2025 <br> To <br> 22-06-2025</td>
      <td class="chart-25">3<br>9<br>0</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">4<br>5<br>6</td>
      <td class="chart-15">5<br>8<br>8</td>
      <td class="chart-bold chart-15">15</td>
      <td class="chart-15">7<br>8<br>0</td>
      <td class="chart-87">1<br>1<br>6</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>2<br>4</td>
      <td class="chart-98">3<br>6<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">1<br>2<br>5</td>
      <td class="chart-07">3<br>8<br>9</td>
      <td class="chart-bold chart-07">07</td>
      <td class="chart-07">1<br>8<br>8</td>
      <td class="chart-42">6<br>9<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">1<br>4<br>7</td>
      <td class="chart-14">1<br>5<br>5</td>
      <td class="chart-bold chart-14">14</td>
      <td class="chart-14">6<br>8<br>0</td>
   </tr>
   <tr>
      <td>23-06-2025 <br> To <br> 29-06-2025</td>
      <td class="chart-67">1<br>5<br>0</td>
      <td class="chart-bold chart-67">67</td>
      <td class="chart-67">3<br>5<br>9</td>
      <td class="chart-31">6<br>8<br>9</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">4<br>7<br>0</td>
      <td class="chart-55">1<br>4<br>0</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">8<br>8<br>9</td>
      <td class="chart-23">1<br>5<br>6</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">5<br>9<br>9</td>
      <td class="chart-10">2<br>3<br>6</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">1<br>1<br>8</td>
      <td class="chart-96">5<br>6<br>8</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">3<br>4<br>9</td>
      <td class="chart-03">3<br>7<br>0</td>
      <td class="chart-bold chart-03">03</td>
      <td class="chart-03">2<br>5<br>6</td>
   </tr>
   <tr>
      <td>30-06-2025 <br> To <br> 06-07-2025</td>
      <td class="chart-49">2<br>3<br>9</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>8<br>0</td>
      <td class="chart-71">5<br>5<br>7</td>
      <td class="chart-bold chart-71">71</td>
      <td class="chart-71">1<br>4<br>6</td>
      <td class="chart-02">3<br>8<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">6<br>7<br>9</td>
      <td class="chart-54">1<br>7<br>7</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">7<br>8<br>9</td>
      <td class="chart-77">3<br>6<br>8</td>
      <td class="chart-bold chart-77">77</td>
      <td class="chart-77">4<br>6<br>7</td>
      <td class="chart-89">1<br>2<br>5</td>
      <td class="chart-bold chart-89">89</td>
      <td class="chart-89">4<br>7<br>8</td>
      <td class="chart-78">8<br>9<br>0</td>
      <td class="chart-bold chart-78">78</td>
      <td class="chart-78">1<br>3<br>4</td>
   </tr>
   <tr>
      <td>07-07-2025 <br> To <br> 13-07-2025</td>
      <td class="chart-01">1<br>3<br>6</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">4<br>8<br>9</td>
      <td class="chart-69">1<br>7<br>8</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">4<br>6<br>9</td>
      <td class="chart-47">1<br>3<br>0</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>2<br>4</td>
      <td class="chart-82">3<br>7<br>8</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">2<br>3<br>7</td>
      <td class="chart-46">1<br>1<br>2</td>
      <td class="chart-bold chart-46">46</td>
      <td class="chart-46">4<br>5<br>7</td>
      <td class="chart-31">6<br>7<br>0</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">5<br>8<br>8</td>
      <td class="chart-23">5<br>7<br>0</td>
      <td class="chart-bold chart-23">23</td>
      <td class="chart-23">2<br>4<br>7</td>
   </tr>
   <tr>
      <td>14-07-2025 <br> To <br> 20-07-2025</td>
      <td class="chart-08">1<br>4<br>5</td>
      <td class="chart-bold chart-08">08</td>
      <td class="chart-08">1<br>7<br>0</td>
      <td class="chart-70">8<br>9<br>0</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">6<br>6<br>8</td>
      <td class="chart-10">1<br>1<br>9</td>
      <td class="chart-bold chart-10">10</td>
      <td class="chart-10">2<br>3<br>5</td>
      <td class="chart-91">4<br>5<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">2<br>3<br>6</td>
      <td class="chart-53">1<br>4<br>0</td>
      <td class="chart-bold chart-53">53</td>
      <td class="chart-53">1<br>3<br>9</td>
      <td class="chart-76">2<br>6<br>9</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">3<br>6<br>7</td>
      <td class="chart-43">1<br>4<br>9</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">7<br>7<br>9</td>
   </tr>
   <tr>
      <td>21-07-2025 <br> To <br> 27-07-2025</td>
      <td class="chart-30">2<br>5<br>6</td>
      <td class="chart-bold chart-30">30</td>
      <td class="chart-30">3<br>8<br>9</td>
      <td class="chart-94">4<br>7<br>8</td>
      <td class="chart-bold chart-94">94</td>
      <td class="chart-94">1<br>4<br>9</td>
      <td class="chart-82">1<br>7<br>0</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">5<br>8<br>9</td>
      <td class="chart-63">7<br>9<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">2<br>4<br>7</td>
      <td class="chart-45">2<br>2<br>0</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">6<br>9<br>0</td>
      <td class="chart-11">4<br>8<br>9</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">6<br>7<br>8</td>
      <td class="chart-26">1<br>5<br>6</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">3<br>5<br>8</td>
   </tr>
   <tr>
      <td>28-07-2025 <br> To <br> 03-08-2025</td>
      <td class="chart-34">5<br>9<br>9</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">3<br>4<br>7</td>
      <td class="chart-76">2<br>5<br>0</td>
      <td class="chart-bold chart-76">76</td>
      <td class="chart-76">3<br>6<br>7</td>
      <td class="chart-09">5<br>5<br>0</td>
      <td class="chart-bold chart-09">09</td>
      <td class="chart-09">1<br>8<br>0</td>
      <td class="chart-82">2<br>2<br>4</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>6<br>0</td>
      <td class="chart-13">4<br>7<br>0</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>3<br>8</td>
      <td class="chart-49">5<br>9<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">2<br>8<br>9</td>
      <td class="chart-70">3<br>5<br>9</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">4<br>8<br>8</td>
   </tr>
   <tr>
      <td>04-08-2025 <br> To <br> 10-08-2025</td>
      <td class="chart-91">4<br>5<br>0</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">1<br>2<br>8</td>
      <td class="chart-05">3<br>7<br>0</td>
      <td class="chart-bold chart-05">05</td>
      <td class="chart-05">4<br>5<br>6</td>
      <td class="chart-29">3<br>4<br>5</td>
      <td class="chart-bold chart-29">29</td>
      <td class="chart-29">2<br>8<br>9</td>
      <td class="chart-61">2<br>4<br>0</td>
      <td class="chart-bold chart-61">61</td>
      <td class="chart-61">2<br>2<br>7</td>
      <td class="chart-82">1<br>8<br>9</td>
      <td class="chart-bold chart-82">82</td>
      <td class="chart-82">6<br>7<br>9</td>
      <td class="chart-59">7<br>8<br>0</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">1<br>3<br>5</td>
      <td class="chart-69">4<br>5<br>7</td>
      <td class="chart-bold chart-69">69</td>
      <td class="chart-69">3<br>7<br>9</td>
   </tr>
   <tr>
      <td>11-08-2025 <br> To <br> 17-08-2025</td>
      <td class="chart-49">7<br>8<br>9</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>3<br>5</td>
      <td class="chart-59">6<br>9<br>0</td>
      <td class="chart-bold chart-59">59</td>
      <td class="chart-59">5<br>6<br>8</td>
      <td class="chart-86">1<br>3<br>4</td>
      <td class="chart-bold chart-86">86</td>
      <td class="chart-86">1<br>7<br>8</td>
      <td class="chart-21">2<br>2<br>8</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">4<br>7<br>0</td>
      <td class="r">*<br>*<br>*</td>
      <td class="r">**</td>
      <td class="r">*<br>*<br>*</td>
      <td class="chart-24">4<br>8<br>0</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">1<br>4<br>9</td>
      <td class="chart-01">4<br>8<br>8</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">4<br>8<br>9</td>
   </tr>
   <tr>
      <td>18-08-2025 <br> To <br> 24-08-2025</td>
      <td class="chart-73">2<br>6<br>9</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">1<br>4<br>8</td>
      <td class="chart-00">2<br>3<br>5</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>9<br>0</td>
      <td class="chart-39">6<br>7<br>0</td>
      <td class="chart-bold chart-39">39</td>
      <td class="chart-39">4<br>7<br>8</td>
      <td class="chart-43">2<br>4<br>8</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">5<br>8<br>0</td>
      <td class="chart-17">3<br>9<br>9</td>
      <td class="chart-bold chart-17">17</td>
      <td class="chart-17">1<br>6<br>0</td>
      <td class="chart-96">2<br>8<br>9</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">3<br>3<br>0</td>
      <td class="chart-45">6<br>9<br>9</td>
      <td class="chart-bold chart-45">45</td>
      <td class="chart-45">4<br>5<br>6</td>
   </tr>
   <tr>
      <td>25-08-2025 <br> To <br> 31-08-2025</td>
      <td class="chart-83">4<br>6<br>8</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">2<br>5<br>6</td>
      <td class="chart-64">4<br>5<br>7</td>
      <td class="chart-bold chart-64">64</td>
      <td class="chart-64">2<br>3<br>9</td>
      <td class="chart-58">1<br>2<br>2</td>
      <td class="chart-bold chart-58">58</td>
      <td class="chart-58">1<br>7<br>0</td>
      <td class="chart-02">3<br>8<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">6<br>7<br>9</td>
      <td class="chart-63">8<br>8<br>0</td>
      <td class="chart-bold chart-63">63</td>
      <td class="chart-63">3<br>0<br>0</td>
      <td class="chart-32">1<br>5<br>7</td>
      <td class="chart-bold chart-32">32</td>
      <td class="chart-32">3<br>9<br>0</td>
      <td class="chart-49">3<br>4<br>7</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">1<br>8<br>0</td>
   </tr>
   <tr>
      <td>01-09-2025 <br> To <br> 07-09-2025</td>
      <td class="chart-96">2<br>8<br>9</td>
      <td class="chart-bold chart-96">96</td>
      <td class="chart-96">2<br>4<br>0</td>
      <td class="chart-21">2<br>5<br>5</td>
      <td class="chart-bold chart-21">21</td>
      <td class="chart-21">5<br>6<br>0</td>
      <td class="chart-55">7<br>8<br>0</td>
      <td class="chart-bold chart-55">55</td>
      <td class="chart-55">3<br>4<br>8</td>
      <td class="chart-93">5<br>5<br>9</td>
      <td class="chart-bold chart-93">93</td>
      <td class="chart-93">1<br>2<br>0</td>
      <td class="chart-24">1<br>4<br>7</td>
      <td class="chart-bold chart-24">24</td>
      <td class="chart-24">2<br>4<br>8</td>
      <td class="chart-38">4<br>4<br>5</td>
      <td class="chart-bold chart-38">38</td>
      <td class="chart-38">1<br>2<br>5</td>
      <td class="chart-73">3<br>6<br>8</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">5<br>8<br>0</td>
   </tr>
   <tr>
      <td>08-09-2025 <br> To <br> 14-09-2025</td>
      <td class="chart-42">1<br>4<br>9</td>
      <td class="chart-bold chart-42">42</td>
      <td class="chart-42">5<br>8<br>9</td>
      <td class="chart-73">2<br>7<br>8</td>
      <td class="chart-bold chart-73">73</td>
      <td class="chart-73">4<br>9<br>0</td>
      <td class="chart-20">2<br>0<br>0</td>
      <td class="chart-bold chart-20">20</td>
      <td class="chart-20">1<br>1<br>8</td>
      <td class="chart-13">3<br>3<br>5</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>3<br>8</td>
      <td class="chart-65">1<br>2<br>3</td>
      <td class="chart-bold chart-65">65</td>
      <td class="chart-65">1<br>6<br>8</td>
      <td class="chart-12">5<br>7<br>9</td>
      <td class="chart-bold chart-12">12</td>
      <td class="chart-12">1<br>5<br>6</td>
      <td class="chart-00">3<br>3<br>4</td>
      <td class="chart-bold chart-00">00</td>
      <td class="chart-00">1<br>4<br>5</td>
   </tr>
   <tr>
      <td>15-09-2025 <br> To <br> 21-09-2025</td>
      <td class="chart-51">2<br>3<br>0</td>
      <td class="chart-bold chart-51">51</td>
      <td class="chart-51">1<br>2<br>8</td>
      <td class="chart-83">1<br>3<br>4</td>
      <td class="chart-bold chart-83">83</td>
      <td class="chart-83">6<br>8<br>9</td>
      <td class="chart-04">4<br>6<br>0</td>
      <td class="chart-bold chart-04">04</td>
      <td class="chart-04">3<br>4<br>7</td>
      <td class="chart-37">7<br>7<br>9</td>
      <td class="chart-bold chart-37">37</td>
      <td class="chart-37">3<br>5<br>9</td>
      <td class="chart-25">2<br>3<br>7</td>
      <td class="chart-bold chart-25">25</td>
      <td class="chart-25">1<br>4<br>0</td>
      <td class="chart-80">3<br>6<br>9</td>
      <td class="chart-bold chart-80">80</td>
      <td class="chart-80">5<br>7<br>8</td>
      <td class="chart-43">4<br>0<br>0</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">6<br>7<br>0</td>
   </tr>
   <tr>
      <td>22-09-2025 <br> To <br> 28-09-2025</td>
      <td class="chart-50">4<br>5<br>6</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">4<br>7<br>9</td>
      <td class="chart-43">1<br>5<br>8</td>
      <td class="chart-bold chart-43">43</td>
      <td class="chart-43">7<br>8<br>8</td>
      <td class="chart-31">1<br>6<br>6</td>
      <td class="chart-bold chart-31">31</td>
      <td class="chart-31">2<br>4<br>5</td>
      <td class="chart-22">5<br>7<br>0</td>
      <td class="chart-bold chart-22">22</td>
      <td class="chart-22">2<br>4<br>6</td>
      <td class="chart-90">5<br>6<br>8</td>
      <td class="chart-bold chart-90">90</td>
      <td class="chart-90">3<br>8<br>9</td>
      <td class="chart-47">1<br>6<br>7</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">1<br>2<br>4</td>
      <td class="chart-87">1<br>8<br>9</td>
      <td class="chart-bold chart-87">87</td>
      <td class="chart-87">1<br>6<br>0</td>
   </tr>
   <tr>
      <td>29-09-2025 <br> To <br> 05-10-2025</td>
      <td class="chart-02">1<br>1<br>8</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>2<br>9</td>
      <td class="chart-16">1<br>3<br>7</td>
      <td class="chart-bold chart-16">16</td>
      <td class="chart-16">3<br>5<br>8</td>
      <td class="chart-98">4<br>5<br>0</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">2<br>7<br>9</td>
      <td class="chart-13">5<br>8<br>8</td>
      <td class="chart-bold chart-13">13</td>
      <td class="chart-13">2<br>5<br>6</td>
      <td class="chart-49">7<br>7<br>0</td>
      <td class="chart-bold chart-49">49</td>
      <td class="chart-49">4<br>7<br>8</td>
      <td class="chart-26">3<br>4<br>5</td>
      <td class="chart-bold chart-26">26</td>
      <td class="chart-26">5<br>5<br>6</td>
      <td class="chart-41">6<br>9<br>9</td>
      <td class="chart-bold chart-41">41</td>
      <td class="chart-41">2<br>9<br>0</td>
   </tr>
   <tr>
      <td>06-10-2025 <br> To <br> 12-10-2025</td>
      <td class="chart-81">2<br>6<br>0</td>
      <td class="chart-bold chart-81">81</td>
      <td class="chart-81">4<br>7<br>0</td>
      <td class="chart-97">2<br>8<br>9</td>
      <td class="chart-bold chart-97">97</td>
      <td class="chart-97">1<br>7<br>9</td>
      <td class="chart-34">1<br>4<br>8</td>
      <td class="chart-bold chart-34">34</td>
      <td class="chart-34">3<br>5<br>6</td>
      <td class="chart-54">3<br>4<br>8</td>
      <td class="chart-bold chart-54">54</td>
      <td class="chart-54">1<br>1<br>2</td>
      <td class="chart-02">2<br>9<br>9</td>
      <td class="chart-bold chart-02">02</td>
      <td class="chart-02">1<br>4<br>7</td>
      <td class="chart-75">2<br>7<br>8</td>
      <td class="chart-bold chart-75">75</td>
      <td class="chart-75">6<br>9<br>0</td>
      <td class="chart-98">1<br>2<br>6</td>
      <td class="chart-bold chart-98">98</td>
      <td class="chart-98">9<br>9<br>0</td>
   </tr>
   <tr>
      <td>13-10-2025 <br> To <br> 19-10-2025</td>
      <td class="chart-70">5<br>6<br>6</td>
      <td class="chart-bold chart-70">70</td>
      <td class="chart-70">4<br>7<br>9</td>
      <td class="chart-50">2<br>6<br>7</td>
      <td class="chart-bold chart-50">50</td>
      <td class="chart-50">4<br>8<br>8</td>
      <td class="chart-68">7<br>9<br>0</td>
      <td class="chart-bold chart-68">68</td>
      <td class="chart-68">1<br>2<br>5</td>
      <td class="chart-11">2<br>3<br>6</td>
      <td class="chart-bold chart-11">11</td>
      <td class="chart-11">1<br>1<br>9</td>
      <td class="chart-91">3<br>8<br>8</td>
      <td class="chart-bold chart-91">91</td>
      <td class="chart-91">5<br>7<br>9</td>
      <td class="chart-01">2<br>3<br>5</td>
      <td class="chart-bold chart-01">01</td>
      <td class="chart-01">1<br>4<br>6</td>
      <td class="chart-47">3<br>4<br>7</td>
      <td class="chart-bold chart-47">47</td>
      <td class="chart-47">4<br>5<br>8</td>
   </tr>


      <tr>
        <td>20/10/2025<br/>to<br/>26/10/2025</td>
      
<td class="">1<br>5<br>5</td>
<td class="">13</td>
<td class="">2<br>5<br>6</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="r">5<br>7<br>0</td>
<td class="r">22</td>
<td class="r">1<br>1<br>0</td>


<td class="">2<br>7<br>8</td>
<td class="">73</td>
<td class="">4<br>9<br>0</td>


<td class="">4<br>7<br>9</td>
<td class="">04</td>
<td class="">2<br>3<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">85</td>
<td class="">8<br>8<br>9</td>


<td class="">1<br>2<br>9</td>
<td class="">21</td>
<td class="">1<br>5<br>5</td>

</tr>      <tr>
        <td>27/10/2025<br/>to<br/>02/11/2025</td>
      
<td class="">3<br>3<br>0</td>
<td class="">60</td>
<td class="">5<br>7<br>8</td>


<td class="r">1<br>3<br>4</td>
<td class="r">83</td>
<td class="r">2<br>3<br>8</td>


<td class="">3<br>4<br>9</td>
<td class="">69</td>
<td class="">2<br>8<br>9</td>


<td class="">6<br>8<br>8</td>
<td class="">25</td>
<td class="">1<br>5<br>9</td>


<td class="">1<br>7<br>7</td>
<td class="">54</td>
<td class="">6<br>8<br>0</td>


<td class="r">3<br>4<br>0</td>
<td class="r">72</td>
<td class="r">1<br>1<br>0</td>


<td class="">3<br>5<br>6</td>
<td class="">47</td>
<td class="">4<br>6<br>7</td>

</tr>      <tr>
        <td>03/11/2025<br/>to<br/>09/11/2025</td>
      
<td class="">2<br>7<br>0</td>
<td class="">93</td>
<td class="">2<br>5<br>6</td>


<td class="">1<br>6<br>8</td>
<td class="">58</td>
<td class="">1<br>1<br>6</td>


<td class="">1<br>4<br>0</td>
<td class="">51</td>
<td class="">6<br>7<br>8</td>


<td class="">2<br>6<br>6</td>
<td class="">45</td>
<td class="">2<br>4<br>9</td>


<td class="">3<br>6<br>9</td>
<td class="">82</td>
<td class="">2<br>0<br>0</td>


<td class="">1<br>6<br>0</td>
<td class="">73</td>
<td class="">2<br>5<br>6</td>


<td class="r">1<br>3<br>8</td>
<td class="r">22</td>
<td class="r">7<br>7<br>8</td>

</tr>      <tr>
        <td>10/11/2025<br/>to<br/>16/11/2025</td>
      
<td class="">2<br>4<br>5</td>
<td class="">17</td>
<td class="">3<br>4<br>0</td>


<td class="">1<br>4<br>7</td>
<td class="">23</td>
<td class="">2<br>2<br>9</td>


<td class="">5<br>6<br>7</td>
<td class="">89</td>
<td class="">4<br>7<br>8</td>


<td class="">1<br>5<br>8</td>
<td class="">42</td>
<td class="">3<br>9<br>0</td>


<td class="">5<br>5<br>6</td>
<td class="">65</td>
<td class="">2<br>5<br>8</td>


<td class="">1<br>2<br>9</td>
<td class="">20</td>
<td class="">5<br>6<br>9</td>


<td class="">4<br>9<br>9</td>
<td class="">25</td>
<td class="">1<br>4<br>0</td>

</tr>      <tr>
        <td>17/11/2025<br/>to<br/>23/11/2025</td>
      
<td class="">2<br>2<br>0</td>
<td class="">46</td>
<td class="">3<br>5<br>8</td>


<td class="">1<br>3<br>6</td>
<td class="">07</td>
<td class="">3<br>5<br>9</td>


<td class="r">4<br>6<br>6</td>
<td class="r">61</td>
<td class="r">5<br>6<br>0</td>


<td class="">3<br>4<br>8</td>
<td class="">59</td>
<td class="">5<br>7<br>7</td>


<td class="">1<br>2<br>5</td>
<td class="">86</td>
<td class="">7<br>9<br>0</td>


<td class="">2<br>4<br>8</td>
<td class="">47</td>
<td class="">1<br>1<br>5</td>


<td class="">1<br>6<br>7</td>
<td class="">45</td>
<td class="">8<br>8<br>9</td>

</tr>      <tr>
        <td>24/11/2025<br/>to<br/>30/11/2025</td>
      
<td class="">3<br>6<br>0</td>
<td class="">98</td>
<td class="">2<br>3<br>3</td>


<td class="">9<br>9<br>0</td>
<td class="">85</td>
<td class="">7<br>8<br>0</td>


<td class="">3<br>4<br>4</td>
<td class="">12</td>
<td class="">2<br>3<br>7</td>


<td class="r">1<br>6<br>7</td>
<td class="r">44</td>
<td class="r">2<br>2<br>0</td>


<td class="">7<br>8<br>8</td>
<td class="">39</td>
<td class="">4<br>6<br>9</td>


<td class="">2<br>2<br>7</td>
<td class="">15</td>
<td class="">2<br>3<br>0</td>


<td class="">1<br>4<br>8</td>
<td class="">30</td>
<td class="">4<br>7<br>9</td>

</tr>      <tr>
        <td>01/12/2025<br/>to<br/>07/12/2025</td>
      
<td class="">2<br>9<br>0</td>
<td class="">19</td>
<td class="">4<br>7<br>8</td>


<td class="">2<br>2<br>6</td>
<td class="">01</td>
<td class="">4<br>8<br>9</td>


<td class="">3<br>5<br>9</td>
<td class="">79</td>
<td class="">2<br>3<br>4</td>


<td class="">5<br>5<br>8</td>
<td class="">81</td>
<td class="">2<br>2<br>7</td>


<td class="">1<br>7<br>0</td>
<td class="">89</td>
<td class="">1<br>3<br>5</td>


<td class="r">2<br>3<br>9</td>
<td class="r">49</td>
<td class="r">5<br>5<br>9</td>


<td class="">3<br>7<br>8</td>
<td class="">84</td>
<td class="">1<br>5<br>8</td>

</tr>      <tr>
        <td>08/12/2025<br/>to<br/>14/12/2025</td>
      
<td class="">2<br>5<br>6</td>
<td class="">32</td>
<td class="">5<br>7<br>0</td>


<td class="">1<br>1<br>9</td>
<td class="">15</td>
<td class="">2<br>6<br>7</td>


<td class="r">1<br>6<br>6</td>
<td class="r">38</td>
<td class="r">4<br>5<br>9</td>


<td class="">6<br>7<br>9</td>
<td class="">24</td>
<td class="">3<br>5<br>6</td>


<td class="">9<br>0<br>0</td>
<td class="">91</td>
<td class="">6<br>7<br>8</td>


<td class="r">3<br>8<br>0</td>
<td class="r">16</td>
<td class="r">4<br>5<br>7</td>


<td class="">1<br>2<br>9</td>
<td class="">25</td>
<td class="">1<br>7<br>7</td>

</tr>      <tr>
        <td>15/12/2025<br/>to<br/>21/12/2025</td>
      
<td class="">4<br>8<br>8</td>
<td class="">04</td>
<td class="">3<br>4<br>7</td>


<td class="r">3<br>3<br>6</td>
<td class="r">22</td>
<td class="r">5<br>8<br>9</td>


<td class="">2<br>2<br>5</td>
<td class="">91</td>
<td class="">5<br>6<br>0</td>


<td class="">1<br>2<br>3</td>
<td class="">63</td>
<td class="">4<br>9<br>0</td>


<td class="">2<br>4<br>7</td>
<td class="">37</td>
<td class="">8<br>9<br>0</td>


<td class="">5<br>6<br>9</td>
<td class="">02</td>
<td class="">5<br>8<br>9</td>


<td class="">3<br>7<br>0</td>
<td class="">03</td>
<td class="">2<br>3<br>8</td>

</tr>      <tr>
        <td>22/12/2025<br/>to<br/>28/12/2025</td>
      
<td class="">1<br>2<br>8</td>
<td class="">10</td>
<td class="">5<br>5<br>0</td>


<td class="">1<br>5<br>9</td>
<td class="">51</td>
<td class="">4<br>7<br>0</td>


<td class="">2<br>9<br>9</td>
<td class="">07</td>
<td class="">2<br>7<br>8</td>


<td class="">5<br>6<br>7</td>
<td class="">84</td>
<td class="">1<br>3<br>0</td>


<td class="">3<br>5<br>7</td>
<td class="">51</td>
<td class="">1<br>5<br>5</td>


<td class="r">2<br>5<br>6</td>
<td class="r">38</td>
<td class="r">3<br>5<br>0</td>


<td class="">2<br>3<br>4</td>
<td class="">96</td>
<td class="">1<br>7<br>8</td>

</tr>      <tr>
        <td>29/12/2025<br/>to<br/>04/01/2026</td>
      
<td class="">4<br>8<br>8</td>
<td class="">03</td>
<td class="">6<br>7<br>0</td>


<td class="r">1<br>2<br>4</td>
<td class="r">72</td>
<td class="r">1<br>3<br>8</td>


<td class="">3<br>6<br>6</td>
<td class="">57</td>
<td class="">1<br>1<br>5</td>


<td class="">3<br>5<br>9</td>
<td class="">78</td>
<td class="">2<br>7<br>9</td>


<td class="">1<br>5<br>9</td>
<td class="">52</td>
<td class="">6<br>6<br>0</td>


<td class="r">1<br>8<br>0</td>
<td class="r">94</td>
<td class="r">3<br>5<br>6</td>


<td class="">1<br>4<br>9</td>
<td class="">46</td>
<td class="">2<br>4<br>0</td>

</tr>      <tr>
        <td>05/01/2026<br/>to<br/>11/01/2026</td>
      
<td class="">5<br>7<br>9</td>
<td class="">18</td>
<td class="">3<br>6<br>9</td>


<td class="r">2<br>7<br>7</td>
<td class="r">66</td>
<td class="r">1<br>5<br>0</td>


<td class="">2<br>5<br>6</td>
<td class="">31</td>
<td class="">5<br>8<br>8</td>


<td class="">4<br>7<br>9</td>
<td class="">04</td>
<td class="">6<br>8<br>0</td>


<td class="r">5<br>8<br>9</td>
<td class="r">22</td>
<td class="r">2<br>2<br>8</td>


<td class="">1<br>2<br>8</td>
<td class="">18</td>
<td class="">1<br>3<br>4</td>


<td class="">4<br>5<br>0</td>
<td class="">92</td>
<td class="">3<br>3<br>6</td>

</tr>      <tr>
        <td>12/01/2026<br/>to<br/>18/01/2026</td>
      
<td class="">1<br>2<br>7</td>
<td class="">06</td>
<td class="">3<br>6<br>7</td>


<td class="">1<br>5<br>8</td>
<td class="">42</td>
<td class="">1<br>3<br>8</td>


<td class="">3<br>6<br>9</td>
<td class="">82</td>
<td class="">5<br>7<br>0</td>


<td class="">7<br>8<br>0</td>
<td class="">51</td>
<td class="">2<br>4<br>5</td>


<td class="">1<br>4<br>7</td>
<td class="">20</td>
<td class="">6<br>6<br>8</td>


<td class="">5<br>5<br>6</td>
<td class="">60</td>
<td class="">2<br>8<br>0</td>


<td class="">9<br>9<br>0</td>
<td class="">85</td>
<td class="">3<br>4<br>8</td>

</tr>      <tr>
        <td>19/01/2026<br/>to<br/>25/01/2026</td>
      
<td class="">5<br>6<br>7</td>
<td class="">87</td>
<td class="">3<br>4<br>0</td>


<td class="">7<br>7<br>9</td>
<td class="">36</td>
<td class="">1<br>5<br>0</td>


<td class="r">1<br>4<br>0</td>
<td class="r">50</td>
<td class="r">2<br>2<br>6</td>


<td class="">2<br>0<br>0</td>
<td class="">26</td>
<td class="">1<br>1<br>4</td>


<td class="">3<br>7<br>8</td>
<td class="">80</td>
<td class="">1<br>3<br>6</td>


<td class="r">1<br>8<br>8</td>
<td class="r">72</td>
<td class="r">3<br>9<br>0</td>


<td class="">2<br>2<br>0</td>
<td class="">48</td>
<td class="">3<br>6<br>9</td>

</tr>      <tr>
        <td>26/01/2026<br/>to<br/>01/02/2026</td>
      
<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>2<br>4</td>
<td class="">79</td>
<td class="">1<br>1<br>7</td>


<td class="">3<br>4<br>7</td>
<td class="">45</td>
<td class="">3<br>6<br>6</td>


<td class="">8<br>8<br>9</td>
<td class="">53</td>
<td class="">2<br>2<br>9</td>


<td class="r">3<br>4<br>9</td>
<td class="r">61</td>
<td class="r">1<br>5<br>5</td>


<td class="">2<br>3<br>5</td>
<td class="">02</td>
<td class="">4<br>8<br>0</td>


<td class="">8<br>9<br>9</td>
<td class="">68</td>
<td class="">1<br>2<br>5</td>

</tr>      <tr>
        <td>02/02/2026<br/>to<br/>08/02/2026</td>
      
<td class="">4<br>7<br>0</td>
<td class="">10</td>
<td class="">1<br>9<br>0</td>


<td class="">3<br>3<br>9</td>
<td class="">58</td>
<td class="">5<br>6<br>7</td>


<td class="">1<br>8<br>0</td>
<td class="">91</td>
<td class="">1<br>4<br>6</td>


<td class="">1<br>0<br>0</td>
<td class="">14</td>
<td class="">2<br>4<br>8</td>


<td class="">2<br>6<br>7</td>
<td class="">59</td>
<td class="">4<br>5<br>0</td>


<td class="">1<br>1<br>2</td>
<td class="">42</td>
<td class="">6<br>8<br>8</td>


<td class="">4<br>4<br>0</td>
<td class="">89</td>
<td class="">2<br>3<br>4</td>

</tr>      <tr>
        <td>09/02/2026<br/>to<br/>15/02/2026</td>
      
<td class="">1<br>2<br>7</td>
<td class="">04</td>
<td class="">6<br>8<br>0</td>


<td class="">1<br>1<br>5</td>
<td class="">79</td>
<td class="">2<br>7<br>0</td>


<td class="">4<br>8<br>8</td>
<td class="">01</td>
<td class="">3<br>4<br>4</td>


<td class="">3<br>5<br>9</td>
<td class="">71</td>
<td class="">1<br>3<br>7</td>


<td class="">1<br>6<br>6</td>
<td class="">37</td>
<td class="">3<br>4<br>0</td>


<td class="">5<br>9<br>0</td>
<td class="">45</td>
<td class="">4<br>5<br>6</td>


<td class="">1<br>4<br>8</td>
<td class="">36</td>
<td class="">2<br>6<br>8</td>

</tr>      <tr>
        <td>16/02/2026<br/>to<br/>22/02/2026</td>
      
<td class="">6<br>9<br>0</td>
<td class="">57</td>
<td class="">1<br>8<br>8</td>


<td class="r">3<br>6<br>6</td>
<td class="r">50</td>
<td class="r">2<br>4<br>4</td>


<td class="">1<br>7<br>8</td>
<td class="">64</td>
<td class="">1<br>3<br>0</td>


<td class="">2<br>5<br>6</td>
<td class="">35</td>
<td class="">1<br>5<br>9</td>


<td class="r">3<br>8<br>0</td>
<td class="r">11</td>
<td class="r">2<br>4<br>5</td>


<td class="">5<br>7<br>7</td>
<td class="">93</td>
<td class="">2<br>3<br>8</td>


<td class="">3<br>8<br>9</td>
<td class="">01</td>
<td class="">6<br>6<br>9</td>

</tr>      <tr>
        <td>23/02/2026<br/>to<br/>01/03/2026</td>
      
<td class="r">2<br>4<br>0</td>
<td class="r">61</td>
<td class="r">2<br>3<br>6</td>


<td class="">5<br>5<br>9</td>
<td class="">93</td>
<td class="">2<br>2<br>9</td>


<td class="">3<br>7<br>0</td>
<td class="">07</td>
<td class="">4<br>5<br>8</td>


<td class="r">3<br>4<br>6</td>
<td class="r">33</td>
<td class="r">2<br>4<br>7</td>


<td class="">2<br>2<br>0</td>
<td class="">46</td>
<td class="">1<br>5<br>0</td>


<td class="">1<br>3<br>7</td>
<td class="">13</td>
<td class="">6<br>8<br>9</td>


<td class="r">3<br>6<br>6</td>
<td class="r">55</td>
<td class="r">1<br>5<br>9</td>

</tr>      <tr>
        <td>02/03/2026<br/>to<br/>08/03/2026</td>
      
<td class="">1<br>6<br>8</td>
<td class="">51</td>
<td class="">4<br>8<br>9</td>


<td class="">5<br>6<br>0</td>
<td class="">18</td>
<td class="">4<br>5<br>9</td>


<td class="r">*<br>*<br>*</td>
<td class="r">**</td>
<td class="r">*<br>*<br>*</td>


<td class="">1<br>4<br>4</td>
<td class="">90</td>
<td class="">1<br>3<br>6</td>


<td class="">2<br>6<br>0</td>
<td class="">85</td>
<td class="">7<br>8<br>0</td>


<td class="r">3<br>5<br>9</td>
<td class="r">72</td>
<td class="r">6<br>8<br>8</td>


<td class="r">1<br>6<br>9</td>
<td class="r">61</td>
<td class="r">4<br>7<br>0</td>

</tr>      <tr>
        <td>09/03/2026<br/>to<br/>15/03/2026</td>
      
<td class="">6<br>6<br>7</td>
<td class="">98</td>
<td class="">2<br>3<br>3</td>


<td class="">7<br>7<br>8</td>
<td class="">24</td>
<td class="">2<br>3<br>9</td>


<td class="">1<br>6<br>7</td>
<td class="">41</td>
<td class="">6<br>7<br>8</td>


<td class="">1<br>4<br>8</td>
<td class="">34</td>
<td class="">2<br>5<br>7</td>


<td class="">3<br>4<br>9</td>
<td class="">69</td>
<td class="">1<br>3<br>5</td>


<td class="">1<br>4<br>5</td>
<td class="">01</td>
<td class="">3<br>8<br>0</td>


<td class="">4<br>4<br>0</td>
<td class="">80</td>
<td class="">5<br>7<br>8</td>

</tr></tbody> 
</table>
</div>
</div>
</div>
<div class="clear">&nbsp;</div>
</div>
<div class="container-fluid footer-text-div">
<p>In the vibrant world of Satta Matka, enthusiasts and seasoned players alike turn to resources like SAHARA Panel Chart Records for valuable insights into the game's historical trends. These records serve as a comprehensive repository, offering a visual representation of past results and aiding strategic decision-making in the dynamic SAHARA Satta Matka game.</p>
<br>
<div class="small-heading">Get SAHARA Panel Chart Records Online</div>
<p>The SAHARA Panel Chart is an exhaustive compilation of previous SAHARA Satta Matka results, detailing winning numbers and their frequencies over time. By analyzing these charts, players gain valuable insights into recurring patterns, empowering them to make informed decisions when participating in the unpredictable SAHARA game. Whether you're a newcomer eager to understand the game or a seasoned player looking to refine your strategy, exploring SAHARA Panel Chart Records is an essential step towards mastery.</p>
<br>
<div class="faq-heading">Frequently Asked Questions (FAQ) for SAHARA Panel Chart Records</div>
<p class="faq-title">Q1: How frequently are SAHARA Panel Chart Records updated?</p>
<p class="faq-ans">SAHARA Panel Chart Records are regularly updated to reflect the latest game results. Reputable Satta Matka platforms prioritize maintaining current charts, ensuring that players have access to the most recent information for strategic planning and analysis.</p>
<p class="faq-title">Q2: Can SAHARA Panel Chart Records be relied upon for predicting future game outcomes?</p>
<p class="faq-ans">While SAHARA Panel Chart Records offer insights into historical patterns, it's crucial to acknowledge that Satta Matka involves an element of unpredictability. These records serve as a reference for identifying trends, but they do not guarantee precise future results. Players should approach the game with an understanding that each draw is independent, and outcomes are based on chance. Utilizing SAHARA Panel Chart Records as an analytical tool enhances the Satta Matka experience, contributing to a more strategic and enjoyable gameplay.</p>
</div><br><br>

<center>
	<div id="bottom"></div>
	<a href="#top" class="button2"> Go to Top </a>
</center>
<p>
145</p>
	
	
<!-- adv & links -->
<!-- footer -->
<footer style="font-style: normal;">

  
  <a class="ftr-icon" href="https://dpboss.boston">dpboss.boston</a>
  <p>
    All Rights Reseved®
    <br>
    (1998-2024)
    <br>
    Contact (Astrologer-<span>Dpboss</span>)
  </p>
</footer>

<!--<a class="mp-btn" href="https://dpboss.boston/dpbossplay-matka-online.php"><i>Matka Play</i></a> -->
<a class="mp-btn" href="https://matkabank.mobi/"><i>Matka Play</i></a>

 


    
</body>
</html>