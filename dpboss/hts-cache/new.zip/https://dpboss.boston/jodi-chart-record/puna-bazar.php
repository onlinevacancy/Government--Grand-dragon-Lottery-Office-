<!DOCTYPE html>
<html amp lang="en-in"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Puna Bazar Jodi Chart | Online Jodi Record</title>
<meta name="description" content="We offer one of the finest, and all-time updated Puna Bazar Jodi Chart record, it offers all the live updates and past game results for Online Matka Jodi." />
<meta name="keywords" content="Puna Bazar Chart chart, Puna Bazar Chart bracket, Puna Bazar Chart jodi chart, Puna Bazar Charti chart, Puna Bazar Chart bazar chart, Puna Bazar Chart jodi record, Puna Bazar Chart red jodi chart, Puna Bazar Chart matka chart, online Puna Bazar Chart chart" />
<link rel="canonical" href="https://dpboss.boston/jodi-chart-record/puna-bazar.php"/>
<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "NewsArticle",
		"author": "dpboss.boston",
		"headline": "Open-source framework for publishing content",
		"datePublished": "2015-10-07T12:02:41Z",
		"image": [
			"logo.jpg"
		],
		"publisher": {
      "@type": "Organization",
      "name": "DPBOSS",
      "logo": {
        "@type": "ImageObject",
        "url": "https://dpboss.boston/logo.png"
      }
    }
	}
</script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>

<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="shortcut icon" href="https://dpboss.boston/fav/favicon.ico">
<style amp-custom>
html{scroll-behavior:smooth}
body{background-color:#fc9;
text-align: center;
font-weight: 700;
padding: 0;
font-family: Helvetica,sans-serif;}
.logo {
  background: #fc9;
padding: 0 10px;
display: block;
color: #fff8f8;
margin-bottom: 5px;
letter-spacing: 1px;
font-weight: 700;
border: 3px solid #ff0016;
border-radius: .75em;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);}
  .logo amp-img{width:220px;height:auto;padding:6px 0 0}
.button2{background-color:#a0d5ff;color:#220c82;padding:10px 30px;font-size:14px;margin: 0px 0px 5px 0px;border:2px solid #0000005c;font-weight:800;text-decoration: none;text-shadow:1px 1px #00bcd4;box-shadow:0 8px 10px 0 rgba(0,0,0,.2),0 6px 8px 0 rgba(0,0,0,.19);display:inline-block;transition:all .3s}.ad-div11{text-align:center;margin:0 0 10px}.chart-list{border:2px solid #eb008b;margin-bottom:2px;width:50%;margin:0 auto 10px;text-align:center;font-weight:600}.chart-list.ab1{border-color:#003c6c}.chart-list h4{color:#fff;padding:5px 10px 3px;font-size:24px;border-top-left-radius:7px;margin:0}.chart-list.ab1 h4{background-color:#024c88}.chart-list a{display:block;font-size:22px;padding:5px 7px 4px;text-decoration:none}.chart-list a:hover{text-decoration:none}.chart-list.ab1 a{border-bottom:2px solid #024c88;color:#003c6c}.chart-list a:hover{background-color:#fff;text-decoration:underline}@media only screen and (max-width:500px){.chart-list{width:95%}}footer{background-color:#fff;color:red;font-weight:bold;font-size:25px;text-decoration:none;border:4px groove purple;text-shadow:1px 1px gold;margin:3px}footer > div{border-bottom:2px solid #b2ddff;padding:10px 0;margin-bottom:10px}footer > div a{text-decoration:none}footer > div a:hover{text-decoration:none}footer .ftr-icon{text-decoration:none;font-size:35px;text-transform:uppercase;color:#007bff}footer p{margin:10px 0 10px;line-height:35px}footer p span{color:rgb(51,102,255)}.panel.panel-info{border:1px solid #3f51b5;width:50%;margin:0 auto 0}.panel-heading h1{margin:0;padding:5px}table{border-collapse:collapse}table,th,td{border:1px solid #000}thead{background-color:#ffc107;text-shadow:1px 1px 2px #9a7400ab}tbody td{padding:5px 0;font-size:24px}.red,.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chart-00,.chat-05,.chat-50,.chat-16,.chat-61,.chat-27,.chat-72,.chat-38,.chat-83,.chat-49,.chat-94{color:red}
.chart-05,.chart-50,.chart-16,.chart-61,.chart-27,.chart-72,.chart-38,.chart-83,.chart-49,.chart-94{color:red}

.css-11, .css-16, .css-22, .css-27, .css-33, .css-38, .css-44, .css-49, .css-50, .css-55, .css-61, .css-66, .css-72, .css-83, .css-88, .css-94, .css-99, .css-05, .css-00, .css-77, .css-star {
    color: red;
}

@media only screen and (max-width:770px){.panel.panel-info{width:70%}} 
@media only screen and (max-width:500px){
	.panel.panel-info{width:100%}
}.r{color: red;}td{font-weight: 700;}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
}

.para3 {
  background: linear-gradient(187deg,#fc9 50%,#ffc387 50%);
  border: 2px solid #ff0016;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
  border-style: outset;
  margin-bottom: 3px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
}

.chart-h1{
background: #ff00a2;;
padding: 5px 10px;
text-shadow: 1px 1px 2px #000;
display: block;
color: #fff8f8;
margin-bottom: 3px;
letter-spacing: 1px;
font-weight: 700;
border: 2px solid #fff;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1) , background 150ms cubic-bezier(0,0,.58,1);
font-size: 18px;
margin: 3px 0px;
}

h1{
color: #fff8f8;
}

.logo img {
  margin: 5px 0px;
}

h3{font-size: 16px;color:#fff; text-shadow: 0px 0px;margin: 0px;padding: 5px;}

.chart-result {
  margin: 6px 2px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
  border: 1px solid black;
}
.chart-result div {
  font-size: 22px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
}

.chart-result span {
  color: #880e4f;
  text-shadow: 1px 1px 2px #ffe2c6;
  font-size: 21px;
}

.chart-result a {
  border: 1px solid #e6e6e6;
  background: #522f92;
  color: #fff;
  padding: 5px 7px;
  font-size: 12px;
  margin: 2px 0 -1px;
  display: inline-block;
  transition: all .3s;
  cursor: pointer;
  text-shadow: none;
  text-decoration: none;
}
@media screen and (max-width: 400px) {
.logo img {height: 60px;width: auto;max-width: 100%;}
}

@media screen and (max-width: 300px) {
.logo img {height: 40px;width: auto;max-width: 100%;}
}


.footer-text-div p.faq-title {
  font-weight: 600;
}

.footer-text-div {
  max-width: 100%;
  text-align: center;
  margin: 2px;
  border: 2px solid purple;
  background: white;
  padding: 10px;
}

.small-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}

.footer-text-div p {
  font-weight: 500;
  font-size: 12px;
  padding: 0px;
  margin: 0px;
}

.faq-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}
</style></head>
<body>   
<div class="logo" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://dpboss.boston/">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhsAAABpCAMAAACkjBFsAAAAvVBMVEUAAADrAIz/AKDrAIwAAADuAJHrAI0AAADsAI0AAAAAAADrAI3rAIwAAADsAI33AJkAAADrAI3wAJEAAADtAI7rAI3sAI0AAADrAI0AAAAAAADsAI0AAADsAI70AJPuAI8AAADsAI3uAI8AAAAAAADsAI0AAAAAAAAAAADsAI0AAADsAI3sAI0AAAAAAAAAAADsAI4AAAAAAADrAI3sAI3tAI0AAADrAI3tAI4AAAAAAAAAAAAAAAAAAADsAIxr+UChAAAAPXRSTlMA+wX29h7xDeOBxNPq4aYMF9wRbj/KgC+31CCSYTcXJ6vAL+q3ZE8GQ3Q5sIrKlotGpHlrXE0mnFWd7VgIj72kFgAAEBFJREFUeNrs2k2rozAUBuB8kEwgQYmYEAgqClKKLgQtduX//1nT5CadKdyBWd+cZ9GWQ3e+5JyjIgAAAAAAAApyQwBAMsD/Ig1rD+udVDxQQjo7b1NPEChaCMa8OiOFUvQKMOVKm+U8JlYjUK6m3SsjOL7+wBi/PriSi90gHOWqH14Kiq9vcVm1NQwiRSLsqDT/Jhj0JZapPNsaxo4CDfOi6fUXnL6UHEctQm+h2k8NhKM4xI78IxkvMR5Yrl07WxOPFFW1DQJFIf2hP9uJck7HiLx+MULY00saDhHf1nD/oyj97DC+Msx1NT+suSKqD4ZQPd1daDnSDwSiUZKpCtHI+OhbxrzISfEdCeGYNQ3ryt5ANgrSzx8dZTkYuXWO5mPEtSQuMosKx4jrYBwtSHfyK8PCTzVC5JA4bSv07EgcMQ4TSsoyBIoRLnpCRxsHimHlOFXEkR6mMK9CwWxwcJTjLnG+paHtFBtI6yjOaQmVgO06FMQOe2w5VnElwg4xCP0ucC6tOQr1ZmioVDBxlOOdDb0OJC0u+djg1QMlZHKxaO7w1K0Qv5BNa4qqupSCh3wfGzNDCRm+EqPOAYEi3G67jL2Cmp2gqLc8ry2mrVHWV/F/3G0IFGJbvq65nT6aR0BPht6ak8aafKJ/IARGkZ+F3ePAMea3d+qnvhJ5NOit8TEbWO0EZcNvds50TU0YCsMQQFwAQVBxwW3ccUbEXVvv/7Kq4XCSYG3n6U/q96PPQBapefOdk5AZL9AACKIF+yjQ3q9q8yQSWEX5bhsajOpohXthVp88syE3EJhRIwwbEa1UCxphve4fGydPe+ORG1W9lWP48P59RiZDBbINh9/LIL0O3O9oKS2Lu8MYw05QlUjUoevewuP0cfSmIy8i1VGjM+nB1eM1G6juEa6WZimpm6SGExYeODirU987Vgpw9KNQtyb9Nxy5EZdFRsM0EzWOhHeXkQ9shCOAZWFAxaF1p0S+FY0k6twq77cuedIMj4AV0DYWQuQJ0lgzDJKaHl3PyHAeXTbqi0Vo3H+kO+tv48iftJAtYD2+oBZV5ISEoQfrG+HdvtHZV2s7MB3Ff//OQt5EpH0FB3shBAY4OMjY8I5gG1SGH/UeSx64dBbvlCNnIjVuTzSqCWwsjAQFOWGDTOrc2WPFOj1Y0FYy3LH2bzbyJRJYGFIsMZ/sr4Aa2Q+S9YxDWaH/KMmLF8K22ytb6a1cqXfCkOLsxIwhsBRIPOk6hURDA23jVrS0Gm3fUPB9/9s38iW2Jyr7fbFoP8Rw8Sipbg2FrVL8CRwOWykpLZ13MporcTlEcVXNHg9LUehoNKTcbsiGA2kr6XcYG7VvLJyb1/ja1J8L7Hk3dq/Lp/rLqxt357r0LzpM3e7Sfr6vz7uu253PpG9KX3bjafO/O25fwz1ReXgiIjb3IjkpWtXul3ufy0R9jwAbR5lno/szldoan109M1hnNSkbZCBwP6FVy/0hMS0HKnS2PkhParPPMsub2M7AVvpICstTsWA6hk4va2gC1xmlzz4fw4d8HRgtycNKqM3j+kPKlYIQQ0qoZbAZGqlNLKqPxMJhtlHf9gCgKITm1HeADdQl5ujQB1zJ2OYQaHEF5hzrb7jbamn2gg2scW5zhbHKddnkkBnwTdy/smGXuVvnGbJB5eaajUmFnRPN2Ea/ooBvGI/cYhQqaBuKFUCtKotJToMgG0wmMmC3xII2ooFjI3zjeku8XdZfsIFS0Y1mA7EAebNNscngL2w0xfqftsCGaueXDVKz0DaGu+xf5yiCT8jO/n59AtugGGD4qa2K0J5uuCMbTGWYa7qZKbjYMMRPQ3Ol98fZ2+NXbKA+Ut4G2ZIUjla24PwnNp6frYVsUG3yy4Y0Gt5AhU4gFmkNBVAo1L07Kg0Z16+FELdA+5aBy5wdsvFVKpXWA4ABwv0aJmo8dTcqzFmqM9j74Ud7nhi4ScM8fPtLW2+uVRzgJzbG9LNgzNeQUgCWpWn3y0y6TNIYQPdrqdvLc/LzQZLiUiKT1oQLGsOS51E37jQG3GJgA7TMLRvVXREjwlYTLWXvy2AURasvVUeWjCGlgjsZxKvLKTBHD798iO8uN17N5Fue8lFkzqL95QATHo3ji48v098ZRxtrYJct3qLWGMrwYszT6oJxoD4pUHDBULok/50r/QT1ILDRmuWVDa2DOcQwIkJRD1ewt0qjJ1VPFbQN2YpmaQdbhMto9EmGDanMxmvARgVIgWGwYehgvHG8xugg2JP6gg2qmF7ZIpMsxVB1DCmfEijxiT+wYYKzJLoylnQMMnFO2SB7FlKOfbFoFBYAhdtjm2u0MmS0jb2GMalTwLu7nugbOPcfdv4DpzX4A47kQcz41TTafGID1tPsD2xMmRWVxTzRZUmMKdjP+BUbAsEbEZWLyIbazicbvQXO+sqilslE6w8uKA+WJ0kntkoxwhFajBciMXVP+j0bKptzXex/juM6QwsRNcA5K+g1G/jJdiZW6CoSgdRwes1GCboUIZsDG6BxPtkIcNYrfkQymahxAynbqkQazg3Z4DBa1HE3bKU9s9HCL2+NPiH6A+Z74zYUiANhTr/DBnJ4mQEl4BNcQPpgj9Gaf4+NMfiE6CMltvfF4uQmsaDciOx8GY/paGKR5yupb1T2d4qYbSh1jWA1H3dVCxOSZaO9YTY/yOYLJo7DNJ2AXV3i9MOEbC8+fIMNPYZxQ6qWEip5Dpp7qNCp2/4GGy0+rCERZ/ypVE6WQDn0jdoKzcCZEJGNrYOGYI3ulxW0jWKHoaE5iIwTcZn9Z/muD1gvSlI2e8C5bOKMh6103iXmKi4GXPs1G2b5LhO3x5hHZWNDG0AElQHF12ygt6EulGHGRpvWWOePDdK3CmKywKRZBbANubjQ7hRxtnFitfZG0hyOeCAbTCakGJgEZucyG0x4x6EzOD64qL58xQaTCm1Fj8KHWuJKFFFsv2ZDXEGJRoJsJNSph9yxAX9CAV/CZ0+KAgtDj0iBz2zD0hCuoMMS1JX2ezbghYoqsIFmASA0P7kWjAKdVgLFf2fj6xd757qeJhCEYVkUSETwAKJGQbCeDUk1Gjw83v9ltUSYb5dKbP9Svl9toj6EfZ2ZnRlmBxQmEBswFjMUVFBP+Y6NAdgQjR3YuNxcY+HYaKMzWEvCSyy6IiXRhvJSq7Bp64rsJ7kUF55Gan20wYag56+M5AS3nWcDy/fM11NIg2OV+6BcNlCjuWs3zmJW1eHoGD+0G6HAhmg3UuyGBWOD1T51NIoygZqpLUnkQlilDfugbDw+XoV1GTGOjeEiVqef3FxYY+hH9mY64QmJaEhNPgWrlGEjXMQajlHuCLPxxja7HW5uGzBHfxlvIIAGGymIE7VgbFi+nC54L8hQ89W5cZtM7DHmra/oG2wTQUi4xy/jXbvDA1Ad3LHzgAW6DBPX0hCjxNXPKgpmD/Kiw+RfuAYhOIUW48StOPlsNJBF5WEBG7TzCYvFRnvKjXGqCYFoPDMw+Z2/MyvtyKZItIfxHO+GQi7F3pn32HBo9Y5JeEGaIADhtGhQaEBCjDD+jo05hbtD8TPgZEQdnimeyGHjFXupTHCqZnfM/SLlN5iHdLc/ZXOhyianxXi5O2KVAHkwHVU2lzrGkrGTGTbwRTvSHZzdSSM9xZoRHKmhn8U/3orJjv53bCADfsh4oPkpXfNh/KGdTL40n403+CLujzuDDa7sXyS7YVo9mVY284S0fpWkxB7s25VKZGCXMk3Nhmu1FHiaqVvJZyOkr9xzNiOO3W2WJvgBFPKrj9no02pVyUh16HU/8Sl/U09ZcZDhcy8ZNlbFY4Mb8SU8zubub9uX2K0ocW2VdbntyB5bGf1KwuxisIHb1kF1fCGYjT4S2mqGpqxj+PmQDfVEbmcLZ4GKfZOSYCtx2/GoDlsV67DjCthIrq1obLiorttRm2MmMiTkuUYmTf2KJaVBK/M2hBZGF2fZcBpYi5nQv3HCyndud3zOv394i/HQ1jE4wbo4nbOaYQN9nVtkxu/0bzhCm+Kh+l3/BiCbOHzDkPMHG81TwdjwEESsR0wY6ZNaDVlbxr+wbEzFN7x0KhR3MI/kwyeh7+sp/CG00Y1z+r4uk6Sodrg0F2GVfE2YtBA7zYvT4Zp1nggZ9H09vf2o8hXzzp99Xyp3EdWO01SdbQNsiWxAfaHvCzyAjVidgrFhYab5i8tnvXQJlROPxaUVDWysa8kcDltGq4/WdcVwTZRD3y4IpXLUTaAxWol5TZoowIMNQR14C1EL9PmI6qs5bMC08GrMeTbojcViI0pDUUneIdNprRWJjugy9jEaXtLkg0EcbCTMWlD8EZvns/FG9xnrAksda1bNLNcFzkDsIkfH2F02kItQf4hvPVOMIlwEggmRDWghEt0fVO6x4RSLjZ0tobqezGpxo08NzeTKrYPUsuE95PrONd191+fQkOyuO8+1G/1zzvMpz00x0wC9DtK955vA0pnbeL7dY2OyVXOeT1lxF3EUzMAiL2dOMPHXNlYrIhupwkKx0a2nbGhRYjS8na9wAWYvMOPYFGetyLKk9JbTZU+XrpDcDZjIBh5sC8+ZdFOYrFj2ubZZ2EgLrvxqOU+v6SLS826z0+8XqcQGPdh2pFdk8uKvmYtYvfVTcIf5dVholWZQj7AxWTbUSZHYQO+G1g1qbi3Y79baFdKN99sJOy/ES91vXWVN02TxHNnRPx3M1HRWzt1uDPWwWh2a998wEJLoeP8DNQ94q6D5IL4K9R8v+r8RspqKbXx+Gmu7Fe9NUIq/zWlpWz79bLP/AkriHYpsL8vZs0UTn/FWFF1XZFnmVt2fumltBSOLXctQwM/tefpuUKJRNJFPIUmcNaAk+Gij01SfIM5+6DJeKZXHQBZSEVVR4SbgUKgS/0FVl1a81WXBxpbJ98j1aa1Eo3iqTes3E6HXNUXwE7rftSiZhVpKcvqjFxnaDQ69/vlRnldfRLFg04rdQ91Yvvh1XcFx9OtpYOKUDMqsJ4dnMHf00qu3tJa9jhEqVUjVIqNeN/ZmhbnBx2bd823f7xk7y2UAiBtnvUQ5zvXe30derTw7pbBirvUxHX2RwMyaZ71H0bvltfkVZ0scrBLxo9BNk5XH6hRZjJnITTD8DzIpYFWMoFKqFIm5dMhw66U856CU0BtGkai9K4eHluLk4vQMwyqji1K/2ruXFAZhIADDEqkUAoaKFTdWFLKQduFC0fufrCDtzKTeoPzfJWYymYcKZnr+RUiBUa2SbhQLN+mRngqVvbQ1pXEYo7aU8kpBYm0lpEyEFFjR6zgbrxQYbrua9nJAuNDmeok8A0S46P63hqIojGq+SbdPzAD1iNIp6tcMSC6AyhQTqSgMN5Zy3HMjFYXh9DPFT6SiMCpdHjosVL5ghOi1dyMDVNgHqW7w0QbL9d/99vlOSEEidP5z8JOQgpQLzbGxJ38yfYAfrjuGYQv6enDixmm4+7KmuoGzapzrnpYvAAD+zxsTdnYFikaAUwAAAABJRU5ErkJggg==" alt="Image of dpboss.boston" height="57" width="292">

</a>
</div>
<div class="container-fluid">
<div>

<h1 class="chart-h1" >PUNA BAZAR JODI CHART</h1>
<div class="para3">
<h2 style="font-size: 14px;margin: 0px;"> PUNA BAZAR JODI RESULT CHART RECORDS </h2>
<p style="margin: 0;font-size: 12px;line-height: 14px;">Dpboss PUNA BAZAR jodi chart, PUNA BAZAR jodi chart, old PUNA BAZAR jodi chart, dpboss PUNA BAZAR chart, PUNA BAZAR jodi record, PUNA BAZARjodi record, PUNA BAZAR jodi chart 2015,
PUNA BAZAR jodi chart 2012, PUNA BAZAR jodi chart 2012 to 2023, PUNA BAZAR final ank, PUNA BAZAR jodi chart.co,
PUNA BAZAR jodi chart matka, PUNA BAZAR jodi chart book, PUNA BAZAR matka chart, matka jodi chart PUNA BAZAR, matka PUNA BAZAR chart,
satta PUNA BAZAR chart jodi, PUNA BAZAR state chart, PUNA BAZAR chart result,
डीपी बॉस,  सट्टा चार्ट, सट्टा मटका जोड़ी चार्ट, सट्टा मटका जोड़ी चार्ट, पुना बाजार मटका जोड़ी चार्ट, सट्टा मटका पुना बाजार चार्ट जोड़ी, पुना बाजार सट्टा चार्ट, पुना बाजार जोड़ी चार्ट </p>
</div>

<div class="chart-result">    
		<div>PUNA BAZAR</div>
		<span>680-47-340</span><br>
		<a href="puna-bazar.php">Refresh Result</a>
</div>
	
<div id="top"></div>
<a href="#bottom" class="button2"> Go to Bottom </a>
<div class="panel panel-info" >
<div class="panel-heading text-center" style="background: #3f51b5;"><h1 style="font-size: 22px;color:#fff; text-shadow: 0px 0px;"> Puna bazar Jodi Chart </h1></div> 
<div class="panel-body">
<table style="width: 100%; text-align:center;" class="panel-chart chart-table"  cellpadding="2">
<thead>
<tr>
<th>Mon</th>
<th>Tue</th>
<th>Wed</th>
<th>Thu</th>
<th>Fri</th>
<th>Sat</th>
<th>Sun</th>
</tr>
</thead>                	
<tbody>
<tr>
  <td class="chart-20">20</td>
  <td class="chart-33">33</td>
  <td class="chart-04">04</td>
  <td class="chart-96">96</td>
  <td class="chart-13">13</td>
  <td class="chart-50">50</td>
</tr>
<tr>
  <td class="chart-12">12</td>
  <td class="chart-04">04</td>
  <td class="chart-69">69</td>
  <td class="chart-92">92</td>
  <td class="chart-54">54</td>
  <td class="chart-57">57</td>
</tr>
<tr>
  <td class="chart-98">98</td>
  <td class="chart-89">89</td>
  <td class="chart-36">36</td>
  <td class="chart-17">17</td>
  <td class="chart-62">62</td>
  <td class="chart-24">24</td>
</tr>
<tr>
  <td class="chart-22">22</td>
  <td class="chart-58">58</td>
  <td class="chart-55">55</td>
  <td class="chart-69">69</td>
  <td class="chart-01">01</td>
  <td class="chart-34">34</td>
</tr>
<tr>
  <td class="chart-12">12</td>
  <td class="chart-80">80</td>
  <td class="chart-46">46</td>
  <td class="chart-24">24</td>
  <td class="chart-15">15</td>
  <td class="chart-70">70</td>
</tr>
<tr>
  <td class="chart-48">48</td>
  <td class="chart-85">85</td>
  <td class="chart-25">25</td>
  <td class="chart-91">91</td>
  <td class="chart-13">13</td>
  <td class="chart-15">15</td>
</tr>
<tr>
  <td class="chart-15">15</td>
  <td class="chart-09">09</td>
  <td class="chart-25">25</td>
  <td class="chart-18">18</td>
  <td class="chart-92">92</td>
  <td class="chart-96">96</td>
</tr>
<tr>
  <td class="chart-97">97</td>
  <td class="chart-00">00</td>
  <td class="chart-12">12</td>
  <td class="chart-43">43</td>
  <td class="chart-59">59</td>
  <td class="chart-87">87</td>
</tr>
<tr>
  <td class="chart-14">14</td>
  <td class="chart-67">67</td>
  <td class="chart-06">06</td>
  <td class="chart-79">79</td>
  <td class="chart-67">67</td>
  <td class="chart-88">88</td>
</tr>
<tr>
  <td class="chart-87">87</td>
  <td class="chart-92">92</td>
  <td class="chart-31">31</td>
  <td class="chart-28">28</td>
  <td class="chart-75">75</td>
  <td class="chart-44">44</td>
</tr>
<tr>
  <td class="chart-86">86</td>
  <td class="chart-23">23</td>
  <td class="chart-60">60</td>
  <td class="chart-71">71</td>
  <td class="chart-53">53</td>
  <td class="chart-93">93</td>
</tr>
<tr>
  <td class="chart-63">63</td>
  <td class="chart-81">81</td>
  <td class="chart-70">70</td>
  <td class="chart-95">95</td>
  <td class="chart-80">80</td>
  <td class="chart-25">25</td>
</tr>
<tr>
  <td class="chart-01">01</td>
  <td class="chart-50">50</td>
  <td class="chart-36">36</td>
  <td class="chart-42">42</td>
  <td class="chart-09">09</td>
  <td class="chart-87">87</td>
</tr>
<tr>
  <td class="chart-39">39</td>
  <td class="chart-53">53</td>
  <td class="chart-77">77</td>
  <td class="chart-98">98</td>
  <td class="chart-65">65</td>
  <td class="chart-14">14</td>
</tr>
<tr>
  <td class="chart-03">03</td>
  <td class="chart-52">52</td>
  <td class="chart-53">53</td>
  <td class="chart-20">20</td>
  <td class="chart-92">92</td>
  <td class="chart-48">48</td>
</tr>
<tr>
  <td class="chart-54">54</td>
  <td class="chart-10">10</td>
  <td class="chart-77">77</td>
  <td class="chart-52">52</td>
  <td class="chart-21">21</td>
  <td class="chart-81">81</td>
</tr>
<tr>
  <td class="chart-45">45</td>
  <td class="chart-45">45</td>
  <td class="chart-58">58</td>
  <td class="chart-00">00</td>
  <td class="chart-68">68</td>
  <td class="chart-05">05</td>
</tr>
<tr>
  <td class="chart-08">08</td>
  <td class="chart-95">95</td>
  <td class="chart-21">21</td>
  <td class="chart-84">84</td>
  <td class="chart-32">32</td>
  <td class="chart-16">16</td>
</tr>
<tr>
  <td class="chart-69">69</td>
  <td class="chart-47">47</td>
  <td class="chart-49">49</td>
  <td class="chart-83">83</td>
  <td class="chart-98">98</td>
  <td class="chart-19">19</td>
</tr>
<tr>
  <td class="chart-17">17</td>
  <td class="chart-38">38</td>
  <td class="chart-97">97</td>
  <td class="r">*</td>
  <td class="chart-83">83</td>
  <td class="chart-14">14</td>
</tr>
<tr>
  <td class="chart-62">62</td>
  <td class="chart-71">71</td>
  <td class="chart-49">49</td>
  <td class="chart-03">03</td>
  <td class="chart-79">79</td>
  <td class="chart-79">79</td>
</tr>
<tr>
  <td class="chart-70">70</td>
  <td class="chart-47">47</td>
  <td class="chart-78">78</td>
  <td class="chart-92">92</td>
  <td class="chart-71">71</td>
  <td class="chart-76">76</td>
</tr>
<tr>
  <td class="chart-52">52</td>
  <td class="chart-41">41</td>
  <td class="chart-28">28</td>
  <td class="chart-58">58</td>
  <td class="chart-98">98</td>
  <td class="chart-83">83</td>
</tr>
<tr>
  <td class="chart-08">08</td>
  <td class="chart-48">48</td>
  <td class="chart-68">68</td>
  <td class="chart-01">01</td>
  <td class="chart-82">82</td>
  <td class="chart-73">73</td>
</tr>
<tr>
  <td class="chart-40">40</td>
  <td class="chart-43">43</td>
  <td class="chart-26">26</td>
  <td class="chart-64">64</td>
  <td class="chart-44">44</td>
  <td class="chart-69">69</td>
</tr>
<tr>
  <td class="chart-74">74</td>
  <td class="chart-75">75</td>
  <td class="chart-44">44</td>
  <td class="chart-77">77</td>
  <td class="chart-15">15</td>
  <td class="chart-62">62</td>
</tr>
<tr>
  <td class="chart-17">17</td>
  <td class="chart-22">22</td>
  <td class="chart-30">30</td>
  <td class="chart-08">08</td>
  <td class="chart-13">13</td>
  <td class="chart-36">36</td>
</tr>
<tr>
  <td class="chart-18">18</td>
  <td class="chart-72">72</td>
  <td class="chart-68">68</td>
  <td class="chart-90">90</td>
  <td class="chart-62">62</td>
  <td class="chart-66">66</td>
</tr>
<tr>
  <td class="chart-42">42</td>
  <td class="chart-14">14</td>
  <td class="chart-66">66</td>
  <td class="chart-29">29</td>
  <td class="chart-86">86</td>
  <td class="chart-09">09</td>
</tr>
<tr>
  <td class="chart-73">73</td>
  <td class="chart-51">51</td>
  <td class="chart-43">43</td>
  <td class="chart-25">25</td>
  <td class="r">*</td>
  <td class="r">*</td>
</tr>
<tr>
  <td class="r">*</td>
  <td class="r">*</td>
  <td class="r">*</td>
  <td class="r">*</td>
  <td class="r">*</td>
  <td class="r">*</td>
</tr>
<tr>
  <td class="chart-04">04</td>
  <td class="chart-92">92</td>
  <td class="chart-11">11</td>
  <td class="chart-84">84</td>
  <td class="chart-41">41</td>
  <td class="chart-31">31</td>
</tr>
<tr>
  <td class="chart-47">47</td>
  <td class="chart-79">79</td>
  <td class="chart-64">64</td>
  <td class="chart-11">11</td>
  <td class="chart-96">96</td>
  <td class="chart-43">43</td>
</tr>
<tr>
  <td class="chart-69">69</td>
  <td class="chart-42">42</td>
  <td class="chart-01">01</td>
  <td class="chart-88">88</td>
  <td class="chart-86">86</td>
  <td class="chart-70">70</td>
</tr>
<tr>
  <td class="chart-18">18</td>
  <td class="chart-82">82</td>
  <td class="chart-09">09</td>
  <td class="chart-69">69</td>
  <td class="chart-62">62</td>
  <td class="chart-54">54</td>
</tr>
<tr>
  <td class="chart-52">52</td>
  <td class="chart-12">12</td>
  <td class="chart-10">10</td>
  <td class="chart-36">36</td>
  <td class="chart-68">68</td>
  <td class="chart-06">06</td>
</tr>
<tr>
  <td class="chart-46">46</td>
  <td class="chart-94">94</td>
  <td class="chart-93">93</td>
  <td class="chart-08">08</td>
  <td class="chart-10">10</td>
  <td class="chart-24">24</td>
</tr>
<tr>
  <td class="chart-10">10</td>
  <td class="chart-83">83</td>
  <td class="chart-53">53</td>
  <td class="chart-08">08</td>
  <td class="chart-47">47</td>
  <td class="chart-14">14</td>
</tr>
<tr>
  <td class="chart-39">39</td>
  <td class="chart-17">17</td>
  <td class="chart-12">12</td>
  <td class="chart-25">25</td>
  <td class="chart-71">71</td>
  <td class="chart-75">75</td>
</tr>
<tr>
  <td class="chart-84">84</td>
  <td class="chart-79">79</td>
  <td class="chart-90">90</td>
  <td class="chart-84">84</td>
  <td class="chart-89">89</td>
  <td class="chart-23">23</td>
</tr>
<tr>
  <td class="chart-04">04</td>
  <td class="chart-64">64</td>
  <td class="chart-68">68</td>
  <td class="chart-51">51</td>
  <td class="chart-20">20</td>
  <td class="chart-17">17</td>
</tr>
<tr>
  <td class="chart-01">01</td>
  <td class="chart-25">25</td>
  <td class="chart-44">44</td>
  <td class="chart-08">08</td>
  <td class="chart-93">93</td>
  <td class="chart-75">75</td>
</tr>
<tr>
  <td class="chart-51">51</td>
  <td class="chart-89">89</td>
  <td class="chart-42">42</td>
  <td class="chart-07">07</td>
  <td class="chart-83">83</td>
  <td class="chart-67">67</td>
</tr>
<tr>
  <td class="chart-95">95</td>
  <td class="chart-78">78</td>
  <td class="chart-51">51</td>
  <td class="chart-01">01</td>
  <td class="chart-99">99</td>
  <td class="chart-67">67</td>
</tr>
<tr>
  <td class="chart-81">81</td>
  <td class="chart-70">70</td>
  <td class="chart-63">63</td>
  <td class="chart-47">47</td>
  <td class="chart-08">08</td>
  <td class="chart-20">20</td>
</tr>
<tr>
  <td class="chart-70">70</td>
  <td class="chart-67">67</td>
  <td class="chart-06">06</td>
  <td class="chart-11">11</td>
  <td class="chart-86">86</td>
  <td class="chart-48">48</td>
</tr>
<tr>
  <td class="chart-47">47</td>
  <td class="chart-31">31</td>
  <td class="chart-64">64</td>
  <td class="chart-06">06</td>
  <td class="chart-55">55</td>
  <td class="chart-10">10</td>
</tr>
<tr>
  <td class="chart-68">68</td>
  <td class="chart-24">24</td>
  <td class="chart-30">30</td>
  <td class="chart-26">26</td>
  <td class="chart-88">88</td>
  <td class="chart-42">42</td>
</tr>
<tr>
  <td>35</td>
  <td>34</td>
  <td class='chart-00'>94</td>
  <td>45</td>
  <td>57</td>
  <td>82</td>
</tr>
<tr>
  <td>79</td>
  <td class='chart-00'>**</td>
  <td>21</td>
  <td>19</td>
  <td class='chart-00'>83</td>
  <td>28</td>
</tr>
<tr>
  <td class='chart-00'>22</td>
  <td>58</td>
  <td>01</td>
  <td>01</td>
  <td>70</td>
  <td>73</td>
</tr>
<tr>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
</tr>
<tr>
  <td>60</td>
  <td class='chart-00'>72</td>
  <td>95</td>
  <td class='chart-00'>94</td>
  <td>04</td>
  <td>23</td>
</tr>
<tr>
  <td>62</td>
  <td>29</td>
  <td class='chart-00'>05</td>
  <td>67</td>
  <td>10</td>
  <td>93</td>
</tr>
<tr>
  <td>35</td>
  <td>63</td>
  <td>92</td>
  <td>82</td>
  <td>91</td>
  <td>04</td>
</tr>
<tr>
  <td>58</td>
  <td class='chart-00'>50</td>
  <td>23</td>
  <td>68</td>
  <td>93</td>
  <td>04</td>
</tr>
<tr>
  <td>95</td>
  <td>71</td>
  <td>32</td>
  <td>71</td>
  <td>34</td>
  <td class='chart-00'>99</td>
</tr>
<tr>
  <td>85</td>
  <td>10</td>
  <td>29</td>
  <td>20</td>
  <td>78</td>
  <td class='chart-00'>50</td>
</tr>
<tr>
  <td class='chart-00'>94</td>
  <td>37</td>
  <td>86</td>
  <td>62</td>
  <td>90</td>
  <td>35</td>
</tr>
<tr>
  <td>29</td>
  <td class='chart-00'>22</td>
  <td>01</td>
  <td>98</td>
  <td class='chart-00'>66</td>
  <td>95</td>
</tr>
<tr>
  <td class='chart-00'>83</td>
  <td>91</td>
  <td>36</td>
  <td>2*</td>
  <td>45</td>
  <td>41</td>
</tr>
<tr>
  <td>19</td>
  <td class='chart-00'>22</td>
  <td>25</td>
  <td>14</td>
  <td>89</td>
  <td>29</td>
</tr>
<tr>
  <td>56</td>
  <td>96</td>
  <td>84</td>
  <td class='chart-00'>88</td>
  <td>78</td>
  <td>75</td>
</tr>
<tr>
  <td>56</td>
  <td>96</td>
  <td>84</td>
  <td class='chart-00'>88</td>
  <td>78</td>
  <td>75</td>
</tr>
<tr>
  <td>09</td>
  <td>62</td>
  <td>47</td>
  <td>56</td>
  <td class='chart-00'>38</td>
  <td>25</td>
</tr>
<tr>
  <td>52</td>
  <td>93</td>
  <td>24</td>
  <td class='chart-00'>83</td>
  <td>04</td>
  <td>70</td>
</tr>
<tr>
  <td>21</td>
  <td>37</td>
  <td>97</td>
  <td class='chart-00'>11</td>
  <td>29</td>
  <td class='chart-00'>**</td>
</tr>
<tr>
  <td>42</td>
  <td>57</td>
  <td>14</td>
  <td>48</td>
  <td>67</td>
  <td class='chart-00'>22</td>
</tr>
<tr>
  <td>37</td>
  <td>31</td>
  <td>08</td>
  <td>41</td>
  <td>57</td>
  <td>46</td>
</tr>
<tr>
  <td>65</td>
  <td>40</td>
  <td>90</td>
  <td>28</td>
  <td class='chart-00'>66</td>
  <td>26</td>
</tr>
<tr>
  <td>35</td>
  <td>19</td>
  <td class='chart-00'>55</td>
  <td class='chart-00'>61</td>
  <td>47</td>
  <td>71</td>
</tr>
<tr>
  <td>32</td>
  <td>17</td>
  <td>31</td>
  <td class='chart-00'>38</td>
  <td>69</td>
  <td>82</td>
</tr>
<tr>
  <td>79</td>
  <td class='chart-00'>61</td>
  <td>78</td>
  <td class='chart-00'>38</td>
  <td>08</td>
  <td>48</td>
</tr>
<tr>
  <td>15</td>
  <td>96</td>
  <td>26</td>
  <td>59</td>
  <td>64</td>
  <td>12</td>
</tr>
<tr>
  <td>80</td>
  <td>98</td>
  <td>32</td>
  <td class='chart-00'>77</td>
  <td>01</td>
  <td>68</td>
</tr>
<tr>
  <td class='chart-00'>88</td>
  <td>64</td>
  <td>70</td>
  <td>12</td>
  <td>45</td>
  <td class='chart-00'>27</td>
</tr>
<tr>
  <td>32</td>
  <td>70</td>
  <td>35</td>
  <td>14</td>
  <td class='chart-00'>27</td>
  <td>89</td>
</tr>
<tr>
  <td>23</td>
  <td>48</td>
  <td class='chart-00'>99</td>
  <td>26</td>
  <td>01</td>
  <td>64</td>
</tr>
<tr>
  <td class='chart-00'>55</td>
  <td>69</td>
  <td>10</td>
  <td>92</td>
  <td class='chart-00'>49</td>
  <td class='chart-00'>99</td>
</tr>
<tr>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
  <td class='chart-00'>**</td>
</tr>
<tr>
  <td>78</td>
  <td>57</td>
  <td>41</td>
  <td>26</td>
  <td>95</td>
  <td class='chart-00'>11</td>
</tr>
<tr>
  <td>46</td>
  <td class='chart-00'>22</td>
  <td>19</td>
  <td>18</td>
  <td>09</td>
  <td>65</td>
</tr>
<tr>
  <td>08</td>
  <td>74</td>
  <td>96</td>
  <td>10</td>
  <td>10</td>
  <td>75</td>
</tr>
<tr>
  <td>39</td>
  <td>97</td>
  <td>35</td>
  <td>56</td>
  <td>75</td>
  <td>29</td>
</tr>
<tr>
  <td>18</td>
  <td class='chart-00'>16</td>
  <td>74</td>
  <td>51</td>
  <td>52</td>
  <td>70</td>
</tr>
<tr>
  <td>48</td>
  <td>53</td>
  <td class='chart-00'>66</td>
  <td>98</td>
  <td class='chart-00'>05</td>
  <td>63</td>
</tr>
<tr>
  <td>04</td>
  <td>96</td>
  <td>58</td>
  <td>69</td>
  <td class='chart-00'>99</td>
  <td>20</td>
</tr>
<tr>
  <td>10</td>
  <td>93</td>
  <td>47</td>
  <td>62</td>
  <td>09</td>
  <td>84</td>
</tr>
<tr>
  <td>64</td>
  <td>95</td>
  <td class='chart-00'>27</td>
  <td>19</td>
  <td>54</td>
  <td class='chart-00'>05</td>
</tr>
<tr>
  <td>43</td>
  <td class='chart-00'>77</td>
  <td>30</td>
  <td>67</td>
  <td>53</td>
  <td>69</td>
</tr>
<tr>
  <td>19</td>
  <td class='chart-00'>**</td>
  <td>24</td>
  <td class='chart-00'>88</td>
  <td>54</td>
  <td>31</td>
</tr>
<tr>
  <td>14</td>
  <td>28</td>
  <td>19</td>
  <td>89</td>
  <td>30</td>
  <td>52</td>
</tr>
<tr>
  <td>36</td>
  <td>40</td>
  <td>46</td>
  <td class='chart-00'>05</td>
  <td>15</td>
  <td class='chart-00'>77</td>
</tr>
<tr>
  <td>59</td>
  <td>78</td>
  <td>48</td>
  <td>76</td>
  <td>04</td>
  <td>17</td>
</tr>
<tr>
  <td>53</td>
  <td>34</td>
  <td>85</td>
  <td>34</td>
  <td>41</td>
  <td>53</td>
</tr>
<tr>
  <td>97</td>
  <td>97</td>
  <td class='chart-00'>66</td>
  <td>59</td>
  <td>63</td>
  <td>30</td>
</tr>
<tr>
  <td>19</td>
  <td>95</td>
  <td>64</td>
  <td>28</td>
  <td>07</td>
  <td>67</td>
</tr>
<tr>
  <td>08</td>
  <td>46</td>
  <td>08</td>
  <td>69</td>
  <td>68</td>
  <td>59</td>
</tr>
<tr>
  <td class='chart-00'>77</td>
  <td>45</td>
  <td>98</td>
  <td>37</td>
  <td>28</td>
  <td class='chart-00'>72</td>
</tr>
<tr>
  <td class='chart-00'>**</td>
  <td>82</td>
  <td>31</td>
  <td>69</td>
  <td>02</td>
  <td>41</td>
</tr>
<tr>
  <td>60</td>
  <td class='chart-00'>27</td>
  <td>95</td>
  <td>92</td>
  <td>54</td>
  <td>23</td>
</tr>
</tbody>
<tr><td class=''>42</td><td class=''>97</td><td class='r'>66</td><td class='r'>72</td><td class=''>86</td><td class=''>70</td><td class=''>45</td></tr><tr><td class=''>14</td><td class=''>95</td><td class=''>35</td><td class=''>87</td><td class=''>04</td><td class=''>96</td><td class=''>68</td></tr><tr><td class=''>64</td><td class=''>98</td><td class=''>64</td><td class=''>30</td><td class=''>81</td><td class='r'>50</td><td class=''>76</td></tr><tr><td class='r'>22</td><td class=''>45</td><td class=''>96</td><td class=''>80</td><td class=''>46</td><td class=''>58</td><td class=''>47</td></tr><tr><td class=''>90</td><td class=''>28</td><td class=''>85</td><td class=''>92</td><td class=''>21</td><td class='r'>94</td><td class=''>21</td></tr><tr><td class=''>60</td><td class=''>47</td><td class=''>59</td><td class='r'>44</td><td class=''>43</td><td class=''>23</td><td class=''>52</td></tr><tr><td class=''>02</td><td class=''>03</td><td class=''>39</td><td class=''>92</td><td class=''>36</td><td class=''>26</td><td class=''>43</td></tr><tr><td class='r'>94</td><td class=''>53</td><td class='r'>38</td><td class=''>20</td><td class=''>54</td><td class=''>79</td><td class=''>15</td></tr><tr><td class=''>98</td><td class=''>18</td><td class=''>76</td><td class=''>92</td><td class='r'>66</td><td class=''>80</td><td class='r'>55</td></tr><tr><td class=''>13</td><td class=''>91</td><td class=''>54</td><td class='r'>22</td><td class=''>35</td><td class=''>91</td><td class=''>54</td></tr><tr><td class=''>19</td><td class=''>23</td><td class=''>80</td><td class=''>91</td><td class=''>54</td><td class='r'>66</td><td class=''>53</td></tr><tr><td class=''>32</td><td class=''>74</td><td class=''>90</td><td class=''>64</td><td class='r'>22</td><td class=''>73</td><td class='r'>16</td></tr><tr><td class=''>23</td><td class=''>29</td><td class='r'>99</td><td class=''>76</td><td class=''>53</td><td class=''>79</td><td class=''>60</td></tr><tr><td class=''>59</td><td class=''>74</td><td class=''>30</td><td class=''>07</td><td class='r'>99</td><td class=''>92</td><td class=''>45</td></tr><tr><td class=''>63</td><td class=''>12</td><td class='r'>66</td><td class=''>75</td><td class=''>92</td><td class=''>58</td><td class=''>85</td></tr><tr><td class=''>25</td><td class=''>91</td><td class=''>54</td><td class=''>75</td><td class=''>30</td><td class=''>54</td><td class=''>92</td></tr><tr><td class='r'>66</td><td class=''>95</td><td class='r'>50</td><td class=''>42</td><td class=''>53</td><td class=''>93</td><td class=''>07</td></tr><tr><td class=''>90</td><td class=''>74</td><td class='r'>94</td><td class=''>79</td><td class=''>21</td><td class=''>35</td><td class='r'>**</td></tr><tr><td class=''>60</td><td class=''>07</td><td class=''>54</td><td class=''>43</td><td class='r'>38</td><td class=''>79</td><td class=''>80</td></tr><tr><td class=''>07</td><td class=''>97</td><td class=''>41</td><td class='r'>00</td><td class=''>69</td><td class=''>28</td><td class=''>63</td></tr><tr><td class='r'>49</td><td class=''>39</td><td class=''>89</td><td class=''>20</td><td class=''>14</td><td class=''>67</td><td class=''>26</td></tr><tr><td class=''>90</td><td class=''>76</td><td class=''>04</td><td class=''>13</td><td class=''>75</td><td class=''>24</td><td class=''>15</td></tr><tr><td class=''>59</td><td class='r'>55</td><td class=''>19</td><td class=''>03</td><td class='r'>11</td><td class=''>63</td><td class=''>48</td></tr><tr><td class='r'>50</td><td class=''>79</td><td class=''>24</td><td class=''>14</td><td class=''>84</td><td class=''>35</td><td class=''>97</td></tr><tr><td class=''>37</td><td class=''>09</td><td class='r'>22</td><td class=''>52</td><td class=''>03</td><td class=''>29</td><td class=''>37</td></tr><tr><td class=''>73</td><td class=''>58</td><td class='r'>44</td><td class=''>08</td><td class='r'>72</td><td class=''>67</td><td class=''>65</td></tr><tr><td class='r'>55</td><td class=''>71</td><td class=''>01</td><td class=''>02</td><td class=''>34</td><td class=''>74</td><td class=''>93</td></tr><tr><td class=''>63</td><td class=''>17</td><td class=''>30</td><td class='r'>27</td><td class=''>67</td><td class='r'>33</td><td class='r'>88</td></tr><tr><td class=''>75</td><td class=''>74</td><td class=''>46</td><td class='r'>94</td><td class=''>29</td><td class=''>60</td><td class=''>80</td></tr><tr><td class=''>80</td><td class=''>75</td><td class=''>97</td><td class='r'>**</td><td class='r'>**</td><td class='r'>**</td><td class='r'>**</td></tr><tr><td class='r'>38</td><td class=''>62</td><td class=''>97</td><td class=''>67</td><td class=''>59</td><td class=''>46</td><td class=''>80</td></tr><tr><td class=''>28</td><td class='r'>99</td><td class='r'>11</td><td class=''>07</td><td class=''>90</td><td class=''>58</td><td class=''>68</td></tr><tr><td class=''>62</td><td class=''>76</td><td class=''>24</td><td class=''>85</td><td class='r'>88</td><td class=''>74</td><td class=''>69</td></tr><tr><td class='r'>99</td><td class=''>36</td><td class=''>21</td><td class=''>75</td><td class=''>08</td><td class='r'>77</td><td class=''>91</td></tr><tr><td class=''>31</td><td class='r'>05</td><td class=''>63</td><td class=''>91</td><td class=''>74</td><td class=''>89</td><td class=''>54</td></tr><tr><td class=''>40</td><td class=''>65</td><td class=''>14</td><td class=''>91</td><td class='r'>44</td><td class=''>85</td><td class=''>76</td></tr><tr><td class=''>60</td><td class=''>82</td><td class=''>79</td><td class=''>37</td><td class=''>63</td><td class=''>67</td><td class=''>91</td></tr><tr><td class=''>37</td><td class=''>14</td><td class=''>07</td><td class=''>07</td><td class='r'>33</td><td class=''>01</td><td class=''>39</td></tr><tr><td class=''>06</td><td class='r'>44</td><td class=''>32</td><td class='r'>05</td><td class=''>37</td><td class=''>86</td><td class=''>75</td></tr><tr><td class=''>80</td><td class=''>78</td><td class='r'>44</td><td class=''>97</td><td class=''>28</td><td class=''>21</td><td class='r'>77</td></tr><tr><td class=''>62</td><td class=''>65</td><td class=''>02</td><td class='r'>44</td><td class=''>09</td><td class=''>79</td><td class=''>37</td></tr><tr><td class=''>78</td><td class='r'>94</td><td class='r'>**</td><td class='r'>05</td><td class=''>29</td><td class=''>59</td><td class=''>62</td></tr><tr><td class=''>56</td><td class='r'>00</td><td class=''>45</td><td class=''>71</td><td class=''>64</td><td class=''>21</td><td class=''>64</td></tr><tr><td class='r'>99</td><td class=''>98</td><td class=''>65</td><td class=''>73</td><td class=''>80</td><td class=''>70</td><td class=''>78</td></tr><tr><td class=''>36</td><td class='r'>99</td><td class=''>39</td><td class=''>87</td><td class=''>79</td><td class=''>89</td><td class=''>02</td></tr><tr><td class=''>70</td><td class=''>60</td><td class=''>78</td><td class=''>87</td><td class='r'>99</td><td class=''>43</td><td class='r'>11</td></tr><tr><td class='r'>49</td><td class=''>09</td><td class=''>51</td><td class=''>28</td><td class=''>75</td><td class='r'>61</td><td class=''>20</td></tr><tr><td class='r'>99</td><td class=''>21</td><td class=''>96</td><td class=''>23</td><td class=''>20</td><td class=''>03</td><td class=''>92</td></tr><tr><td class=''>56</td><td class=''>96</td><td class=''>46</td><td class=''>10</td><td class='r'>**</td><td class='r'>33</td><td class=''>96</td></tr><tr><td class=''>40</td><td class=''>65</td><td class='r'>16</td><td class=''>60</td><td class='r'>44</td><td class=''>81</td><td class=''>67</td></tr><tr><td class=''>65</td><td class=''>81</td><td class=''>95</td><td class=''>30</td><td class=''>46</td><td class=''>84</td><td class=''>92</td></tr><tr><td class=''>32</td><td class='r'>61</td><td class=''>87</td><td class=''>87</td><td class=''>09</td><td class=''>09</td><td class=''>17</td></tr><tr><td class=''>12</td><td class=''>06</td><td class=''>75</td><td class=''>17</td><td class=''>93</td><td class='r'>88</td><td class=''>97</td></tr><tr><td class='r'>99</td><td class=''>34</td><td class=''>62</td><td class=''>56</td><td class=''>80</td><td class=''>41</td><td class='r'>38</td></tr><tr><td class=''>82</td><td class=''>86</td><td class=''>39</td><td class=''>86</td><td class=''>67</td><td class=''>73</td><td class=''>20</td></tr><tr><td class=''>32</td><td class='r'>11</td><td class=''>96</td><td class=''>53</td><td class=''>46</td><td class=''>35</td><td class='r'>44</td></tr><tr><td class=''>65</td><td class=''>18</td><td class='r'>05</td><td class=''>93</td><td class=''>42</td><td class=''>10</td><td class=''>39</td></tr><tr><td class='r'>16</td><td class=''>53</td><td class=''>10</td><td class=''>24</td><td class=''>26</td><td class=''>53</td><td class=''>62</td></tr><tr><td class=''>75</td><td class=''>81</td><td class=''>20</td><td class=''>37</td><td class=''>67</td><td class='r'>55</td><td class='r'>22</td></tr><tr><td class=''>40</td><td class=''>86</td><td class=''>51</td><td class=''>68</td><td class=''>06</td><td class='r'>11</td><td class=''>53</td></tr><tr><td class=''>70</td><td class=''>51</td><td class=''>63</td><td class=''>70</td><td class='r'>27</td><td class=''>18</td><td class=''>85</td></tr><tr><td class=''>57</td><td class=''>92</td><td class=''>70</td><td class=''>90</td><td class='r'>33</td><td class=''>21</td><td class=''>76</td></tr><tr><td class=''>74</td><td class='r'>38</td><td class=''>23</td><td class=''>13</td><td class='r'>05</td><td class=''>75</td><td class=''>13</td></tr><tr><td class=''>46</td><td class=''>74</td><td class=''>58</td><td class='r'>72</td><td class=''>84</td><td class='r'>49</td><td class=''>01</td></tr><tr><td class=''>43</td><td class='r'>94</td><td class=''>78</td><td class=''>08</td><td class=''>42</td><td class=''>04</td><td class=''>96</td></tr><tr><td class='r'>11</td><td class=''>41</td><td class=''>90</td><td class=''>87</td><td class=''>18</td><td class=''>93</td><td class=''>18</td></tr><tr><td class=''>14</td><td class=''>34</td><td class=''>20</td><td class='r'>44</td><td class='r'>88</td><td class=''>26</td><td class=''>06</td></tr><tr><td class=''>21</td><td class=''>80</td><td class=''>53</td><td class=''>97</td><td class=''>59</td><td class=''>78</td><td class=''>96</td></tr><tr><td class=''>93</td><td class=''>39</td><td class=''>80</td><td class=''>51</td><td class='r'>05</td><td class=''>28</td><td class=''>53</td></tr><tr><td class=''>71</td><td class=''>63</td><td class=''>89</td><td class=''>81</td><td class=''>01</td><td class=''>21</td><td class=''>81</td></tr><tr><td class='r'>**</td><td class=''>21</td><td class='r'>00</td><td class='r'>22</td><td class=''>79</td><td class=''>67</td><td class=''>30</td></tr><tr><td class=''>74</td><td class=''>31</td><td class=''>32</td><td class=''>97</td><td class='r'>99</td><td class=''>26</td><td class=''>20</td></tr><tr><td class='r'>38</td><td class=''>54</td><td class=''>08</td><td class='r'>72</td><td class=''>14</td><td class=''>78</td><td class=''>48</td></tr><tr><td class=''>31</td><td class=''>37</td><td class=''>80</td><td class=''>18</td><td class=''>63</td><td class=''>52</td><td class=''>93</td></tr><tr><td class=''>93</td><td class='r'>77</td><td class=''>79</td><td class=''>96</td><td class='r'>05</td><td class=''>79</td><td class=''>57</td></tr><tr><td class=''>93</td><td class=''>37</td><td class=''>29</td><td class='r'>38</td><td class='r'>44</td><td class=''>59</td><td class=''>91</td></tr><tr><td class=''>43</td><td class=''>79</td><td class='r'>27</td><td class='r'>72</td><td class=''>62</td><td class=''>04</td><td class=''>89</td></tr><tr><td class=''>01</td><td class=''>12</td><td class=''>34</td><td class=''>19</td><td class=''>80</td><td class='r'>88</td><td class=''>21</td></tr><tr><td class=''>23</td><td class=''>25</td><td class='r'>83</td><td class=''>93</td><td class=''>35</td><td class=''>95</td><td class=''>03</td></tr><tr><td class=''>75</td><td class=''>08</td><td class=''>87</td><td class=''>57</td><td class='r'>50</td><td class='r'>77</td><td class=''>06</td></tr><tr><td class='r'>**</td><td class='r'>**</td><td class='r'>**</td><td class=''>26</td><td class=''>32</td><td class=''>24</td><td class='r'>44</td></tr><tr><td class='r'>38</td><td class=''>54</td><td class=''>74</td><td class=''>95</td><td class='r'>05</td><td class=''>43</td><td class=''>13</td></tr><tr><td class=''>29</td><td class='r'>99</td><td class=''>32</td><td class=''>01</td><td class=''>20</td><td class=''>71</td><td class=''>17</td></tr><tr><td class=''>80</td><td class=''>71</td><td class=''>75</td><td class=''>80</td><td class=''>34</td><td class=''>59</td><td class='r'>55</td></tr><tr><td class=''>10</td><td class=''>32</td><td class=''>03</td><td class=''>13</td><td class=''>87</td><td class='r'>66</td><td class=''>87</td></tr><tr><td class=''>89</td><td class=''>47</td><td class='r'>05</td><td class=''>41</td><td class='r'>50</td><td class='r'>88</td><td class=''>04</td></tr><tr><td class=''>40</td><td class=''>19</td><td class=''>82</td><td class=''>97</td><td class=''>95</td><td class=''>52</td><td class=''>47</td></tr><tr><td class=''>89</td><td class='r'>11</td><td class=''>79</td><td class=''>48</td><td class=''>82</td><td class=''>15</td><td class=''>18</td></tr><tr><td class=''>13</td><td class=''>60</td><td class=''>85</td><td class=''>09</td><td class=''>81</td><td class='r'>61</td><td class=''>75</td></tr><tr><td class=''>43</td><td class=''>51</td><td class=''>34</td><td class='r'>49</td><td class=''>21</td><td class=''>73</td><td class='r'>88</td></tr><tr><td class=''>06</td><td class=''>58</td><td class=''>36</td><td class=''>98</td><td class='r'>16</td><td class=''>21</td><td class=''>46</td></tr><tr><td class=''>21</td><td class=''>23</td><td class=''>97</td><td class=''>71</td><td class=''>32</td><td class=''>02</td><td class=''>39</td></tr><tr><td class='r'>61</td><td class=''>73</td><td class='r'>99</td><td class=''>48</td><td class=''>13</td><td class=''>37</td><td class=''>59</td></tr><tr><td class=''>74</td><td class=''>70</td><td class=''>31</td><td class='r'>**</td><td class=''>26</td><td class=''>17</td><td class='r'>55</td></tr><tr><td class='r'>11</td><td class=''>19</td><td class='r'>94</td><td class=''>03</td><td class=''>34</td><td class=''>65</td><td class='r'>00</td></tr><tr><td class=''>89</td><td class=''>81</td><td class='r'>44</td><td class=''>02</td><td class=''>81</td><td class=''>42</td><td class=''>81</td></tr><tr><td class=''>21</td><td class=''>08</td><td class=''>96</td><td class=''>60</td><td class='r'>49</td><td class=''>24</td><td class=''>82</td></tr><tr><td class=''>96</td><td class=''>14</td><td class=''>78</td><td class=''>89</td><td class=''>13</td><td class=''>15</td><td class=''>75</td></tr><tr><td class=''>48</td><td class=''>54</td><td class=''>28</td><td class='r'>55</td><td class=''>79</td><td class=''>19</td><td class=''>89</td></tr><tr><td class='r'>77</td><td class=''>18</td><td class='r'>**</td><td class=''>01</td><td class=''>18</td><td class=''>42</td><td class=''>40</td></tr><tr><td class=''>01</td><td class='r'>55</td><td class=''>28</td><td class=''>28</td><td class=''>06</td><td class=''>46</td><td class=''>62</td></tr><tr><td class='r'>61</td><td class=''>76</td><td class=''>90</td><td class='r'>83</td><td class=''>90</td><td class=''>36</td><td class=''>71</td></tr><tr><td class=''>40</td><td class='r'>05</td><td class=''>25</td><td class=''>28</td><td class=''>43</td><td class=''>26</td><td class=''>32</td></tr><tr><td class=''>26</td><td class=''>73</td><td class='r'>49</td><td class=''>46</td><td class=''>31</td><td class=''>03</td><td class=''>60</td></tr><tr><td class=''>87</td><td class=''>75</td><td class='r'>49</td><td class='r'>44</td><td class=''>84</td><td class=''>19</td><td class=''>21</td></tr><tr><td class=''>12</td><td class=''>03</td><td class=''>65</td><td class=''>41</td><td class='r'>49</td><td class=''>39</td><td class='r'>50</td></tr><tr><td class=''>17</td><td class=''>70</td><td class=''>39</td><td class=''>37</td><td class=''>15</td><td class=''>13</td><td class='r'>77</td></tr><tr><td class=''>25</td><td class=''>51</td><td class=''>35</td><td class=''>42</td><td class=''>09</td><td class=''>08</td><td class=''>79</td></tr><tr><td class=''>48</td><td class=''>71</td><td class=''>17</td><td class=''>90</td><td class=''>14</td><td class=''>78</td><td class=''>10</td></tr><tr><td class=''>48</td><td class=''>97</td><td class=''>82</td><td class=''>75</td><td class=''>56</td><td class=''>47</td><td class=''>90</td></tr><tr><td class=''>56</td><td class=''>04</td><td class='r'>22</td><td class=''>30</td><td class=''>08</td><td class=''>42</td><td class='r'>33</td></tr><tr><td class=''>91</td><td class=''>34</td><td class='r'>66</td><td class=''>69</td><td class=''>58</td><td class='r'>38</td><td class=''>21</td></tr><tr><td class='r'>88</td><td class=''>10</td><td class=''>76</td><td class=''>56</td><td class=''>10</td><td class=''>53</td><td class=''>04</td></tr><tr><td class=''>75</td><td class=''>59</td><td class=''>19</td><td class=''>91</td><td class=''>35</td><td class='r'>33</td><td class='r'>55</td></tr><tr><td class=''>98</td><td class=''>82</td><td class=''>58</td><td class=''>26</td><td class=''>42</td><td class=''>92</td><td class=''>98</td></tr><tr><td class=''>46</td><td class=''>51</td><td class='r'>55</td><td class=''>39</td><td class=''>95</td><td class=''>32</td><td class=''>79</td></tr><tr><td class=''>12</td><td class='r'>88</td><td class='r'>61</td><td class=''>60</td><td class=''>92</td><td class=''>41</td><td class=''>32</td></tr><tr><td class=''>64</td><td class=''>41</td><td class=''>09</td><td class=''>52</td><td class=''>96</td><td class=''>34</td><td class=''>15</td></tr><tr><td class=''>26</td><td class='r'>50</td><td class=''>59</td><td class='r'>66</td><td class=''>73</td><td class=''>69</td><td class=''>84</td></tr><tr><td class='r'>88</td><td class=''>12</td><td class=''>39</td><td class=''>89</td><td class=''>37</td><td class=''>86</td><td class=''>10</td></tr><tr><td class='r'>16</td><td class=''>29</td><td class=''>32</td><td class=''>29</td><td class=''>25</td><td class=''>69</td><td class=''>10</td></tr><tr><td class='r'>44</td><td class=''>53</td><td class=''>84</td><td class=''>98</td><td class=''>97</td><td class=''>65</td><td class='r'>99</td></tr><tr><td class=''>84</td><td class='r'>**</td><td class=''>51</td><td class=''>82</td><td class=''>70</td><td class=''>82</td><td class=''>31</td></tr><tr><td class='r'>27</td><td class=''>67</td><td class=''>19</td><td class='r'>11</td><td class=''>57</td><td class=''>64</td><td class=''>64</td></tr><tr><td class=''>64</td><td class=''>31</td><td class=''>47</td><td class=''>36</td><td class='r'>22</td><td class=''>32</td><td class=''>29</td></tr><tr><td class=''>98</td><td class='r'>72</td><td class=''>02</td><td class=''>93</td><td class='r'>00</td><td class=''>96</td><td class='r'>27</td></tr><tr><td class=''>86</td><td class=''>10</td><td class=''>98</td><td class=''>93</td><td class='r'>88</td><td class=''>25</td><td class='r'>83</td></tr><tr><td class=''>17</td><td class=''>15</td><td class=''>86</td><td class=''>17</td><td class='r'>00</td><td class=''>28</td><td class=''>73</td></tr><tr><td class=''>25</td><td class=''>51</td><td class=''>51</td><td class=''>68</td><td class=''>23</td><td class=''>25</td><td class=''>76</td></tr><tr><td class='r'>00</td><td class=''>10</td><td class=''>71</td><td class=''>03</td><td class=''>20</td><td class=''>62</td><td class=''>30</td></tr><tr><td class=''>04</td><td class='r'>38</td><td class=''>29</td><td class=''>69</td><td class='r'>61</td><td class=''>12</td><td class=''>48</td></tr><tr><td class=''>52</td><td class=''>48</td><td class=''>15</td><td class=''>32</td><td class='r'>22</td><td class=''>47</td><td class='r'>66</td></tr><tr><td class=''>41</td><td class=''>14</td><td class=''>62</td><td class=''>31</td><td class=''>75</td><td class='r'>33</td><td class=''>02</td></tr><tr><td class='r'>00</td><td class=''>31</td><td class=''>60</td><td class='r'>66</td><td class=''>37</td><td class=''>41</td><td class=''>93</td></tr><tr><td class=''>46</td><td class=''>40</td><td class=''>10</td><td class=''>10</td><td class=''>41</td><td class=''>09</td><td class='r'>**</td></tr><tr><td class='r'>**</td><td class='r'>**</td><td class='r'>**</td><td class=''>29</td><td class=''>03</td><td class=''>34</td><td class='r'>11</td></tr><tr><td class=''>48</td><td class=''>43</td><td class='r'>88</td><td class=''>17</td><td class=''>09</td><td class=''>70</td><td class=''>54</td></tr><tr><td class='r'>00</td><td class=''>31</td><td class=''>42</td><td class=''>07</td><td class=''>57</td><td class=''>68</td><td class=''>64</td></tr><tr><td class=''>47</td><td class=''>96</td><td class='r'>49</td><td class=''>57</td><td class='r'>27</td><td class=''>81</td><td class=''>18</td></tr><tr><td class=''>18</td><td class=''>63</td><td class=''>76</td><td class='r'>49</td><td class=''>42</td><td class=''>31</td><td class='r'>22</td></tr><tr><td class=''>01</td><td class='r'>44</td><td class=''>46</td><td class=''>63</td><td class=''>03</td><td class=''>46</td><td class=''>87</td></tr><tr><td class=''>04</td><td class=''>20</td><td class='r'>77</td><td class=''>95</td><td class=''>28</td><td class=''>64</td><td class='r'>99</td></tr><tr><td class=''>24</td><td class=''>78</td><td class=''>17</td><td class=''>09</td><td class='r'>94</td><td class=''>51</td><td class=''>91</td></tr><tr><td class='r'>99</td><td class=''>26</td><td class=''>75</td><td class='r'>44</td><td class=''>03</td><td class=''>75</td><td class=''>28</td></tr><tr><td class=''>28</td><td class=''>96</td><td class=''>84</td><td class=''>90</td><td class='r'>55</td><td class=''>58</td><td class=''>90</td></tr><tr><td class=''>28</td><td class=''>42</td><td class=''>32</td><td class=''>03</td><td class='r'>**</td><td class=''>90</td><td class=''>84</td></tr><tr><td class=''>31</td><td class=''>87</td><td class=''>03</td><td class=''>48</td><td class=''>60</td><td class=''>19</td><td class=''>64</td></tr><tr><td class='r'>49</td><td class=''>17</td><td class='r'>49</td><td class=''>76</td><td class=''>40</td><td class=''>15</td><td class=''>73</td></tr><tr><td class=''>69</td><td class=''>51</td><td class=''>71</td><td class=''>86</td><td class=''>20</td><td class=''>03</td><td class=''>75</td></tr><tr><td class=''>10</td><td class=''>98</td><td class=''>46</td><td class=''>36</td><td class=''>73</td><td class=''>76</td><td class=''>46</td></tr><tr><td class=''>04</td><td class=''>68</td><td class='r'>77</td><td class=''>51</td><td class='r'>83</td><td class=''>53</td><td class='r'>05</td></tr><tr><td class=''>23</td><td class=''>79</td><td class=''>43</td><td class=''>78</td><td class='r'>22</td><td class=''>74</td><td class=''>19</td></tr><tr><td class=''>71</td><td class=''>62</td><td class=''>32</td><td class='r'>49</td><td class=''>03</td><td class=''>39</td><td class=''>84</td></tr><tr><td class=''>87</td><td class=''>20</td><td class=''>67</td><td class=''>15</td><td class=''>92</td><td class=''>97</td><td class=''>95</td></tr><tr><td class='r'>**</td><td class=''>37</td><td class=''>29</td><td class=''>30</td><td class='r'>11</td><td class=''>04</td><td class=''>32</td></tr><tr><td class=''>31</td><td class=''>78</td><td class='r'>05</td><td class=''>43</td><td class=''>68</td><td class=''>60</td><td class=''>47</td></tr><tr><td class=''>18</td><td class=''>18</td><td class=''>62</td><td class=''>35</td><td class=''>75</td><td class='r'>38</td><td class=''>40</td></tr><tr><td class='r'>00</td><td class=''>12</td><td class=''>74</td><td class=''>67</td><td class='r'>72</td><td class=''>65</td><td class=''>25</td></tr><tr><td class=''>97</td><td class=''>53</td><td class=''>29</td><td class=''>29</td><td class=''>41</td><td class=''>07</td><td class=''>10</td></tr><tr><td class=''>74</td><td class='r'>44</td><td class=''>12</td><td class=''>96</td><td class=''>32</td><td class='r'>05</td><td class=''>68</td></tr><tr><td class=''>09</td><td class='r'>05</td><td class=''>80</td><td class=''>37</td><td class=''>12</td><td class=''>39</td><td class=''>85</td></tr><tr><td class=''>25</td><td class=''>81</td><td class=''>21</td><td class=''>91</td><td class=''>36</td><td class='r'>66</td><td class=''>96</td></tr><tr><td class=''>24</td><td class=''>78</td><td class=''>70</td><td class='r'>61</td><td class='r'>05</td><td class=''>51</td><td class=''>98</td></tr><tr><td class=''>95</td><td class=''>84</td><td class=''>30</td><td class='r'>61</td><td class='r'>44</td><td class=''>58</td><td class=''>78</td></tr><tr><td class=''>79</td><td class='r'>16</td><td class=''>41</td><td class='r'>61</td><td class='r'>55</td><td class=''>41</td><td class=''>96</td></tr><tr><td class=''>73</td><td class=''>43</td><td class=''>63</td><td class=''>47</td><td class=''>89</td><td class=''>91</td><td class='r'>83</td></tr><tr><td class=''>23</td><td class=''>95</td><td class=''>03</td><td class=''>43</td><td class='r'>05</td><td class=''>09</td><td class='r'>11</td></tr><tr><td class=''>03</td><td class=''>20</td><td class=''>01</td><td class=''>21</td><td class=''>57</td><td class=''>20</td><td class='r'>49</td></tr><tr><td class=''>91</td><td class=''>09</td><td class='r'>72</td><td class=''>12</td><td class=''>47</td><td class=''>19</td><td class=''>21</td></tr><tr><td class=''>06</td><td class=''>89</td><td class='r'>61</td><td class=''>69</td><td class=''>74</td><td class=''>71</td><td class=''>68</td></tr><tr><td class=''>08</td><td class=''>89</td><td class='r'>77</td><td class=''>09</td><td class=''>39</td><td class=''>95</td><td class=''>67</td></tr><tr><td class=''>52</td><td class='r'>88</td><td class=''>68</td><td class=''>15</td><td class=''>19</td><td class=''>58</td><td class=''>97</td></tr><tr><td class=''>29</td><td class=''>75</td><td class=''>76</td><td class=''>39</td><td class='r'>05</td><td class=''>20</td><td class=''>60</td></tr><tr><td class=''>97</td><td class=''>67</td><td class='r'>22</td><td class=''>09</td><td class='r'>44</td><td class=''>82</td><td class=''>81</td></tr><tr><td class=''>37</td><td class=''>91</td><td class='r'>72</td><td class='r'>**</td><td class=''>32</td><td class=''>19</td><td class=''>91</td></tr><tr><td class=''>43</td><td class=''>35</td><td class='r'>11</td><td class=''>53</td><td class=''>52</td><td class=''>58</td><td class='r'>38</td></tr><tr><td class='r'>49</td><td class=''>86</td><td class=''>17</td><td class=''>52</td><td class=''>84</td><td class=''>59</td><td class=''>23</td></tr><tr><td class=''>58</td><td class='r'>44</td><td class='r'>05</td><td class=''>89</td><td class=''>52</td><td class=''>03</td><td class=''>56</td></tr><tr><td class=''>10</td><td class=''>71</td><td class=''>31</td><td class=''>81</td><td class='r'>88</td><td class=''>04</td><td class=''>45</td></tr><tr><td class='r'>83</td><td class=''>67</td><td class=''>39</td><td class=''>20</td><td class=''>07</td><td class='r'>33</td><td class=''>10</td></tr><tr><td class=''>28</td><td class=''>95</td><td class=''>81</td><td class=''>47</td><td class=''>43</td><td class=''>08</td><td class='r'>77</td></tr><tr><td class='r'>50</td><td class=''>15</td><td class='r'>66</td><td class=''>13</td><td class=''>19</td><td class=''>29</td><td class=''>23</td></tr><tr><td class=''>14</td><td class=''>69</td><td class='r'>49</td><td class='r'>77</td><td class=''>34</td><td class=''>70</td><td class='r'>27</td></tr><tr><td class=''>68</td><td class='r'>05</td><td class=''>30</td><td class=''>19</td><td class='r'>11</td><td class=''>89</td><td class=''>93</td></tr><tr><td class=''>20</td><td class=''>69</td><td class=''>84</td><td class=''>98</td><td class=''>58</td><td class=''>64</td><td class=''>18</td></tr><tr><td class=''>21</td><td class=''>18</td><td class=''>08</td><td class=''>51</td><td class='r'>**</td><td class='r'>**</td><td class='r'>**</td></tr><tr><td class=''>70</td><td class='r'>00</td><td class=''>48</td><td class=''>08</td><td class=''>87</td><td class='r'>66</td><td class=''>42</td></tr><tr><td class=''>65</td><td class=''>69</td><td class=''>95</td><td class=''>65</td><td class=''>95</td><td class=''>97</td><td class=''>30</td></tr><tr><td class=''>93</td><td class='r'>83</td><td class=''>56</td><td class='r'>50</td><td class=''>23</td><td class=''>41</td><td class='r'>33</td></tr><tr><td class=''>13</td><td class=''>36</td><td class=''>03</td><td class='r'>00</td><td class=''>91</td><td class=''>41</td><td class=''>07</td></tr><tr><td class=''>73</td><td class=''>07</td><td class='r'>83</td><td class=''>48</td><td class=''>70</td><td class=''>48</td><td class=''>79</td></tr><tr><td class=''>32</td><td class='r'>00</td><td class=''>78</td><td class=''>68</td><td class=''>60</td><td class='r'>88</td><td class=''>20</td></tr><tr><td class=''>67</td><td class='r'>00</td><td class=''>90</td><td class='r'>77</td><td class=''>64</td><td class=''>15</td><td class=''>12</td></tr><tr><td class=''>70</td><td class=''>91</td><td class=''>42</td><td class='r'>77</td><td class=''>89</td><td class='r'>83</td><td class=''>42</td></tr><tr><td class=''>12</td><td class='r'>16</td><td class=''>06</td><td class=''>28</td><td class=''>70</td><td class=''>85</td><td class='r'>44</td></tr><tr><td class=''>36</td><td class=''>09</td><td class=''>09</td><td class=''>26</td><td class=''>85</td><td class=''>64</td><td class=''>62</td></tr><tr><td class=''>71</td><td class=''>29</td><td class=''>51</td><td class=''>57</td><td class=''>47</td><td class='r'>11</td><td class=''>23</td></tr><tr><td class='r'>77</td><td class=''>81</td><td class='r'>05</td><td class=''>08</td><td class=''>59</td><td class=''>36</td><td class='r'>**</td></tr><tr><td class=''>02</td><td class=''>92</td><td class=''>14</td><td class=''>74</td><td class=''>82</td><td class='r'>55</td><td class=''>84</td></tr><tr><td class=''>97</td><td class='r'>99</td><td class=''>80</td><td class=''>03</td><td class=''>87</td><td class=''>40</td><td class=''>19</td></tr><tr><td class=''>01</td><td class=''>29</td><td class=''>21</td><td class=''>75</td><td class=''>69</td><td class=''>81</td><td class=''>58</td></tr><tr><td class=''>75</td><td class=''>10</td><td class=''>62</td><td class=''>23</td><td class=''>34</td><td class=''>62</td><td class=''>08</td></tr><tr><td class='r'>44</td><td class=''>80</td><td class=''>23</td><td class=''>20</td><td class='r'>55</td><td class=''>39</td><td class=''>13</td></tr><tr><td class=''>95</td><td class=''>31</td><td class='r'>16</td><td class=''>41</td><td class=''>98</td><td class=''>78</td><td class='r'>94</td></tr><tr><td class=''>46</td><td class='r'>77</td><td class=''>10</td><td class=''>41</td><td class='r'>**</td><td class=''>40</td><td class=''>71</td></tr><tr><td class=''>47</td><td class=''>80</td><td class=''>57</td><td class=''>82</td><td class=''>17</td><td class='r'>61</td><td class=''>98</td></tr><tr><td class=''>10</td><td class=''>47</td><td class=''>73</td><td class=''>75</td><td class='r'>38</td><td class=''>90</td><td class=''>32</td></tr><tr><td class=''>70</td><td class=''>56</td><td class=''>60</td><td class=''>47</td><td class=''>43</td><td class=''>04</td><td class=''>30</td></tr><tr><td class=''>13</td><td class=''>69</td><td class=''>30</td><td class=''>37</td><td class=''>25</td><td class='r'>44</td><td class=''>15</td></tr><tr><td class=''>12</td><td class='r'>94</td><td class=''>65</td><td class=''>89</td><td class=''>17</td><td class=''>79</td><td class=''>69</td></tr><tr><td class=''>13</td><td class=''>93</td><td class='r'>11</td><td class=''>78</td><td class=''>43</td><td class=''>35</td><td class=''>51</td></tr><tr><td class=''>58</td><td class='r'>55</td><td class=''>14</td><td class=''>48</td><td class=''>31</td><td class=''>68</td><td class=''>82</td></tr><tr><td class=''>57</td><td class='r'>16</td><td class=''>18</td><td class=''>60</td><td class=''>87</td><td class='r'>16</td><td class=''>59</td></tr><tr><td class=''>53</td><td class=''>10</td><td class=''>10</td><td class=''>62</td><td class=''>37</td><td class=''>07</td><td class='r'>11</td></tr><tr><td class=''>47</td><td class=''>98</td><td class='r'>49</td><td class=''>35</td><td class=''>10</td><td class=''>14</td><td class=''>23</td></tr><tr><td class=''>39</td><td class=''>18</td><td class='r'>55</td><td class=''>58</td><td class=''>31</td><td class=''>17</td><td class=''>87</td></tr><tr><td class=''>98</td><td class=''>14</td><td class=''>13</td><td class=''>42</td><td class=''>37</td><td class=''>58</td><td class=''>98</td></tr><tr><td class=''>26</td><td class=''>71</td><td class=''>41</td><td class=''>58</td><td class='r'>77</td><td class=''>81</td><td class=''>21</td></tr><tr><td class=''>06</td><td class=''>75</td><td class=''>13</td><td class=''>08</td><td class='r'>00</td><td class=''>23</td><td class=''>80</td></tr><tr><td class=''>81</td><td class='r'>61</td><td class=''>74</td><td class=''>67</td><td class=''>87</td><td class=''>42</td><td class=''>09</td></tr><tr><td class=''>65</td><td class=''>09</td><td class=''>39</td><td class='r'>38</td><td class=''>84</td><td class=''>20</td><td class=''>67</td></tr><tr><td class=''>74</td><td class=''>42</td><td class='r'>50</td><td class=''>98</td><td class=''>07</td><td class=''>10</td><td class='r'>38</td></tr><tr><td class=''>60</td><td class=''>64</td><td class=''>45</td><td class=''>28</td><td class=''>59</td><td class=''>20</td><td class=''>63</td></tr><tr><td class=''>84</td><td class=''>54</td><td class='r'>27</td><td class=''>14</td><td class='r'>61</td><td class=''>02</td><td class=''>42</td></tr><tr><td class=''>14</td><td class=''>24</td><td class=''>78</td><td class=''>82</td><td class='r'>94</td><td class=''>32</td><td class=''>92</td></tr><tr><td class=''>78</td><td class='r'>55</td><td class=''>87</td><td class=''>63</td><td class=''>60</td><td class=''>03</td><td class=''>67</td></tr><tr><td class=''>74</td><td class=''>13</td><td class=''>20</td><td class=''>29</td><td class='r'>**</td><td class=''>59</td><td class=''>18</td></tr><tr><td class=''>30</td><td class=''>10</td><td class=''>17</td><td class=''>01</td><td class=''>45</td><td class='r'>77</td><td class=''>73</td></tr><tr><td class=''>18</td><td class=''>17</td><td class=''>47</td><td class=''>93</td><td class=''>56</td><td class=''>13</td><td class=''>08</td></tr><tr><td class=''>52</td><td class=''>47</td><td class=''>10</td><td class='r'>99</td><td class=''>31</td><td class=''>73</td><td class=''>37</td></tr><tr><td class=''>54</td><td class=''>93</td><td class=''>37</td><td class=''>48</td><td class=''>57</td><td class='r'>49</td><td class=''>54</td></tr><tr><td class=''>91</td><td class=''>76</td><td class='r'>55</td><td class=''>34</td><td class=''>96</td><td class=''>32</td><td class=''>51</td></tr><tr><td class=''>21</td><td class='r'>77</td><td class=''>03</td><td class=''>86</td><td class=''>96</td><td class=''>45</td><td class=''>70</td></tr><tr><td class=''>45</td><td class=''>80</td><td class=''>71</td><td class=''>17</td><td class=''>40</td><td class='r'>33</td><td class=''>81</td></tr><tr><td class=''>80</td><td class=''>69</td><td class='r'>99</td><td class='r'>66</td><td class=''>76</td><td class=''>28</td><td class=''>06</td></tr><tr><td class='r'>00</td><td class=''>74</td><td class=''>60</td><td class=''>91</td><td class=''>40</td><td class=''>29</td><td class='r'>99</td></tr><tr><td class=''>26</td><td class=''>68</td><td class='r'>99</td><td class=''>84</td><td class=''>48</td><td class=''>65</td><td class='r'>22</td></tr><tr><td class=''>09</td><td class='r'>77</td><td class=''>29</td><td class=''>40</td><td class=''>68</td><td class=''>68</td><td class='r'>38</td></tr><tr><td class=''>90</td><td class=''>02</td><td class=''>53</td><td class=''>14</td><td class=''>34</td><td class=''>09</td><td class=''>19</td></tr><tr><td class=''>48</td><td class=''>48</td><td class=''>29</td><td class=''>34</td><td class=''>93</td><td class=''>26</td><td class=''>29</td></tr><tr><td class=''>06</td><td class=''>23</td><td class=''>18</td><td class=''>23</td><td class=''>87</td><td class=''>02</td><td class=''>37</td></tr><tr><td class=''>25</td><td class=''>95</td><td class='r'>44</td><td class='r'>11</td><td class=''>15</td><td class=''>79</td><td class=''>04</td></tr><tr><td class=''>98</td><td class=''>15</td><td class=''>07</td><td class=''>04</td><td class=''>46</td><td class='r'>99</td><td class=''>10</td></tr><tr><td class=''>87</td><td class=''>89</td><td class=''>62</td><td class=''>52</td><td class=''>76</td><td class=''>71</td><td class='r'>50</td></tr><tr><td class=''>85</td><td class='r'>50</td><td class=''>53</td><td class=''>53</td><td class=''>48</td><td class=''>69</td><td class=''>87</td></tr><tr><td class=''>89</td><td class=''>12</td><td class=''>60</td><td class=''>67</td><td class='r'>83</td><td class=''>92</td><td class=''>52</td></tr><tr><td class=''>45</td><td class='r'>77</td><td class='r'>22</td><td class=''>86</td><td class=''>90</td><td class=''>42</td><td class='r'>22</td></tr><tr><td class=''>76</td><td class='r'>77</td><td class=''>06</td><td class=''>10</td><td class=''>76</td><td class=''>90</td><td class=''>59</td></tr><tr><td class=''>29</td><td class=''>15</td><td class=''>24</td><td class='r'>49</td><td class=''>75</td><td class=''>37</td><td class=''>19</td></tr><tr><td class=''>15</td><td class=''>67</td><td class='r'>49</td><td class='r'>16</td><td class=''>41</td><td class=''>07</td><td class=''>07</td></tr><tr><td class='r'>**</td><td class='r'>00</td><td class=''>40</td><td class=''>68</td><td class=''>87</td><td class=''>04</td><td class=''>69</td></tr><tr><td class='r'>61</td><td class=''>09</td><td class=''>92</td><td class=''>93</td><td class='r'>83</td><td class=''>64</td><td class='r'>27</td></tr><tr><td class=''>08</td><td class=''>79</td><td class=''>60</td><td class=''>76</td><td class='r'>22</td><td class='r'>16</td><td class=''>48</td></tr><tr><td class=''>60</td><td class=''>23</td><td class=''>36</td><td class='r'>77</td><td class=''>34</td><td class=''>74</td><td class=''>36</td></tr><tr><td class=''>08</td><td class=''>14</td><td class=''>74</td><td class=''>57</td><td class=''>36</td><td class='r'>11</td><td class='r'>94</td></tr><tr><td class=''>58</td><td class=''>53</td><td class='r'>**</td><td class=''>18</td><td class=''>34</td><td class='r'>00</td><td class=''>71</td></tr><tr><td class='r'>11</td><td class='r'>50</td><td class=''>80</td><td class=''>75</td><td class=''>42</td><td class=''>47</td><td class=''>47</td></tr></table>
</div>
</div>
</div>
<div class="clear">&nbsp;</div>
</div>


<div class="chart-result">    
		<div>PUNA BAZAR</div>
		<span>680-47-340</span><br>
		<a href="puna-bazar.php">Refresh Result</a>
</div>
	

<div class="container-fluid footer-text-div">
<p>DPBoss Services is the best Satta Matka platform to play all Satta Matka games online, including Puna Bazar. It is because of the enticing live gaming house promotions, and instantaneous as well as safe withdrawals. The Satta Matka website also encourages an assortment of global payment methods. Users of the betting site can expect professional and dedicated support services round-the-clock. Additionally, you will be capable of finding and playing all current as well as newly added Satta Matka games on DPBoss Services.</p>
<br>
<div class="small-heading">DPBoss Services: Puna Bazar Jodi Chart Records</div>
<p>If you are ready to play live Satta Matka games online, then playing them with DFPBoss is the best option. The Staka Matka website offers a huge collection of betting games to choose from, including Puna Bazar. All the betting games offered by the site are known for their exhilarating as well as innovative game features. You can also find these games in different variations and you can be involved with gamblers from all around the globe through the in-game conversation in real-time.</p>
<br>
<div class="faq-heading">Frequently Asked Questions (FAQs):</div>
<p class="faq-title">Q1. What Makes DPBoss Services very popular?</p>
<p class="faq-ans">DPBoss stands out in the gambling industry for its varied Satta Matka game collection, pioneering streaming technology, and professional gamblers from many parts of the world.</p>
<p class="faq-title">Q2. how can I get the ultimate Puna Bazar gaming experience?</p>
<p class="faq-ans">Choosing DPBoss Services to play your Puna Bazar game online is the best as well as the cleverest option to get the  ultimate gaming experience. It is because, the top pririty of this Satta Matka betting platform is to meet all the gaming and betting needs of its users.</p>
</div><br><br>

<div class="para3">
<p style="margin: 0;font-size: 12px;line-height: 14px;"> 
Hello, and welcome to Dpboss.Services, today I would love to greet you on this page where we are going to shed light on yet another very important chart in our chart explainer series. Welcome to the Puna Bazar Jodi Chart. This chart shows all the results, new and old, and the complete historical data of all the games that are played across this Market Puna Bazar, and for all the sessions of day and night. 
<br>
<br>
This chart is very important if you want to check the results of the Matka games you played in this market if you have a lot of games in this market you can see all those together on a single page, and for better preparation for your future games, you can separate the winning and losing Jodis that you picked in the past, and then you should analyze those, find out why you choose those numbers, they won or lose if win how they won, and if lost, why they lost, and with what margin? By getting the answers to all these questions you will become a very smart player, and most probably you will become the next Matka King of this market, who knows? 
<br>
<br>
The results are presented in this chart in front of you in the form of Jodi. Here you can see the seven columns that are for each day of the week, starting from Monday, then Tuesday, Wednesday, Thursday, Friday, Saturday, and finally Sunday, this market works on all seven days of the week without any day off. 
<br>
<br>
In the chart, you can find the patterns of how these numbers are winning and how others are losing. There can be some blank cells, you can ignore them they are the days with no results or unconfirmed results, you need to focus only on the numbers that you are going to select as your Jodi for the next game, and after multiple iterations, your Jodis will pass from various filters and only the most probable to win Jodis will be remaining, and you will increase you winning chances.</p>
</div>

<center>
	<div id="bottom"></div>
	<a href="#top" class="button2"> Go to Top </a>
</center>
<p>
182</p>
	
	
<!-- adv & links -->
<!-- footer -->
<footer style="font-style: normal;">

  
  <a class="ftr-icon" href="https://dpboss.boston">dpboss.boston</a>
  <p>
    All Rights Reseved®
    <br>
    (1998-2024)
    <br>
    Contact (Astrologer-<span>Dpboss</span>)
  </p>
</footer>

<!--<a class="mp-btn" href="https://dpboss.boston/dpbossplay-matka-online.php"><i>Matka Play</i></a> -->
<a class="mp-btn" href="https://matkabank.mobi/"><i>Matka Play</i></a>

 


</body>
</html>