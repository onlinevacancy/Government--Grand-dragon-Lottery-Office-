<!DOCTYPE html>
<html amp lang="en-in"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<title>Sridevi Jodi Chart | Live Jodi Matka Record</title>
<meta name="description" content="We offer the quickest Online Jodi Satta Matka results. Players can visit our website and check their live results using the Sridevi Jodi Chart record." />
<link rel="canonical" href="https://dpboss.boston/jodi-chart-record/sridevi.php">
<link rel="alternate" href="https://dpboss.boston/jodi-chart-record/sridevi.php" hreflang="en">
<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "NewsArticle",
		"author": "dpboss.boston",
		"headline": "Open-source framework for publishing content",
		"datePublished": "2015-10-07T12:02:41Z",
		"image": [
			"logo.jpg"
		],
		"publisher": {
      "@type": "Organization",
      "name": "DPBOSS",
      "logo": {
        "@type": "ImageObject",
        "url": "https://dpboss.boston/logo.png"
      }
    }
	}
</script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>

<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<link rel="shortcut icon" href="https://dpboss.boston/fav/favicon.ico">
<style amp-custom>
html{scroll-behavior:smooth}
body{background-color:#fc9;
text-align: center;
font-weight: 700;
padding: 0;
font-family: Helvetica,sans-serif;}
.logo {
  background: #fc9;
padding: 0 10px;
display: block;
color: #fff8f8;
margin-bottom: 5px;
letter-spacing: 1px;
font-weight: 700;
border: 3px solid #ff0016;
border-radius: .75em;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1),background 150ms cubic-bezier(0,0,.58,1);}
  .logo amp-img{width:220px;height:auto;padding:6px 0 0}
.button2{background-color:#a0d5ff;color:#220c82;padding:10px 30px;font-size:14px;margin: 0px 0px 5px 0px;border:2px solid #0000005c;font-weight:800;text-decoration: none;text-shadow:1px 1px #00bcd4;box-shadow:0 8px 10px 0 rgba(0,0,0,.2),0 6px 8px 0 rgba(0,0,0,.19);display:inline-block;transition:all .3s}.ad-div11{text-align:center;margin:0 0 10px}.chart-list{border:2px solid #eb008b;margin-bottom:2px;width:50%;margin:0 auto 10px;text-align:center;font-weight:600}.chart-list.ab1{border-color:#003c6c}.chart-list h4{color:#fff;padding:5px 10px 3px;font-size:24px;border-top-left-radius:7px;margin:0}.chart-list.ab1 h4{background-color:#024c88}.chart-list a{display:block;font-size:22px;padding:5px 7px 4px;text-decoration:none}.chart-list a:hover{text-decoration:none}.chart-list.ab1 a{border-bottom:2px solid #024c88;color:#003c6c}.chart-list a:hover{background-color:#fff;text-decoration:underline}@media only screen and (max-width:500px){.chart-list{width:95%}}footer{background-color:#fff;color:red;font-weight:bold;font-size:25px;text-decoration:none;border:4px groove purple;text-shadow:1px 1px gold;margin:3px}footer > div{border-bottom:2px solid #b2ddff;padding:10px 0;margin-bottom:10px}footer > div a{text-decoration:none}footer > div a:hover{text-decoration:none}footer .ftr-icon{text-decoration:none;font-size:35px;text-transform:uppercase;color:#007bff}footer p{margin:10px 0 10px;line-height:35px}footer p span{color:rgb(51,102,255)}.panel.panel-info{border:1px solid #3f51b5;width:50%;margin:0 auto 0}.panel-heading h1{margin:0;padding:5px}table{border-collapse:collapse}table,th,td{border:1px solid #000}thead{background-color:#ffc107;text-shadow:1px 1px 2px #9a7400ab}tbody td{padding:5px 0;font-size:24px}.red,.chart-11,.chart-22,.chart-33,.chart-44,.chart-55,.chart-66,.chart-77,.chart-88,.chart-99,.chart-00,.chat-05,.chat-50,.chat-16,.chat-61,.chat-27,.chat-72,.chat-38,.chat-83,.chat-49,.chat-94{color:red}
.chart-05,.chart-50,.chart-16,.chart-61,.chart-27,.chart-72,.chart-38,.chart-83,.chart-49,.chart-94{color:red}

.css-11, .css-16, .css-22, .css-27, .css-33, .css-38, .css-44, .css-49, .css-50, .css-55, .css-61, .css-66, .css-72, .css-83, .css-88, .css-94, .css-99, .css-05, .css-00, .css-77, .css-star {
    color: red;
}

@media only screen and (max-width:770px){.panel.panel-info{width:70%}} 
@media only screen and (max-width:500px){
	.panel.panel-info{width:100%}
}.r{color: red;}td{font-weight: 700;}

@media only screen and (max-width:500px) {
 .chart-list {
  width:95%;
 }
}
.mp-btn {
  position: fixed;
  bottom: 9px;
  left: 5px;
  padding: 5px 8px;
  font-size: 15px;
  border: 1px solid #fff;
  text-decoration: none;
  background-color: #039;
  color: #fff;
}

.para3 {
  background: linear-gradient(187deg,#fc9 50%,#ffc387 50%);
  border: 2px solid #ff0016;
    border-top-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-left-style: solid;
  border-style: outset;
  margin-bottom: 3px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
}

.chart-h1{
background: #ff00a2;;
padding: 5px 10px;
text-shadow: 1px 1px 2px #000;
display: block;
color: #fff8f8;
margin-bottom: 3px;
letter-spacing: 1px;
font-weight: 700;
border: 2px solid #fff;
transform-style: preserve-3d;
transition: transform 150ms cubic-bezier(0,0,.58,1) , background 150ms cubic-bezier(0,0,.58,1);
font-size: 18px;
margin: 3px 0px;
}

h1{
color: #fff8f8;
}

.logo img {
  margin: 5px 0px;
}

h3{font-size: 16px;color:#fff; text-shadow: 0px 0px;margin: 0px;padding: 5px;}

.chart-result {
  margin: 6px 2px;
  line-height: 1.4;
  font-size: 14px;
  padding: 4px 10px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
  box-shadow: 0 0 20px 0 rgb(0 0 0 / 40%);
  border: 1px solid black;
}
.chart-result div {
  font-size: 22px;
  color: #00094d;
  text-shadow: 1px 1px 2px #fff;
}

.chart-result span {
  color: #880e4f;
  text-shadow: 1px 1px 2px #ffe2c6;
  font-size: 21px;
}

.chart-result a {
  border: 1px solid #e6e6e6;
  background: #522f92;
  color: #fff;
  padding: 5px 7px;
  font-size: 12px;
  margin: 2px 0 -1px;
  display: inline-block;
  transition: all .3s;
  cursor: pointer;
  text-shadow: none;
  text-decoration: none;
}
@media screen and (max-width: 400px) {
.logo img {height: 60px;width: auto;max-width: 100%;}
}

@media screen and (max-width: 300px) {
.logo img {height: 40px;width: auto;max-width: 100%;}
}


.footer-text-div p.faq-title {
  font-weight: 600;
}

.footer-text-div {
  max-width: 100%;
  text-align: center;
  margin: 2px;
  border: 2px solid purple;
  background: white;
  padding: 10px;
}

.small-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}

.footer-text-div p {
  font-weight: 500;
  font-size: 12px;
  padding: 0px;
  margin: 0px;
}

.faq-heading {
  font-weight: 600;
  color: red;
  text-shadow: 0px 0px 1px yellow;
}
</style></head>
<body>
    <div class="logo" style="box-shadow: 0 8px 0px -3px #ff9628;">
<a href="https://dpboss.boston/">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhsAAABpCAMAAACkjBFsAAAAvVBMVEUAAADrAIz/AKDrAIwAAADuAJHrAI0AAADsAI0AAAAAAADrAI3rAIwAAADsAI33AJkAAADrAI3wAJEAAADtAI7rAI3sAI0AAADrAI0AAAAAAADsAI0AAADsAI70AJPuAI8AAADsAI3uAI8AAAAAAADsAI0AAAAAAAAAAADsAI0AAADsAI3sAI0AAAAAAAAAAADsAI4AAAAAAADrAI3sAI3tAI0AAADrAI3tAI4AAAAAAAAAAAAAAAAAAADsAIxr+UChAAAAPXRSTlMA+wX29h7xDeOBxNPq4aYMF9wRbj/KgC+31CCSYTcXJ6vAL+q3ZE8GQ3Q5sIrKlotGpHlrXE0mnFWd7VgIj72kFgAAEBFJREFUeNrs2k2rozAUBuB8kEwgQYmYEAgqClKKLgQtduX//1nT5CadKdyBWd+cZ9GWQ3e+5JyjIgAAAAAAAApyQwBAMsD/Ig1rD+udVDxQQjo7b1NPEChaCMa8OiOFUvQKMOVKm+U8JlYjUK6m3SsjOL7+wBi/PriSi90gHOWqH14Kiq9vcVm1NQwiRSLsqDT/Jhj0JZapPNsaxo4CDfOi6fUXnL6UHEctQm+h2k8NhKM4xI78IxkvMR5Yrl07WxOPFFW1DQJFIf2hP9uJck7HiLx+MULY00saDhHf1nD/oyj97DC+Msx1NT+suSKqD4ZQPd1daDnSDwSiUZKpCtHI+OhbxrzISfEdCeGYNQ3ryt5ANgrSzx8dZTkYuXWO5mPEtSQuMosKx4jrYBwtSHfyK8PCTzVC5JA4bSv07EgcMQ4TSsoyBIoRLnpCRxsHimHlOFXEkR6mMK9CwWxwcJTjLnG+paHtFBtI6yjOaQmVgO06FMQOe2w5VnElwg4xCP0ucC6tOQr1ZmioVDBxlOOdDb0OJC0u+djg1QMlZHKxaO7w1K0Qv5BNa4qqupSCh3wfGzNDCRm+EqPOAYEi3G67jL2Cmp2gqLc8ry2mrVHWV/F/3G0IFGJbvq65nT6aR0BPht6ak8aafKJ/IARGkZ+F3ePAMea3d+qnvhJ5NOit8TEbWO0EZcNvds50TU0YCsMQQFwAQVBxwW3ccUbEXVvv/7Kq4XCSYG3n6U/q96PPQBapefOdk5AZL9AACKIF+yjQ3q9q8yQSWEX5bhsajOpohXthVp88syE3EJhRIwwbEa1UCxphve4fGydPe+ORG1W9lWP48P59RiZDBbINh9/LIL0O3O9oKS2Lu8MYw05QlUjUoevewuP0cfSmIy8i1VGjM+nB1eM1G6juEa6WZimpm6SGExYeODirU987Vgpw9KNQtyb9Nxy5EZdFRsM0EzWOhHeXkQ9shCOAZWFAxaF1p0S+FY0k6twq77cuedIMj4AV0DYWQuQJ0lgzDJKaHl3PyHAeXTbqi0Vo3H+kO+tv48iftJAtYD2+oBZV5ISEoQfrG+HdvtHZV2s7MB3Ff//OQt5EpH0FB3shBAY4OMjY8I5gG1SGH/UeSx64dBbvlCNnIjVuTzSqCWwsjAQFOWGDTOrc2WPFOj1Y0FYy3LH2bzbyJRJYGFIsMZ/sr4Aa2Q+S9YxDWaH/KMmLF8K22ytb6a1cqXfCkOLsxIwhsBRIPOk6hURDA23jVrS0Gm3fUPB9/9s38iW2Jyr7fbFoP8Rw8Sipbg2FrVL8CRwOWykpLZ13MporcTlEcVXNHg9LUehoNKTcbsiGA2kr6XcYG7VvLJyb1/ja1J8L7Hk3dq/Lp/rLqxt357r0LzpM3e7Sfr6vz7uu253PpG9KX3bjafO/O25fwz1ReXgiIjb3IjkpWtXul3ufy0R9jwAbR5lno/szldoan109M1hnNSkbZCBwP6FVy/0hMS0HKnS2PkhParPPMsub2M7AVvpICstTsWA6hk4va2gC1xmlzz4fw4d8HRgtycNKqM3j+kPKlYIQQ0qoZbAZGqlNLKqPxMJhtlHf9gCgKITm1HeADdQl5ujQB1zJ2OYQaHEF5hzrb7jbamn2gg2scW5zhbHKddnkkBnwTdy/smGXuVvnGbJB5eaajUmFnRPN2Ea/ooBvGI/cYhQqaBuKFUCtKotJToMgG0wmMmC3xII2ooFjI3zjeku8XdZfsIFS0Y1mA7EAebNNscngL2w0xfqftsCGaueXDVKz0DaGu+xf5yiCT8jO/n59AtugGGD4qa2K0J5uuCMbTGWYa7qZKbjYMMRPQ3Ol98fZ2+NXbKA+Ut4G2ZIUjla24PwnNp6frYVsUG3yy4Y0Gt5AhU4gFmkNBVAo1L07Kg0Z16+FELdA+5aBy5wdsvFVKpXWA4ABwv0aJmo8dTcqzFmqM9j74Ud7nhi4ScM8fPtLW2+uVRzgJzbG9LNgzNeQUgCWpWn3y0y6TNIYQPdrqdvLc/LzQZLiUiKT1oQLGsOS51E37jQG3GJgA7TMLRvVXREjwlYTLWXvy2AURasvVUeWjCGlgjsZxKvLKTBHD798iO8uN17N5Fue8lFkzqL95QATHo3ji48v098ZRxtrYJct3qLWGMrwYszT6oJxoD4pUHDBULok/50r/QT1ILDRmuWVDa2DOcQwIkJRD1ewt0qjJ1VPFbQN2YpmaQdbhMto9EmGDanMxmvARgVIgWGwYehgvHG8xugg2JP6gg2qmF7ZIpMsxVB1DCmfEijxiT+wYYKzJLoylnQMMnFO2SB7FlKOfbFoFBYAhdtjm2u0MmS0jb2GMalTwLu7nugbOPcfdv4DpzX4A47kQcz41TTafGID1tPsD2xMmRWVxTzRZUmMKdjP+BUbAsEbEZWLyIbazicbvQXO+sqilslE6w8uKA+WJ0kntkoxwhFajBciMXVP+j0bKptzXex/juM6QwsRNcA5K+g1G/jJdiZW6CoSgdRwes1GCboUIZsDG6BxPtkIcNYrfkQymahxAynbqkQazg3Z4DBa1HE3bKU9s9HCL2+NPiH6A+Z74zYUiANhTr/DBnJ4mQEl4BNcQPpgj9Gaf4+NMfiE6CMltvfF4uQmsaDciOx8GY/paGKR5yupb1T2d4qYbSh1jWA1H3dVCxOSZaO9YTY/yOYLJo7DNJ2AXV3i9MOEbC8+fIMNPYZxQ6qWEip5Dpp7qNCp2/4GGy0+rCERZ/ypVE6WQDn0jdoKzcCZEJGNrYOGYI3ulxW0jWKHoaE5iIwTcZn9Z/muD1gvSlI2e8C5bOKMh6103iXmKi4GXPs1G2b5LhO3x5hHZWNDG0AElQHF12ygt6EulGHGRpvWWOePDdK3CmKywKRZBbANubjQ7hRxtnFitfZG0hyOeCAbTCakGJgEZucyG0x4x6EzOD64qL58xQaTCm1Fj8KHWuJKFFFsv2ZDXEGJRoJsJNSph9yxAX9CAV/CZ0+KAgtDj0iBz2zD0hCuoMMS1JX2ezbghYoqsIFmASA0P7kWjAKdVgLFf2fj6xd757qeJhCEYVkUSETwAKJGQbCeDUk1Gjw83v9ltUSYb5dKbP9Svl9toj6EfZ2ZnRlmBxQmEBswFjMUVFBP+Y6NAdgQjR3YuNxcY+HYaKMzWEvCSyy6IiXRhvJSq7Bp64rsJ7kUF55Gan20wYag56+M5AS3nWcDy/fM11NIg2OV+6BcNlCjuWs3zmJW1eHoGD+0G6HAhmg3UuyGBWOD1T51NIoygZqpLUnkQlilDfugbDw+XoV1GTGOjeEiVqef3FxYY+hH9mY64QmJaEhNPgWrlGEjXMQajlHuCLPxxja7HW5uGzBHfxlvIIAGGymIE7VgbFi+nC54L8hQ89W5cZtM7DHmra/oG2wTQUi4xy/jXbvDA1Ad3LHzgAW6DBPX0hCjxNXPKgpmD/Kiw+RfuAYhOIUW48StOPlsNJBF5WEBG7TzCYvFRnvKjXGqCYFoPDMw+Z2/MyvtyKZItIfxHO+GQi7F3pn32HBo9Y5JeEGaIADhtGhQaEBCjDD+jo05hbtD8TPgZEQdnimeyGHjFXupTHCqZnfM/SLlN5iHdLc/ZXOhyianxXi5O2KVAHkwHVU2lzrGkrGTGTbwRTvSHZzdSSM9xZoRHKmhn8U/3orJjv53bCADfsh4oPkpXfNh/KGdTL40n403+CLujzuDDa7sXyS7YVo9mVY284S0fpWkxB7s25VKZGCXMk3Nhmu1FHiaqVvJZyOkr9xzNiOO3W2WJvgBFPKrj9no02pVyUh16HU/8Sl/U09ZcZDhcy8ZNlbFY4Mb8SU8zubub9uX2K0ocW2VdbntyB5bGf1KwuxisIHb1kF1fCGYjT4S2mqGpqxj+PmQDfVEbmcLZ4GKfZOSYCtx2/GoDlsV67DjCthIrq1obLiorttRm2MmMiTkuUYmTf2KJaVBK/M2hBZGF2fZcBpYi5nQv3HCyndud3zOv394i/HQ1jE4wbo4nbOaYQN9nVtkxu/0bzhCm+Kh+l3/BiCbOHzDkPMHG81TwdjwEESsR0wY6ZNaDVlbxr+wbEzFN7x0KhR3MI/kwyeh7+sp/CG00Y1z+r4uk6Sodrg0F2GVfE2YtBA7zYvT4Zp1nggZ9H09vf2o8hXzzp99Xyp3EdWO01SdbQNsiWxAfaHvCzyAjVidgrFhYab5i8tnvXQJlROPxaUVDWysa8kcDltGq4/WdcVwTZRD3y4IpXLUTaAxWol5TZoowIMNQR14C1EL9PmI6qs5bMC08GrMeTbojcViI0pDUUneIdNprRWJjugy9jEaXtLkg0EcbCTMWlD8EZvns/FG9xnrAksda1bNLNcFzkDsIkfH2F02kItQf4hvPVOMIlwEggmRDWghEt0fVO6x4RSLjZ0tobqezGpxo08NzeTKrYPUsuE95PrONd191+fQkOyuO8+1G/1zzvMpz00x0wC9DtK955vA0pnbeL7dY2OyVXOeT1lxF3EUzMAiL2dOMPHXNlYrIhupwkKx0a2nbGhRYjS8na9wAWYvMOPYFGetyLKk9JbTZU+XrpDcDZjIBh5sC8+ZdFOYrFj2ubZZ2EgLrvxqOU+v6SLS826z0+8XqcQGPdh2pFdk8uKvmYtYvfVTcIf5dVholWZQj7AxWTbUSZHYQO+G1g1qbi3Y79baFdKN99sJOy/ES91vXWVN02TxHNnRPx3M1HRWzt1uDPWwWh2a998wEJLoeP8DNQ94q6D5IL4K9R8v+r8RspqKbXx+Gmu7Fe9NUIq/zWlpWz79bLP/AkriHYpsL8vZs0UTn/FWFF1XZFnmVt2fumltBSOLXctQwM/tefpuUKJRNJFPIUmcNaAk+Gij01SfIM5+6DJeKZXHQBZSEVVR4SbgUKgS/0FVl1a81WXBxpbJ98j1aa1Eo3iqTes3E6HXNUXwE7rftSiZhVpKcvqjFxnaDQ69/vlRnldfRLFg04rdQ91Yvvh1XcFx9OtpYOKUDMqsJ4dnMHf00qu3tJa9jhEqVUjVIqNeN/ZmhbnBx2bd823f7xk7y2UAiBtnvUQ5zvXe30derTw7pbBirvUxHX2RwMyaZ71H0bvltfkVZ0scrBLxo9BNk5XH6hRZjJnITTD8DzIpYFWMoFKqFIm5dMhw66U856CU0BtGkai9K4eHluLk4vQMwyqji1K/2ruXFAZhIADDEqkUAoaKFTdWFLKQduFC0fufrCDtzKTeoPzfJWYymYcKZnr+RUiBUa2SbhQLN+mRngqVvbQ1pXEYo7aU8kpBYm0lpEyEFFjR6zgbrxQYbrua9nJAuNDmeok8A0S46P63hqIojGq+SbdPzAD1iNIp6tcMSC6AyhQTqSgMN5Zy3HMjFYXh9DPFT6SiMCpdHjosVL5ghOi1dyMDVNgHqW7w0QbL9d/99vlOSEEidP5z8JOQgpQLzbGxJ38yfYAfrjuGYQv6enDixmm4+7KmuoGzapzrnpYvAAD+zxsTdnYFikaAUwAAAABJRU5ErkJggg==" alt="Image of dpboss.boston" height="57" width="292">

</a>
</div>
<div class="container-fluid">
        <div>
<h1 class="chart-h1" >SRIDEVI JODI CHART</h1>
<div class="para3">
<h2 style="font-size: 14px;margin: 0px;"> SRIDEVI JODI RESULT CHART RECORDS </h2>
<p style="margin: 0;font-size: 12px;line-height: 14px;">Dpboss SRIDEVI jodi chart, SRIDEVI jodi chart, old SRIDEVI jodi chart, dpboss SRIDEVI chart, SRIDEVI jodi record, SRIDEVIjodi record, SRIDEVI jodi chart 2015,
SRIDEVI jodi chart 2012, SRIDEVI jodi chart 2012 to 2023, SRIDEVI final ank, SRIDEVI jodi chart.co,
SRIDEVI jodi chart matka, SRIDEVI jodi chart book, SRIDEVI matka chart, matka jodi chart SRIDEVI, matka SRIDEVI chart,
satta SRIDEVI chart jodi, SRIDEVI state chart, SRIDEVI chart result,
डीपी बॉस,  सट्टा चार्ट, सट्टा मटका जोड़ी चार्ट, सट्टा मटका जोड़ी चार्ट, श्रीदेवी मटका जोड़ी चार्ट, सट्टा मटका श्रीदेवी चार्ट जोड़ी, श्रीदेवी सट्टा चार्ट, श्रीदेवी जोड़ी चार्ट </p>
</div>

<div class="chart-result">    
		<div>SRIDEVI</div>
		<span>150-62-390</span><br>
		<a href="sridevi.php">Refresh Result</a>
</div>
	
<div id="top"></div>
<a href="#bottom" class="button2"> Go to Bottom </a>			<div class="panel panel-info" >
            	<div class="panel-heading text-center" style="background: #3f51b5;">
			<h3>SRIDEVI MATKA JODI RECORD 2018 - 2026</h3></div>
                <div class="panel-body">
                	<table style="width: 100%; text-align:center;" class="panel-chart chart-table"  cellpadding="2">
                	<thead>
                	<tr>
                		<th>Mo</th>
                		<th>Tue</th>
                		<th>Wed</th>
                		<th>Thu</th>
                		<th>Fri</th>
<th>Sat</th>
                		<th>Sun</th>
												
												
                	</tr>
                	</thead>                	
                	<tbody>
					
					<tr>

<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-85">85</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-88">88</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-53">53</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
 </tr>
<tr>

<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-17">17</span>
</td>
</tr>
<tr>

<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-64">64</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-86">86</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
</tr>
<tr>

<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-36">36</span>
</td>
<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-25">25</span>
</td>
</tr>
<tr>

<td >
<span class="chart-22">22</span>
</td>
<td >
<span class="chart-88">88</span>
 </td>
<td >
<span class="chart-01">01</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-55">55</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
</tr>
<tr>

<td >
<span class="chart-56">56</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-86">86</span>
</td>
<td >
<span class="chart-75">75</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-78">78</span>
</td>
</tr>
<tr>

<td >
<span class="chart-88">88</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
</tr>
<tr>

<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-74">74</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-98">98</span>
 </td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
</tr>
<tr>

<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
</tr>
<tr>

<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-21">21</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
</tr>
<tr>

<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-27">27</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
</tr>
<tr>

<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-78">78</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-35">35</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
</tr>
<tr>

<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
</tr>
<tr>

<td >
<span class="chart-65">65</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-54">54</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-62">62</span>
</td>
</tr>
<tr>

<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
</tr>
<tr>

<td >
<span class="chart-83">83</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-14">14</span>
</td>
</tr>
<tr>

<td >
<span class="chart-17">17</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
<td >
<span>*</span>
</td>
</tr>
<tr>

<td >
<span class="chart-83">83</span>
</td>
<td >
<span class="chart-01">01</span>
</td>
<td >
<span class="chart-55">55</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
<td >
 <span class="chart-36">36</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
</tr>
<tr>

<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-72">72</span>
</td>
<td >
<span class="chart-27">27</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
</tr>
<tr>

<td >
<span class="chart-72">72</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-74">74</span>
</td>
<td >
<span class="chart-94">94</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
</tr>
<tr>

<td >
<span class="chart-58">58</span>
</td>
<td >
<span class="chart-17">17</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span>*</span>
</td>
</tr>
<tr>

<td >
<span class="chart-88">88</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
</tr>
<tr>

<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-33">33</span>
</td>
</tr>
<tr>

<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
<td >
<span>*</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-24">24</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-14">14</span>
</td>
</tr>
<tr>

<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-07">07</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-27">27</span>
</td>
<td >
<span class="chart-01">01</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
</tr>
<tr>

<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-94">94</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
</tr>
<tr>

<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
<td >
<span class="chart-01">01</span>
</td>
<td >
<span class="chart-94">94</span>
</td>
<td >
<span class="chart-26">26</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-64">64</span>
</td>
</tr>
<tr>

<td >
<span class="chart-62">62</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-26">26</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-54">54</span>
</td>
</tr>
<tr>

<td >
<span class="chart-43">43</span>
</td>
<td >
<span class="chart-29">29</span>
</td>
<td >
<span class="chart-53">53</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-17">17</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
</tr>
<tr>

<td >
<span class="chart-01">01</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-86">86</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
</tr>
<tr>

<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-15">15</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-65">65</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
</tr>
<tr>

<td >
<span class="chart-95">95</span>
</td>
 <td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-24">24</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
</tr>
<tr>

<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
</tr>
<tr>

<td >
<span class="chart-54">54</span>
</td>
<td >
<span class="chart-05">05</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
</tr>
<tr>

<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-07">07</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
 <td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-75">75</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
</tr>
<tr>

<td >
<span class="chart-56">56</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
</tr>
<tr>

<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-53">53</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
</tr>
<tr>

<td >
<span class="chart-07">07</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
 </tr>
<tr>

<td >
<span class="chart-16">16</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-85">85</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-22">22</span>
</td>
</tr>
<tr>

<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-29">29</span>
</td>
<td >
<span class="chart-05">05</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
</tr>
<tr>

<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
</tr>
<tr>

<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-29">29</span>
 </td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-21">21</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-56">56</span>
</td>
</tr>
<tr>

<td >
<span class="chart-72">72</span>
</td>
<td >
<span class="chart-85">85</span>
</td>
<td >
<span class="chart-21">21</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
</tr>
<tr>

<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-25">25</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
</tr>
<tr>

<td >
<span class="chart-35">35</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-15">15</span>
 </td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
</tr>
<tr>

<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-22">22</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-05">05</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
</tr>
<tr>

<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-74">74</span>
</td>
<td >
<span>*</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
</tr>
<tr>

<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-58">58</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
</tr>
<tr>

<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-53">53</span>
</td>
<td >
<span class="chart-26">26</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-54">54</span>
</td>
</tr>
<tr>

<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-47">47</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
</tr>
<tr>

<td >
<span class="chart-29">29</span>
</td>
<td >
<span class="chart-56">56</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
<td >
<span class="chart-64">64</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
</tr>
<tr>

<td >
<span class="chart-75">75</span>
</td>
<td >
<span class="chart-22">22</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-38">38</span>
</td>
<td >
<span class="chart-36">36</span>
</td>
</tr>
<tr>

<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-29">29</span>
</td>
<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-35">35</span>
</td>
<td >
<span class="chart-43">43</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
</tr>
<tr>

<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-65">65</span>
</td>
</tr>
<tr>

<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span>*</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-46">46</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
</tr>
<tr>

<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-78">78</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-83">83</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
<td >
<span class="chart-68">68</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
</tr>
<tr>

<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-68">68</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
</tr>
<tr>

<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
</tr>
<tr>

<td >
 <span class="chart-58">58</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-63">63</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
</tr>
<tr>

<td >
<span class="chart-14">14</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-46">46</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-75">75</span>
</td>
<td >
<span class="chart-76">76</span>
</td>
<td >
<span class="chart-85">85</span>
</td>
</tr>
<tr>

<td >
<span class="chart-26">26</span>
</td>
<td >
<span class="chart-25">25</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
</tr>
<tr>

<td >
<span class="chart-43">43</span>
</td>
<td >
<span class="chart-78">78</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
 <span class="chart-11">11</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
</tr>
<tr>

<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
</tr>
<tr>

<td >
<span class="chart-38">38</span>
</td>
<td >
<span class="chart-94">94</span>
</td>
<td >
<span class="chart-24">24</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
</tr>
<tr>

<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-59">59</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-62">62</span>
</td>
<td >
<span class="chart-72">72</span>
</td>
<td >
 <span class="chart-62">62</span>
</td>
</tr>
<tr>

<td >
<span class="chart-33">33</span>
</td>
<td >
<span class="chart-63">63</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-25">25</span>
</td>
</tr>
<tr>

<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-21">21</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
</tr>
<tr>

<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-62">62</span>
</td>
</tr>
<tr>

<td >
<span class="chart-30">30</span>
</td>
 <td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-08">08</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-15">15</span>
</td>
</tr>
<tr>

<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-75">75</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-95">95</span>
</td>
</tr>
<tr>

<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-15">15</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
</tr>
<tr>

<td >
<span class="chart-95">95</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-36">36</span>
</td>
 <td >
<span class="chart-38">38</span>
</td>
<td >
<span class="chart-77">77</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
</tr>
<tr>

<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-98">98</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
</tr>
<tr>

<td >
<span class="chart-64">64</span>
</td>
<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-36">36</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-94">94</span>
</td>
</tr>
<tr>

<td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-55">55</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
 </tr>
<tr>

<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-24">24</span>
</td>
<td >
<span>*</span>
</td>
<td >
<span class="chart-85">85</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
</tr>
<tr>

<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-88">88</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-84">84</span>
</td>
</tr>
<tr>

<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-15">15</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-68">68</span>
</td>
</tr>
<tr>

<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-41">41</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
</tr>
<tr>

<td >
<span class="chart-15">15</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-68">68</span>
</td>
<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-35">35</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
</tr>
<tr>

<td >
<span class="chart-39">39</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
</tr>
<tr>

<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-76">76</span>
</td>
<td >
<span class="chart-78">78</span>
</td>
<td >
<span class="chart-07">07</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-14">14</span>
</td>
</tr>
<tr>

<td >
<span class="chart-27">27</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
</tr>
<tr>

<td >
<span class="chart-17">17</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-60">60</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-16">16</span>
</td>
</tr>
<tr>

<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-58">58</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
</tr>
<tr>

<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-37">37</span>
</td>
</tr>
<tr>

<td >
<span class="chart-85">85</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-67">67</span>
</td>
<td >
<span class="chart-91">91</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
</tr>
<tr>

<td >
<span class="chart-47">47</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-17">17</span>
</td>
<td >
<span class="chart-86">86</span>
</td>
<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-55">55</span>
</td>
</tr>
<tr>

<td >
<span class="chart-94">94</span>
</td>
<td >
<span class="chart-76">76</span>
</td>
<td >
<span class="chart-23">23</span>
</td>
<td >
<span class="chart-34">34</span>
</td>
<td >
<span class="chart-13">13</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-34">34</span>
</td>
</tr>
<tr>

<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-40">40</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-95">95</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
</tr>
<tr>

<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-97">97</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-63">63</span>
</td>
<td >
<span class="chart-90">90</span>
</td>
</tr>
<tr>

<td >
<span class="chart-81">81</span>
</td>
<td >
<span class="chart-06">06</span>
</td>
<td >
<span class="chart-57">57</span>
</td>
<td >
<span class="chart-36">36</span>
</td>
<td >
<span class="chart-86">86</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
</tr>
<tr>

<td >
<span class="chart-32">32</span>
</td>
<td >
<span class="chart-20">20</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
<td >
<span class="chart-47">47</span>
</td>
<td >
<span class="chart-69">69</span>
</td>
<td >
<span class="chart-65">65</span>
</td>
<td >
<span class="chart-68">68</span>
</td>
</tr>
<tr>

<td >
<span class="chart-79">79</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-53">53</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-27">27</span>
</td>
</tr>
<tr>

<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-09">09</span>
</td>
<td >
<span class="chart-35">35</span>
</td>
<td >
<span class="chart-56">56</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-49">49</span>
</td>
<td >
<span class="chart-52">52</span>
</td>
</tr>
<tr>

<td >
 <span class="chart-62">62</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span class="chart-44">44</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-42">42</span>
</td>
<td >
<span class="chart-73">73</span>
</td>
<td >
<span class="chart-27">27</span>
</td>
</tr>
<tr>

<td >
<span class="chart-45">45</span>
</td>
<td >
<span class="chart-30">30</span>
</td>
<td >
<span class="chart-18">18</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
<span class="chart-50">50</span>
</td>
<td >
<span class="chart-87">87</span>
</td>
</tr>
<tr>

<td >
<span class="chart-56">56</span>
</td>
<td >
<span class="chart-89">89</span>
</td>
<td >
<span class="chart-54">54</span>
</td>
<td >
<span class="chart-80">80</span>
</td>
<td >
<span class="chart-38">38</span>
</td>
<td >
<span class="chart-19">19</span>
</td>
<td >
<span class="chart-29">29</span>
</td>
</tr>
<tr>

<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-15">15</span>
</td>
<td >
<span class="chart-66">66</span>
</td>
<td >
 <span class="chart-52">52</span>
</td>
<td >
<span class="chart-82">82</span>
</td>
<td >
<span class="chart-12">12</span>
</td>
<td >
<span>*</span>
</td>
</tr>
<tr>

<td >
<span class="chart-51">51</span>
</td>
<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-02">02</span>
</td>
<td >
<span class="chart-00">00</span>
</td>
<td >
<span class="chart-28">28</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-81">81</span>
</td>
</tr>
<tr>

<td >
<span class="chart-83">83</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
<td >
<span class="chart-96">96</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-10">10</span>
</td>
<td >
<span class="chart-03">03</span>
</td>
</tr>
<tr>

<td >
<span class="chart-99">99</span>
</td>
<td >
<span class="chart-70">70</span>
</td>
<td >
<span class="chart-48">48</span>
</td>
<td >
<span class="chart-74">74</span>
</td>
<td >
<span class="chart-32">32</span>
</td>
<td >
<span class="chart-26">26</span>
</td>
<td >
 <span class="chart-80">80</span>
</td>
</tr>
<tr>

<td >
<span class="chart-24">24</span>
</td>
<td >
<span class="chart-93">93</span>
</td>
<td >
<span class="chart-31">31</span>
</td>
<td >
<span class="chart-04">04</span>
</td>
<td >
<span class="chart-11">11</span>
</td>
<td >
<span class="chart-92">92</span>
</td>
<td >
<span class="chart-71">71</span>
</td>
</tr>
<tr>
  <td><span class="chart-00">66</span></td>
  <td><span class="chart-69">30</span></td>
  <td><span class="chart-00">77</span></td>
  <td><span class="chart-69">86</span></td>
  <td><span class="chart-00">16</span></td>
  <td><span class="chart-00">77</span></td>
  <td><span class="chart-69">03</span></td>
</tr>
<tr>
  <td><span class="chart-69">19</span></td>
  <td><span class="chart-69">37</span></td>
  <td><span class="chart-69">17</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-00">83</span></td>
  <td><span class="chart-69">98</span></td>
  <td><span class="chart-69">86</span></td>
</tr>
<tr>
  <td><span class="chart-69">91</span></td>
  <td><span class="chart-69">**</span></td>
  <td><span class="chart-69">74</span></td>
  <td><span class="chart-69">24</span></td>
  <td><span class="chart-00">49</span></td>
  <td><span class="chart-69">25</span></td>
  <td><span class="chart-69">20</span></td>
</tr>
<tr>
  <td><span class="chart-00">49</span></td>
  <td><span class="chart-69">87</span></td>
  <td><span class="chart-00">44</span></td>
  <td><span class="chart-69">09</span></td>
  <td><span class="chart-69">08</span></td>
  <td><span class="chart-69">19</span></td>
  <td><span class="chart-69">65</span></td>
</tr>
<tr>
  <td><span class="chart-69">89</span></td>
  <td><span class="chart-69">87</span></td>
  <td><span class="chart-69">62</span></td>
  <td><span class="chart-00">88</span></td>
  <td><span class="chart-69">76</span></td>
  <td><span class="chart-69">62</span></td>
  <td><span class="chart-00">22</span></td>
</tr>
<tr>
  <td><span class="chart-69">10</span></td>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">80</span></td>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">59</span></td>
  <td><span class="chart-69">91</span></td>
  <td><span class="chart-00">50</span></td>
</tr>
<tr>
  <td><span class="chart-69">69</span></td>
  <td><span class="chart-00">55</span></td>
  <td><span class="chart-69">79</span></td>
  <td><span class="chart-69">57</span></td>
  <td><span class="chart-69">84</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-69">58</span></td>
</tr>
<tr>
  <td><span class="chart-69">39</span></td>
  <td><span class="chart-69">65</span></td>
  <td><span class="chart-69">21</span></td>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">01</span></td>
  <td><span class="chart-69">87</span></td>
  <td><span class="chart-69">41</span></td>
</tr>
<tr>
  <td><span class="chart-69">20</span></td>
  <td><span class="chart-69">67</span></td>
  <td><span class="chart-69">63</span></td>
  <td><span class="chart-69">45</span></td>
  <td><span class="chart-69">84</span></td>
  <td><span class="chart-69">09</span></td>
  <td><span class="chart-69">92</span></td>
</tr>
<tr>
  <td><span class="chart-69">32</span></td>
  <td><span class="chart-69">24</span></td>
  <td><span class="chart-69">60</span></td>
  <td><span class="chart-69">51</span></td>
  <td><span class="chart-69">64</span></td>
  <td><span class="chart-00">05</span></td>
  <td><span class="chart-69">58</span></td>
</tr>
<tr>
  <td><span class="chart-69">10</span></td>
  <td><span class="chart-69">90</span></td>
  <td><span class="chart-69">28</span></td>
  <td><span class="chart-69">97</span></td>
  <td><span class="chart-69">79</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-69">74</span></td>
</tr>
<tr>
  <td><span class="chart-69">08</span></td>
  <td><span class="chart-00">49</span></td>
  <td><span class="chart-69">26</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-69">23</span></td>
  <td><span class="chart-69">31</span></td>
  <td><span class="chart-00">83</span></td>
</tr>
<tr>
  <td><span class="chart-69">26</span></td>
  <td><span class="chart-69">69</span></td>
  <td><span class="chart-69">46</span></td>
  <td><span class="chart-69">02</span></td>
  <td><span class="chart-69">60</span></td>
  <td><span class="chart-69">90</span></td>
  <td><span class="chart-69">41</span></td>
</tr>
<tr>
  <td><span class="chart-69">29</span></td>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">23</span></td>
  <td><span class="chart-00">27</span></td>
  <td><span class="chart-69">56</span></td>
  <td><span class="chart-00">66</span></td>
  <td><span class="chart-69">89</span></td>
</tr>
<tr>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">56</span></td>
  <td><span class="chart-69">91</span></td>
  <td><span class="chart-69">06</span></td>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">48</span></td>
  <td><span class="chart-69">56</span></td>
</tr>
<tr>
  <td><span class="chart-69">85</span></td>
  <td><span class="chart-69">60</span></td>
  <td><span class="chart-69">95</span></td>
  <td><span class="chart-69">57</span></td>
  <td><span class="chart-69">86</span></td>
  <td><span class="chart-00">94</span></td>
  <td><span class="chart-69">47</span></td>
</tr>
<tr>
  <td><span class="chart-69">32</span></td>
  <td><span class="chart-69">48</span></td>
  <td><span class="chart-69">81</span></td>
  <td><span class="chart-69">43</span></td>
  <td><span class="chart-69">82</span></td>
  <td><span class="chart-69">75</span></td>
  <td><span class="chart-69">62</span></td>
</tr>
<tr>
  <td><span class="chart-69">53</span></td>
  <td><span class="chart-69">78</span></td>
  <td><span class="chart-69">79</span></td>
  <td><span class="chart-69">54</span></td>
  <td><span class="chart-69">70</span></td>
  <td><span class="chart-69">35</span></td>
  <td><span class="chart-69">35</span></td>
</tr>
<tr>
  <td><span class="chart-69">24</span></td>
  <td><span class="chart-69">31</span></td>
  <td><span class="chart-69">53</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-69">21</span></td>
  <td><span class="chart-69">32</span></td>
  <td><span class="chart-69">09</span></td>
</tr>
<tr>
  <td><span class="chart-69">71</span></td>
  <td><span class="chart-00">66</span></td>
  <td><span class="chart-00">38</span></td>
  <td><span class="chart-69">62</span></td>
  <td><span class="chart-69">82</span></td>
  <td><span class="chart-69">31</span></td>
  <td><span class="chart-69">78</span></td>
</tr>
<tr>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">73</span></td>
  <td><span class="chart-69">51</span></td>
  <td><span class="chart-00">27</span></td>
  <td><span class="chart-69">85</span></td>
  <td><span class="chart-69">02</span></td>
  <td><span class="chart-69">81</span></td>
</tr>
<tr>
  <td><span class="chart-69">75</span></td>
  <td><span class="chart-00">99</span></td>
  <td><span class="chart-69">79</span></td>
  <td><span class="chart-69">69</span></td>
  <td><span class="chart-69">98</span></td>
  <td><span class="chart-69">24</span></td>
  <td><span class="chart-00">88</span></td>
</tr>
<tr>
  <td><span class="chart-69">90</span></td>
  <td><span class="chart-69">53</span></td>
  <td><span class="chart-00">33</span></td>
  <td><span class="chart-69">80</span></td>
  <td><span class="chart-69">42</span></td>
  <td><span class="chart-69">41</span></td>
  <td><span class="chart-69">80</span></td>
</tr>
<tr>
  <td><span class="chart-69">26</span></td>
  <td><span class="chart-69">97</span></td>
  <td><span class="chart-69">70</span></td>
  <td><span class="chart-69">91</span></td>
  <td><span class="chart-69">58</span></td>
  <td><span class="chart-69">76</span></td>
  <td><span class="chart-69">59</span></td>
</tr>
<tr>
  <td><span class="chart-69">06</span></td>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">70</span></td>
  <td><span class="chart-00">38</span></td>
  <td><span class="chart-69">98</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-69">32</span></td>
</tr>
<tr>
  <td><span class="chart-69">92</span></td>
  <td><span class="chart-69">47</span></td>
  <td><span class="chart-69">73</span></td>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">51</span></td>
  <td><span class="chart-69">01</span></td>
  <td><span class="chart-69">34</span></td>
</tr>
<tr>
  <td><span class="chart-69">64</span></td>
  <td><span class="chart-69">54</span></td>
  <td><span class="chart-69">32</span></td>
  <td><span class="chart-69">01</span></td>
  <td><span class="chart-69">63</span></td>
  <td><span class="chart-69">30</span></td>
  <td><span class="chart-69">92</span></td>
</tr>
<tr>
  <td><span class="chart-69">60</span></td>
  <td><span class="chart-69">03</span></td>
  <td><span class="chart-69">54</span></td>
  <td><span class="chart-00">94</span></td>
  <td><span class="chart-69">96</span></td>
  <td><span class="chart-69">76</span></td>
  <td><span class="chart-69">73</span></td>
</tr>
<tr>
  <td><span class="chart-69">04</span></td>
  <td><span class="chart-69">70</span></td>
  <td><span class="chart-00">55</span></td>
  <td><span class="chart-69">25</span></td>
  <td><span class="chart-69">58</span></td>
  <td><span class="chart-69">13</span></td>
  <td><span class="chart-00">72</span></td>
</tr>
<tr>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">91</span></td>
  <td><span class="chart-69">31</span></td>
  <td><span class="chart-69">13</span></td>
  <td><span class="chart-69">14</span></td>
  <td><span class="chart-69">20</span></td>
  <td><span class="chart-69">28</span></td>
</tr>
<tr>
  <td><span class="chart-00">49</span></td>
  <td><span class="chart-69">68</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-00">61</span></td>
  <td><span class="chart-00">27</span></td>
  <td><span class="chart-69">93</span></td>
  <td><span class="chart-69">02</span></td>
</tr>
<tr>
  <td><span class="chart-69">97</span></td>
  <td><span class="chart-00">66</span></td>
  <td><span class="chart-69">80</span></td>
  <td><span class="chart-00">61</span></td>
  <td><span class="chart-69">08</span></td>
  <td><span class="chart-69">21</span></td>
  <td><span class="chart-69">60</span></td>
</tr>
<tr>
  <td><span class="chart-69">97</span></td>
  <td><span class="chart-00">99</span></td>
  <td><span class="chart-69">09</span></td>
  <td><span class="chart-69">20</span></td>
  <td><span class="chart-69">92</span></td>
  <td><span class="chart-69">73</span></td>
  <td><span class="chart-00">99</span></td>
</tr>
<tr>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
  <td><span class="chart-00">**</span></td>
</tr>
<tr>
  <td><span class="chart-69">32</span></td>
  <td><span class="chart-69">06</span></td>
  <td><span class="chart-69">29</span></td>
  <td><span class="chart-69">34</span></td>
  <td><span class="chart-69">40</span></td>
  <td><span class="chart-69">81</span></td>
  <td><span class="chart-69">30</span></td>
</tr>
<tr>
  <td><span class="chart-00">11</span></td>
  <td><span class="chart-69">07</span></td>
  <td><span class="chart-69">96</span></td>
  <td><span class="chart-69">36</span></td>
  <td><span class="chart-00">83</span></td>
  <td><span class="chart-69">20</span></td>
  <td><span class="chart-69">79</span></td>
</tr>
<tr>
  <td><span class="chart-69">51</span></td>
  <td><span class="chart-69">37</span></td>
  <td><span class="chart-69">80</span></td>
  <td><span class="chart-69">71</span></td>
  <td><span class="chart-00">11</span></td>
  <td><span class="chart-69">65</span></td>
  <td><span class="chart-69">25</span></td>
</tr>
<tr>
  <td><span class="chart-69">23</span></td>
  <td><span class="chart-69">52</span></td>
  <td><span class="chart-69">06</span></td>
  <td><span class="chart-69">30</span></td>
  <td><span class="chart-00">88</span></td>
  <td><span class="chart-69">69</span></td>
  <td><span class="chart-69">35</span></td>
</tr>
<tr>
  <td><span class="chart-00">83</span></td>
  <td><span class="chart-69">07</span></td>
  <td><span class="chart-69">37</span></td>
  <td><span class="chart-69">15</span></td>
  <td><span class="chart-00">49</span></td>
  <td><span class="chart-69">81</span></td>
  <td><span class="chart-00">11</span></td>
</tr>
<tr>
  <td><span class="chart-69">80</span></td>
  <td><span class="chart-69">64</span></td>
  <td><span class="chart-69">69</span></td>
  <td><span class="chart-69">79</span></td>
  <td><span class="chart-00">88</span></td>
  <td><span class="chart-69">24</span></td>
  <td><span class="chart-69">15</span></td>
</tr>
</tbody>

<tr><td class=''>80</td><td class=''>64</td><td class=''>35</td><td class=''>92</td><td class=''>35</td><td class='r'>72</td><td class=''>84</td></tr><tr><td class=''>98</td><td class=''>53</td><td class=''>32</td><td class=''>18</td><td class=''>63</td><td class=''>10</td><td class=''>86</td></tr><tr><td class=''>43</td><td class=''>17</td><td class=''>04</td><td class=''>20</td><td class=''>12</td><td class=''>41</td><td class=''>59</td></tr><tr><td class=''>95</td><td class='r'>**</td><td class='r'>77</td><td class=''>24</td><td class='r'>55</td><td class=''>46</td><td class=''>90</td></tr><tr><td class=''>63</td><td class=''>48</td><td class=''>97</td><td class=''>92</td><td class='r'>77</td><td class=''>21</td><td class=''>52</td></tr><tr><td class=''>67</td><td class=''>10</td><td class=''>87</td><td class='r'>66</td><td class=''>31</td><td class='r'>00</td><td class=''>70</td></tr><tr><td class='r'>11</td><td class=''>74</td><td class=''>06</td><td class=''>24</td><td class='r'>99</td><td class=''>60</td><td class='r'>55</td></tr><tr><td class=''>04</td><td class=''>82</td><td class=''>39</td><td class=''>24</td><td class=''>52</td><td class='r'>88</td><td class=''>98</td></tr><tr><td class='r'>66</td><td class=''>74</td><td class=''>47</td><td class='r'>38</td><td class=''>91</td><td class=''>06</td><td class=''>80</td></tr><tr><td class=''>98</td><td class=''>40</td><td class='r'>66</td><td class='r'>16</td><td class=''>39</td><td class='r'>72</td><td class=''>46</td></tr><tr><td class='r'>22</td><td class=''>84</td><td class=''>40</td><td class=''>08</td><td class=''>73</td><td class='r'>99</td><td class=''>39</td></tr><tr><td class=''>86</td><td class=''>87</td><td class='r'>00</td><td class=''>37</td><td class=''>13</td><td class=''>19</td><td class=''>48</td></tr><tr><td class='r'>**</td><td class=''>18</td><td class='r'>66</td><td class=''>59</td><td class='r'>00</td><td class=''>51</td><td class=''>85</td></tr><tr><td class=''>76</td><td class=''>24</td><td class=''>30</td><td class=''>08</td><td class=''>95</td><td class=''>43</td><td class=''>13</td></tr><tr><td class=''>12</td><td class=''>26</td><td class=''>46</td><td class=''>91</td><td class=''>19</td><td class=''>60</td><td class=''>97</td></tr><tr><td class=''>06</td><td class=''>70</td><td class='r'>11</td><td class=''>69</td><td class=''>15</td><td class=''>25</td><td class=''>92</td></tr><tr><td class='r'>77</td><td class=''>23</td><td class=''>30</td><td class=''>19</td><td class=''>02</td><td class=''>56</td><td class=''>13</td></tr><tr><td class=''>69</td><td class=''>56</td><td class='r'>99</td><td class=''>17</td><td class=''>84</td><td class=''>39</td><td class=''>32</td></tr><tr><td class=''>10</td><td class=''>56</td><td class=''>06</td><td class=''>54</td><td class=''>39</td><td class=''>32</td><td class=''>21</td></tr><tr><td class=''>47</td><td class=''>03</td><td class=''>37</td><td class=''>85</td><td class=''>90</td><td class=''>09</td><td class=''>59</td></tr><tr><td class=''>17</td><td class=''>51</td><td class=''>09</td><td class=''>75</td><td class=''>10</td><td class=''>23</td><td class=''>25</td></tr><tr><td class=''>43</td><td class=''>43</td><td class=''>67</td><td class=''>92</td><td class=''>71</td><td class=''>12</td><td class=''>18</td></tr><tr><td class='r'>33</td><td class=''>03</td><td class='r'>50</td><td class=''>41</td><td class=''>51</td><td class=''>84</td><td class=''>76</td></tr><tr><td class='r'>55</td><td class=''>37</td><td class=''>92</td><td class='r'>83</td><td class='r'>33</td><td class=''>29</td><td class=''>40</td></tr><tr><td class=''>52</td><td class=''>52</td><td class=''>79</td><td class=''>40</td><td class=''>81</td><td class=''>74</td><td class=''>19</td></tr><tr><td class=''>60</td><td class=''>64</td><td class=''>40</td><td class=''>60</td><td class='r'>88</td><td class=''>37</td><td class=''>87</td></tr><tr><td class=''>51</td><td class=''>86</td><td class=''>89</td><td class=''>64</td><td class=''>19</td><td class=''>37</td><td class=''>59</td></tr><tr><td class=''>75</td><td class=''>81</td><td class=''>41</td><td class=''>20</td><td class=''>14</td><td class=''>14</td><td class=''>98</td></tr><tr><td class=''>59</td><td class=''>62</td><td class=''>65</td><td class=''>60</td><td class='r'>72</td><td class=''>75</td><td class=''>42</td></tr><tr><td class=''>07</td><td class='r'>00</td><td class='r'>88</td><td class=''>10</td><td class='r'>61</td><td class='r'>72</td><td class=''>25</td></tr><tr><td class='r'>88</td><td class=''>57</td><td class=''>48</td><td class=''>35</td><td class='r'>94</td><td class=''>34</td><td class=''>67</td></tr><tr><td class=''>67</td><td class=''>13</td><td class=''>17</td><td class=''>40</td><td class=''>17</td><td class='r'>00</td><td class='r'>**</td></tr><tr><td class='r'>27</td><td class='r'>77</td><td class=''>30</td><td class='r'>88</td><td class='r'>88</td><td class=''>06</td><td class=''>14</td></tr><tr><td class=''>60</td><td class=''>87</td><td class=''>82</td><td class='r'>00</td><td class=''>91</td><td class=''>98</td><td class=''>48</td></tr><tr><td class=''>19</td><td class='r'>77</td><td class=''>98</td><td class=''>79</td><td class=''>25</td><td class=''>37</td><td class=''>40</td></tr><tr><td class=''>06</td><td class='r'>66</td><td class='r'>49</td><td class='r'>49</td><td class=''>28</td><td class=''>48</td><td class='r'>61</td></tr><tr><td class=''>24</td><td class=''>70</td><td class=''>76</td><td class=''>03</td><td class='r'>05</td><td class='r'>33</td><td class=''>90</td></tr><tr><td class=''>43</td><td class=''>34</td><td class=''>34</td><td class='r'>16</td><td class=''>09</td><td class=''>70</td><td class='r'>72</td></tr><tr><td class=''>19</td><td class=''>51</td><td class=''>82</td><td class=''>95</td><td class=''>93</td><td class=''>26</td><td class=''>37</td></tr><tr><td class=''>98</td><td class=''>30</td><td class=''>51</td><td class=''>76</td><td class=''>71</td><td class=''>65</td><td class=''>69</td></tr><tr><td class=''>06</td><td class=''>20</td><td class=''>41</td><td class=''>79</td><td class=''>10</td><td class=''>90</td><td class=''>78</td></tr><tr><td class=''>90</td><td class=''>97</td><td class=''>97</td><td class=''>45</td><td class=''>58</td><td class=''>68</td><td class=''>21</td></tr><tr><td class=''>78</td><td class=''>04</td><td class=''>95</td><td class=''>97</td><td class=''>21</td><td class=''>87</td><td class=''>64</td></tr><tr><td class=''>13</td><td class=''>68</td><td class=''>12</td><td class=''>80</td><td class=''>29</td><td class=''>28</td><td class=''>69</td></tr><tr><td class=''>07</td><td class=''>80</td><td class=''>74</td><td class=''>48</td><td class=''>41</td><td class=''>46</td><td class=''>86</td></tr><tr><td class=''>40</td><td class=''>36</td><td class=''>75</td><td class=''>35</td><td class=''>12</td><td class=''>48</td><td class=''>30</td></tr><tr><td class=''>80</td><td class=''>32</td><td class=''>02</td><td class='r'>88</td><td class='r'>99</td><td class=''>58</td><td class=''>58</td></tr><tr><td class='r'>66</td><td class=''>01</td><td class=''>64</td><td class=''>45</td><td class=''>46</td><td class='r'>16</td><td class=''>35</td></tr><tr><td class=''>91</td><td class=''>58</td><td class=''>75</td><td class=''>40</td><td class=''>47</td><td class=''>76</td><td class='r'>27</td></tr><tr><td class=''>95</td><td class=''>19</td><td class='r'>94</td><td class=''>73</td><td class='r'>33</td><td class=''>64</td><td class=''>04</td></tr><tr><td class='r'>33</td><td class=''>41</td><td class='r'>11</td><td class='r'>44</td><td class=''>02</td><td class='r'>11</td><td class=''>98</td></tr><tr><td class=''>93</td><td class=''>01</td><td class=''>02</td><td class=''>28</td><td class=''>06</td><td class='r'>11</td><td class=''>56</td></tr><tr><td class='r'>77</td><td class=''>02</td><td class=''>89</td><td class=''>51</td><td class=''>45</td><td class=''>98</td><td class=''>84</td></tr><tr><td class=''>95</td><td class=''>65</td><td class=''>23</td><td class=''>29</td><td class=''>26</td><td class=''>84</td><td class=''>81</td></tr><tr><td class=''>65</td><td class=''>93</td><td class=''>80</td><td class='r'>55</td><td class=''>26</td><td class='r'>05</td><td class=''>29</td></tr><tr><td class=''>80</td><td class='r'>27</td><td class='r'>**</td><td class=''>76</td><td class=''>65</td><td class='r'>72</td><td class=''>76</td></tr><tr><td class=''>95</td><td class=''>48</td><td class='r'>99</td><td class='r'>99</td><td class=''>19</td><td class='r'>88</td><td class=''>31</td></tr><tr><td class=''>01</td><td class=''>68</td><td class=''>63</td><td class='r'>50</td><td class=''>58</td><td class=''>63</td><td class=''>63</td></tr><tr><td class=''>71</td><td class=''>79</td><td class=''>15</td><td class=''>95</td><td class='r'>44</td><td class=''>58</td><td class=''>47</td></tr><tr><td class=''>63</td><td class=''>15</td><td class=''>52</td><td class=''>13</td><td class=''>70</td><td class='r'>72</td><td class=''>23</td></tr><tr><td class='r'>72</td><td class=''>15</td><td class=''>30</td><td class=''>30</td><td class=''>29</td><td class=''>12</td><td class='r'>49</td></tr><tr><td class=''>04</td><td class='r'>88</td><td class='r'>61</td><td class=''>37</td><td class=''>13</td><td class=''>15</td><td class=''>12</td></tr><tr><td class='r'>77</td><td class=''>57</td><td class='r'>55</td><td class=''>98</td><td class='r'>**</td><td class=''>04</td><td class=''>69</td></tr><tr><td class='r'>38</td><td class=''>98</td><td class=''>13</td><td class=''>90</td><td class='r'>05</td><td class=''>32</td><td class='r'>05</td></tr><tr><td class=''>46</td><td class='r'>94</td><td class=''>09</td><td class=''>04</td><td class='r'>77</td><td class=''>42</td><td class=''>67</td></tr><tr><td class=''>36</td><td class=''>18</td><td class=''>14</td><td class=''>75</td><td class=''>79</td><td class=''>84</td><td class=''>70</td></tr><tr><td class=''>58</td><td class=''>51</td><td class=''>46</td><td class=''>34</td><td class=''>91</td><td class=''>10</td><td class=''>76</td></tr><tr><td class=''>79</td><td class=''>79</td><td class=''>26</td><td class='r'>88</td><td class=''>04</td><td class=''>98</td><td class='r'>38</td></tr><tr><td class=''>09</td><td class=''>29</td><td class=''>08</td><td class='r'>61</td><td class=''>74</td><td class=''>71</td><td class=''>03</td></tr><tr><td class='r'>38</td><td class='r'>66</td><td class='r'>22</td><td class=''>20</td><td class=''>21</td><td class=''>40</td><td class=''>84</td></tr><tr><td class=''>78</td><td class=''>41</td><td class=''>98</td><td class=''>20</td><td class=''>81</td><td class=''>03</td><td class=''>08</td></tr><tr><td class=''>03</td><td class=''>60</td><td class=''>79</td><td class=''>15</td><td class=''>21</td><td class=''>68</td><td class=''>62</td></tr><tr><td class=''>69</td><td class=''>97</td><td class=''>47</td><td class=''>39</td><td class=''>59</td><td class=''>18</td><td class=''>47</td></tr><tr><td class=''>06</td><td class=''>04</td><td class=''>06</td><td class='r'>77</td><td class='r'>66</td><td class=''>42</td><td class=''>69</td></tr><tr><td class=''>01</td><td class=''>21</td><td class='r'>72</td><td class=''>59</td><td class=''>59</td><td class=''>01</td><td class=''>45</td></tr><tr><td class='r'>05</td><td class=''>19</td><td class=''>97</td><td class=''>32</td><td class=''>54</td><td class=''>12</td><td class=''>87</td></tr><tr><td class='r'>61</td><td class=''>59</td><td class=''>03</td><td class=''>54</td><td class='r'>72</td><td class=''>26</td><td class=''>17</td></tr><tr><td class=''>32</td><td class=''>25</td><td class='r'>33</td><td class='r'>11</td><td class=''>19</td><td class=''>59</td><td class=''>73</td></tr><tr><td class='r'>88</td><td class=''>95</td><td class=''>64</td><td class=''>64</td><td class=''>73</td><td class='r'>66</td><td class='r'>66</td></tr><tr><td class=''>52</td><td class=''>20</td><td class=''>28</td><td class=''>26</td><td class=''>48</td><td class=''>34</td><td class=''>19</td></tr><tr><td class=''>81</td><td class='r'>49</td><td class='r'>66</td><td class=''>08</td><td class=''>70</td><td class=''>12</td><td class=''>07</td></tr><tr><td class=''>68</td><td class=''>35</td><td class='r'>49</td><td class=''>97</td><td class=''>59</td><td class=''>01</td><td class=''>07</td></tr><tr><td class=''>28</td><td class=''>42</td><td class=''>48</td><td class=''>42</td><td class=''>10</td><td class=''>31</td><td class='r'>83</td></tr><tr><td class=''>28</td><td class=''>62</td><td class=''>51</td><td class=''>71</td><td class=''>18</td><td class=''>52</td><td class=''>06</td></tr><tr><td class='r'>**</td><td class=''>23</td><td class=''>80</td><td class=''>89</td><td class='r'>05</td><td class=''>09</td><td class=''>42</td></tr><tr><td class=''>39</td><td class=''>28</td><td class=''>07</td><td class='r'>44</td><td class=''>80</td><td class=''>81</td><td class=''>85</td></tr><tr><td class=''>17</td><td class='r'>83</td><td class=''>65</td><td class=''>54</td><td class=''>76</td><td class=''>07</td><td class=''>03</td></tr><tr><td class='r'>77</td><td class='r'>77</td><td class=''>13</td><td class='r'>55</td><td class=''>13</td><td class=''>37</td><td class=''>74</td></tr><tr><td class=''>69</td><td class='r'>83</td><td class='r'>38</td><td class=''>47</td><td class=''>84</td><td class=''>04</td><td class=''>75</td></tr><tr><td class=''>04</td><td class=''>17</td><td class=''>87</td><td class=''>19</td><td class=''>60</td><td class=''>63</td><td class=''>59</td></tr><tr><td class='r'>83</td><td class='r'>11</td><td class=''>92</td><td class=''>64</td><td class=''>97</td><td class='r'>88</td><td class=''>56</td></tr><tr><td class=''>35</td><td class=''>03</td><td class=''>07</td><td class='r'>22</td><td class='r'>49</td><td class=''>41</td><td class='r'>49</td></tr><tr><td class='r'>61</td><td class='r'>55</td><td class=''>42</td><td class=''>46</td><td class='r'>61</td><td class=''>23</td><td class=''>24</td></tr><tr><td class=''>78</td><td class=''>53</td><td class=''>53</td><td class=''>58</td><td class=''>96</td><td class=''>24</td><td class=''>02</td></tr><tr><td class=''>39</td><td class='r'>49</td><td class=''>31</td><td class='r'>38</td><td class=''>06</td><td class=''>65</td><td class=''>25</td></tr><tr><td class=''>26</td><td class=''>25</td><td class=''>09</td><td class=''>06</td><td class='r'>77</td><td class=''>67</td><td class=''>68</td></tr><tr><td class=''>59</td><td class=''>87</td><td class=''>92</td><td class=''>82</td><td class=''>28</td><td class=''>67</td><td class='r'>05</td></tr><tr><td class=''>19</td><td class=''>68</td><td class=''>04</td><td class='r'>50</td><td class=''>02</td><td class=''>29</td><td class=''>25</td></tr><tr><td class=''>21</td><td class=''>80</td><td class='r'>11</td><td class='r'>33</td><td class=''>65</td><td class=''>46</td><td class=''>36</td></tr><tr><td class=''>25</td><td class=''>93</td><td class=''>76</td><td class='r'>00</td><td class=''>80</td><td class='r'>44</td><td class=''>65</td></tr><tr><td class=''>53</td><td class=''>31</td><td class=''>39</td><td class=''>41</td><td class=''>32</td><td class=''>40</td><td class=''>62</td></tr><tr><td class='r'>00</td><td class=''>14</td><td class=''>76</td><td class=''>28</td><td class=''>93</td><td class='r'>44</td><td class=''>39</td></tr><tr><td class=''>70</td><td class=''>02</td><td class=''>70</td><td class=''>62</td><td class=''>85</td><td class='r'>83</td><td class=''>43</td></tr><tr><td class='r'>94</td><td class=''>98</td><td class='r'>44</td><td class=''>59</td><td class=''>14</td><td class=''>63</td><td class='r'>16</td></tr><tr><td class='r'>27</td><td class=''>09</td><td class=''>36</td><td class=''>92</td><td class=''>87</td><td class=''>41</td><td class=''>74</td></tr><tr><td class=''>98</td><td class=''>69</td><td class=''>12</td><td class=''>17</td><td class=''>51</td><td class=''>03</td><td class='r'>88</td></tr><tr><td class=''>24</td><td class=''>28</td><td class=''>13</td><td class='r'>44</td><td class='r'>05</td><td class=''>90</td><td class=''>13</td></tr><tr><td class='r'>11</td><td class=''>65</td><td class=''>20</td><td class='r'>**</td><td class='r'>88</td><td class='r'>72</td><td class=''>65</td></tr><tr><td class='r'>05</td><td class=''>84</td><td class=''>62</td><td class='r'>05</td><td class=''>32</td><td class=''>45</td><td class=''>24</td></tr><tr><td class=''>59</td><td class=''>54</td><td class=''>26</td><td class=''>12</td><td class=''>80</td><td class=''>63</td><td class=''>35</td></tr><tr><td class='r'>49</td><td class=''>29</td><td class=''>85</td><td class=''>08</td><td class=''>86</td><td class='r'>38</td><td class=''>19</td></tr><tr><td class=''>67</td><td class=''>65</td><td class=''>52</td><td class='r'>72</td><td class=''>07</td><td class='r'>94</td><td class=''>71</td></tr><tr><td class='r'>49</td><td class=''>68</td><td class='r'>55</td><td class='r'>11</td><td class=''>20</td><td class=''>90</td><td class=''>28</td></tr><tr><td class=''>20</td><td class='r'>**</td><td class='r'>**</td><td class=''>76</td><td class='r'>66</td><td class=''>89</td><td class=''>48</td></tr><tr><td class='r'>00</td><td class=''>39</td><td class='r'>05</td><td class=''>87</td><td class=''>28</td><td class=''>52</td><td class=''>48</td></tr><tr><td class=''>06</td><td class=''>46</td><td class=''>40</td><td class=''>18</td><td class=''>23</td><td class=''>03</td><td class=''>79</td></tr><tr><td class='r'>27</td><td class=''>13</td><td class=''>15</td><td class=''>89</td><td class=''>42</td><td class=''>63</td><td class=''>42</td></tr><tr><td class=''>01</td><td class=''>01</td><td class=''>87</td><td class=''>97</td><td class='r'>55</td><td class='r'>05</td><td class='r'>49</td></tr><tr><td class=''>39</td><td class=''>80</td><td class=''>80</td><td class=''>93</td><td class=''>97</td><td class=''>97</td><td class=''>07</td></tr><tr><td class=''>51</td><td class=''>45</td><td class=''>24</td><td class='r'>11</td><td class=''>40</td><td class='r'>66</td><td class=''>71</td></tr><tr><td class=''>53</td><td class='r'>88</td><td class=''>17</td><td class=''>81</td><td class=''>07</td><td class=''>97</td><td class=''>85</td></tr><tr><td class=''>39</td><td class='r'>88</td><td class=''>21</td><td class=''>01</td><td class=''>40</td><td class=''>69</td><td class=''>41</td></tr><tr><td class='r'>88</td><td class=''>51</td><td class='r'>22</td><td class=''>85</td><td class='r'>72</td><td class=''>28</td><td class=''>86</td></tr><tr><td class=''>58</td><td class=''>40</td><td class=''>45</td><td class=''>85</td><td class='r'>66</td><td class='r'>72</td><td class=''>29</td></tr><tr><td class=''>29</td><td class=''>03</td><td class=''>78</td><td class=''>09</td><td class=''>18</td><td class=''>60</td><td class=''>13</td></tr><tr><td class=''>67</td><td class=''>30</td><td class=''>24</td><td class=''>85</td><td class=''>42</td><td class=''>89</td><td class=''>81</td></tr><tr><td class=''>06</td><td class=''>47</td><td class=''>01</td><td class=''>81</td><td class=''>75</td><td class='r'>33</td><td class=''>65</td></tr><tr><td class=''>69</td><td class=''>98</td><td class=''>75</td><td class=''>41</td><td class=''>78</td><td class=''>29</td><td class=''>26</td></tr><tr><td class=''>48</td><td class='r'>55</td><td class='r'>55</td><td class=''>75</td><td class=''>67</td><td class=''>17</td><td class=''>96</td></tr><tr><td class='r'>83</td><td class=''>08</td><td class=''>84</td><td class=''>24</td><td class=''>23</td><td class=''>25</td><td class=''>95</td></tr><tr><td class='r'>61</td><td class='r'>94</td><td class='r'>61</td><td class=''>04</td><td class=''>32</td><td class='r'>72</td><td class=''>39</td></tr><tr><td class=''>54</td><td class='r'>94</td><td class=''>96</td><td class='r'>16</td><td class=''>96</td><td class=''>37</td><td class=''>58</td></tr><tr><td class=''>89</td><td class='r'>33</td><td class='r'>44</td><td class=''>97</td><td class=''>19</td><td class=''>06</td><td class=''>51</td></tr><tr><td class=''>02</td><td class='r'>77</td><td class=''>76</td><td class=''>95</td><td class='r'>38</td><td class=''>82</td><td class=''>82</td></tr><tr><td class=''>40</td><td class=''>79</td><td class=''>96</td><td class=''>90</td><td class='r'>55</td><td class='r'>99</td><td class=''>35</td></tr><tr><td class=''>17</td><td class=''>70</td><td class=''>71</td><td class=''>17</td><td class=''>93</td><td class=''>59</td><td class=''>79</td></tr><tr><td class='r'>05</td><td class='r'>**</td><td class=''>73</td><td class=''>86</td><td class=''>86</td><td class=''>08</td><td class=''>01</td></tr><tr><td class=''>13</td><td class=''>29</td><td class=''>06</td><td class=''>79</td><td class=''>12</td><td class=''>29</td><td class=''>45</td></tr><tr><td class=''>41</td><td class='r'>83</td><td class=''>70</td><td class=''>35</td><td class=''>58</td><td class=''>46</td><td class='r'>27</td></tr><tr><td class=''>60</td><td class='r'>72</td><td class=''>41</td><td class=''>08</td><td class=''>01</td><td class=''>08</td><td class=''>87</td></tr><tr><td class='r'>99</td><td class=''>92</td><td class=''>82</td><td class=''>04</td><td class=''>71</td><td class='r'>22</td><td class=''>18</td></tr><tr><td class=''>70</td><td class=''>30</td><td class='r'>16</td><td class=''>64</td><td class=''>98</td><td class=''>13</td><td class='r'>66</td></tr><tr><td class=''>08</td><td class='r'>50</td><td class=''>29</td><td class=''>95</td><td class=''>09</td><td class='r'>38</td><td class=''>95</td></tr><tr><td class=''>98</td><td class=''>09</td><td class=''>58</td><td class=''>64</td><td class=''>62</td><td class=''>62</td><td class=''>23</td></tr><tr><td class=''>90</td><td class=''>04</td><td class='r'>49</td><td class='r'>33</td><td class=''>90</td><td class=''>42</td><td class=''>90</td></tr><tr><td class=''>02</td><td class=''>86</td><td class=''>57</td><td class=''>32</td><td class='r'>49</td><td class=''>63</td><td class=''>40</td></tr><tr><td class=''>82</td><td class='r'>77</td><td class=''>03</td><td class=''>06</td><td class='r'>61</td><td class=''>71</td><td class=''>74</td></tr><tr><td class='r'>16</td><td class=''>07</td><td class=''>54</td><td class=''>98</td><td class=''>84</td><td class=''>84</td><td class=''>07</td></tr><tr><td class=''>12</td><td class='r'>77</td><td class=''>71</td><td class=''>84</td><td class=''>19</td><td class=''>78</td><td class=''>34</td></tr><tr><td class=''>14</td><td class=''>85</td><td class=''>80</td><td class=''>25</td><td class=''>97</td><td class=''>30</td><td class=''>34</td></tr><tr><td class=''>02</td><td class=''>21</td><td class=''>06</td><td class=''>32</td><td class=''>90</td><td class=''>29</td><td class=''>96</td></tr><tr><td class='r'>88</td><td class=''>09</td><td class=''>06</td><td class=''>04</td><td class=''>81</td><td class=''>45</td><td class=''>69</td></tr><tr><td class='r'>77</td><td class=''>85</td><td class=''>23</td><td class=''>37</td><td class=''>17</td><td class='r'>05</td><td class=''>67</td></tr><tr><td class=''>09</td><td class=''>93</td><td class='r'>05</td><td class='r'>66</td><td class=''>58</td><td class=''>17</td><td class=''>52</td></tr><tr><td class=''>24</td><td class=''>71</td><td class=''>93</td><td class=''>86</td><td class=''>64</td><td class=''>04</td><td class=''>62</td></tr><tr><td class=''>01</td><td class=''>67</td><td class='r'>44</td><td class=''>03</td><td class=''>02</td><td class=''>41</td><td class=''>08</td></tr><tr><td class=''>69</td><td class='r'>61</td><td class='r'>27</td><td class=''>06</td><td class=''>02</td><td class='r'>61</td><td class='r'>83</td></tr><tr><td class=''>06</td><td class=''>25</td><td class=''>57</td><td class=''>03</td><td class=''>87</td><td class=''>59</td><td class='r'>66</td></tr><tr><td class=''>64</td><td class=''>79</td><td class=''>57</td><td class=''>75</td><td class='r'>38</td><td class=''>80</td><td class=''>82</td></tr><tr><td class=''>69</td><td class=''>21</td><td class='r'>83</td><td class=''>13</td><td class='r'>**</td><td class=''>73</td><td class=''>13</td></tr><tr><td class=''>74</td><td class='r'>00</td><td class=''>89</td><td class=''>79</td><td class=''>17</td><td class=''>14</td><td class=''>58</td></tr><tr><td class='r'>22</td><td class='r'>00</td><td class=''>95</td><td class=''>04</td><td class=''>73</td><td class=''>74</td><td class=''>71</td></tr><tr><td class=''>01</td><td class=''>54</td><td class=''>42</td><td class=''>13</td><td class=''>09</td><td class=''>69</td><td class=''>56</td></tr><tr><td class=''>62</td><td class=''>03</td><td class=''>13</td><td class=''>58</td><td class=''>84</td><td class='r'>49</td><td class=''>98</td></tr><tr><td class=''>28</td><td class='r'>49</td><td class='r'>11</td><td class=''>04</td><td class='r'>50</td><td class=''>70</td><td class=''>84</td></tr><tr><td class=''>63</td><td class=''>71</td><td class=''>19</td><td class=''>89</td><td class=''>86</td><td class=''>68</td><td class=''>54</td></tr><tr><td class=''>70</td><td class='r'>55</td><td class=''>19</td><td class='r'>55</td><td class=''>93</td><td class=''>90</td><td class='r'>66</td></tr><tr><td class='r'>16</td><td class=''>82</td><td class=''>67</td><td class=''>29</td><td class=''>86</td><td class=''>64</td><td class=''>43</td></tr><tr><td class='r'>**</td><td class=''>48</td><td class=''>64</td><td class=''>12</td><td class='r'>88</td><td class=''>74</td><td class=''>19</td></tr><tr><td class=''>73</td><td class='r'>72</td><td class=''>23</td><td class=''>26</td><td class=''>63</td><td class=''>70</td><td class=''>81</td></tr><tr><td class=''>98</td><td class=''>81</td><td class='r'>61</td><td class=''>67</td><td class='r'>00</td><td class=''>52</td><td class=''>56</td></tr><tr><td class=''>52</td><td class=''>04</td><td class=''>63</td><td class=''>87</td><td class=''>42</td><td class=''>76</td><td class=''>89</td></tr><tr><td class='r'>00</td><td class=''>08</td><td class=''>62</td><td class=''>60</td><td class=''>68</td><td class=''>98</td><td class=''>09</td></tr><tr><td class=''>59</td><td class=''>57</td><td class=''>48</td><td class=''>48</td><td class=''>18</td><td class=''>03</td><td class=''>92</td></tr><tr><td class=''>65</td><td class=''>42</td><td class=''>46</td><td class=''>57</td><td class=''>17</td><td class=''>53</td><td class=''>95</td></tr><tr><td class=''>64</td><td class=''>29</td><td class=''>95</td><td class=''>70</td><td class=''>37</td><td class=''>19</td><td class=''>78</td></tr><tr><td class='r'>05</td><td class=''>68</td><td class=''>13</td><td class=''>53</td><td class='r'>05</td><td class=''>13</td><td class='r'>72</td></tr><tr><td class=''>23</td><td class=''>25</td><td class=''>59</td><td class='r'>16</td><td class=''>10</td><td class=''>28</td><td class=''>76</td></tr><tr><td class=''>29</td><td class='r'>16</td><td class=''>73</td><td class=''>15</td><td class=''>51</td><td class=''>19</td><td class=''>32</td></tr><tr><td class=''>24</td><td class=''>01</td><td class=''>02</td><td class=''>29</td><td class=''>48</td><td class=''>84</td><td class=''>47</td></tr><tr><td class=''>51</td><td class=''>08</td><td class=''>32</td><td class=''>01</td><td class=''>45</td><td class=''>42</td><td class=''>45</td></tr><tr><td class=''>12</td><td class=''>18</td><td class=''>28</td><td class=''>23</td><td class=''>73</td><td class=''>76</td><td class=''>84</td></tr><tr><td class=''>51</td><td class='r'>50</td><td class=''>54</td><td class=''>21</td><td class='r'>49</td><td class=''>76</td><td class=''>57</td></tr><tr><td class='r'>77</td><td class='r'>88</td><td class=''>73</td><td class='r'>88</td><td class=''>91</td><td class=''>60</td><td class=''>53</td></tr><tr><td class=''>97</td><td class='r'>00</td><td class=''>81</td><td class=''>69</td><td class=''>97</td><td class=''>57</td><td class=''>71</td></tr><tr><td class=''>51</td><td class=''>53</td><td class=''>09</td><td class='r'>83</td><td class=''>08</td><td class=''>82</td><td class=''>48</td></tr><tr><td class=''>47</td><td class='r'>77</td><td class='r'>55</td><td class=''>63</td><td class=''>62</td><td class=''>85</td><td class=''>59</td></tr><tr><td class=''>13</td><td class=''>59</td><td class=''>14</td><td class=''>62</td><td class=''>60</td><td class=''>87</td><td class=''>06</td></tr><tr><td class=''>84</td><td class=''>08</td><td class=''>24</td><td class='r'>**</td><td class=''>08</td><td class=''>54</td><td class=''>97</td></tr><tr><td class=''>63</td><td class='r'>99</td><td class=''>42</td><td class=''>89</td><td class='r'>50</td><td class='r'>16</td><td class='r'>16</td></tr><tr><td class=''>19</td><td class=''>52</td><td class=''>82</td><td class=''>96</td><td class=''>08</td><td class=''>28</td><td class=''>70</td></tr><tr><td class=''>23</td><td class=''>76</td><td class=''>76</td><td class=''>41</td><td class=''>42</td><td class=''>19</td><td class=''>13</td></tr><tr><td class=''>87</td><td class=''>23</td><td class=''>29</td><td class=''>41</td><td class=''>63</td><td class=''>76</td><td class=''>62</td></tr><tr><td class=''>09</td><td class=''>52</td><td class=''>75</td><td class=''>43</td><td class=''>43</td><td class=''>81</td><td class=''>40</td></tr><tr><td class=''>13</td><td class=''>06</td><td class=''>69</td><td class=''>67</td><td class=''>02</td><td class=''>53</td><td class=''>56</td></tr><tr><td class='r'>88</td><td class=''>43</td><td class=''>60</td><td class='r'>55</td><td class=''>79</td><td class=''>81</td><td class=''>59</td></tr><tr><td class=''>45</td><td class='r'>77</td><td class='r'>11</td><td class=''>59</td><td class=''>21</td><td class=''>29</td><td class='r'>72</td></tr><tr><td class=''>21</td><td class=''>54</td><td class=''>45</td><td class=''>89</td><td class=''>85</td><td class='r'>55</td><td class=''>80</td></tr><tr><td class='r'>38</td><td class=''>69</td><td class='r'>72</td><td class=''>42</td><td class=''>09</td><td class='r'>49</td><td class=''>47</td></tr><tr><td class=''>75</td><td class=''>32</td><td class=''>74</td><td class=''>98</td><td class=''>84</td><td class=''>06</td><td class='r'>83</td></tr><tr><td class=''>74</td><td class=''>81</td><td class='r'>66</td><td class='r'>66</td><td class=''>70</td><td class=''>02</td><td class=''>63</td></tr><tr><td class=''>09</td><td class=''>82</td><td class=''>69</td><td class='r'>88</td><td class='r'>66</td><td class=''>19</td><td class='r'>49</td></tr><tr><td class=''>78</td><td class='r'>16</td><td class=''>03</td><td class=''>95</td><td class=''>40</td><td class=''>29</td><td class=''>65</td></tr><tr><td class=''>18</td><td class=''>96</td><td class=''>21</td><td class=''>41</td><td class=''>28</td><td class=''>23</td><td class=''>53</td></tr><tr><td class='r'>55</td><td class=''>26</td><td class=''>29</td><td class=''>08</td><td class='r'>38</td><td class=''>23</td><td class=''>96</td></tr><tr><td class=''>48</td><td class=''>08</td><td class='r'>50</td><td class=''>52</td><td class=''>81</td><td class=''>08</td><td class=''>76</td></tr><tr><td class='r'>11</td><td class=''>04</td><td class=''>81</td><td class='r'>22</td><td class=''>37</td><td class=''>98</td><td class=''>26</td></tr><tr><td class=''>15</td><td class='r'>88</td><td class=''>26</td><td class=''>86</td><td class=''>26</td><td class=''>58</td><td class=''>54</td></tr><tr><td class=''>04</td><td class=''>57</td><td class=''>57</td><td class=''>64</td><td class=''>96</td><td class=''>93</td><td class=''>96</td></tr><tr><td class=''>70</td><td class=''>89</td><td class=''>81</td><td class=''>29</td><td class=''>54</td><td class=''>26</td><td class=''>17</td></tr><tr><td class=''>65</td><td class=''>97</td><td class=''>98</td><td class=''>81</td><td class=''>97</td><td class=''>87</td><td class=''>35</td></tr><tr><td class=''>93</td><td class=''>18</td><td class=''>63</td><td class=''>56</td><td class=''>30</td><td class=''>34</td><td class='r'>**</td></tr><tr><td class=''>59</td><td class=''>29</td><td class=''>23</td><td class=''>29</td><td class=''>87</td><td class='r'>49</td><td class=''>80</td></tr><tr><td class=''>97</td><td class=''>96</td><td class='r'>16</td><td class='r'>61</td><td class=''>12</td><td class='r'>61</td><td class=''>28</td></tr><tr><td class='r'>94</td><td class='r'>22</td><td class=''>70</td><td class=''>23</td><td class=''>76</td><td class=''>57</td><td class=''>01</td></tr><tr><td class='r'>61</td><td class=''>63</td><td class=''>53</td><td class=''>04</td><td class='r'>72</td><td class='r'>55</td><td class=''>97</td></tr><tr><td class=''>80</td><td class=''>78</td><td class=''>34</td><td class=''>39</td><td class=''>21</td><td class=''>70</td><td class=''>34</td></tr><tr><td class='r'>77</td><td class=''>04</td><td class=''>04</td><td class=''>06</td><td class=''>89</td><td class=''>28</td><td class='r'>83</td></tr><tr><td class=''>71</td><td class=''>62</td><td class=''>84</td><td class=''>90</td><td class='r'>**</td><td class=''>02</td><td class=''>28</td></tr><tr><td class=''>58</td><td class=''>60</td><td class='r'>99</td><td class='r'>77</td><td class=''>91</td><td class=''>95</td><td class=''>60</td></tr><tr><td class=''>42</td><td class=''>62</td><td class=''>98</td><td class=''>35</td><td class=''>32</td><td class=''>48</td><td class=''>14</td></tr><tr><td class=''>14</td><td class=''>67</td><td class=''>14</td><td class=''>14</td><td class=''>08</td><td class='r'>50</td><td class=''>37</td></tr><tr><td class='r'>99</td><td class=''>17</td><td class=''>51</td><td class=''>85</td><td class=''>56</td><td class=''>53</td><td class=''>97</td></tr><tr><td class=''>17</td><td class='r'>05</td><td class=''>59</td><td class=''>54</td><td class='r'>11</td><td class=''>17</td><td class=''>79</td></tr><tr><td class='r'>44</td><td class=''>90</td><td class='r'>49</td><td class=''>98</td><td class=''>29</td><td class=''>78</td><td class=''>92</td></tr><tr><td class=''>47</td><td class=''>26</td><td class=''>01</td><td class=''>70</td><td class='r'>99</td><td class='r'>11</td><td class=''>62</td></tr><tr><td class=''>68</td><td class='r'>27</td><td class=''>26</td><td class='r'>99</td><td class=''>84</td><td class=''>91</td><td class=''>65</td></tr><tr><td class=''>68</td><td class=''>56</td><td class=''>58</td><td class=''>28</td><td class=''>65</td><td class=''>45</td><td class=''>29</td></tr><tr><td class='r'>88</td><td class=''>30</td><td class=''>08</td><td class=''>03</td><td class='r'>38</td><td class=''>43</td><td class=''>59</td></tr><tr><td class=''>67</td><td class=''>96</td><td class=''>59</td><td class=''>30</td><td class=''>40</td><td class='r'>88</td><td class=''>57</td></tr><tr><td class=''>63</td><td class=''>58</td><td class=''>23</td><td class=''>71</td><td class=''>96</td><td class=''>43</td><td class=''>84</td></tr><tr><td class=''>29</td><td class=''>51</td><td class='r'>83</td><td class=''>75</td><td class=''>39</td><td class=''>51</td><td class=''>31</td></tr><tr><td class=''>90</td><td class=''>46</td><td class=''>96</td><td class=''>12</td><td class=''>42</td><td class=''>51</td><td class=''>90</td></tr><tr><td class=''>79</td><td class=''>90</td><td class='r'>77</td><td class=''>84</td><td class=''>70</td><td class=''>70</td><td class=''>87</td></tr><tr><td class=''>62</td><td class='r'>83</td><td class=''>70</td><td class=''>79</td><td class='r'>55</td><td class=''>14</td><td class=''>84</td></tr><tr><td class=''>75</td><td class='r'>77</td><td class=''>57</td><td class=''>84</td><td class=''>19</td><td class=''>67</td><td class=''>46</td></tr><tr><td class='r'>11</td><td class=''>51</td><td class=''>35</td><td class=''>59</td><td class=''>56</td><td class=''>32</td><td class=''>93</td></tr><tr><td class=''>45</td><td class=''>21</td><td class='r'>99</td><td class=''>37</td><td class=''>82</td><td class=''>32</td><td class=''>36</td></tr><tr><td class=''>04</td><td class=''>97</td><td class=''>82</td><td class=''>89</td><td class=''>70</td><td class=''>79</td><td class=''>74</td></tr><tr><td class=''>95</td><td class=''>90</td><td class=''>53</td><td class=''>60</td><td class=''>85</td><td class=''>45</td><td class=''>71</td></tr><tr><td class=''>35</td><td class=''>17</td><td class=''>67</td><td class='r'>49</td><td class='r'>**</td><td class=''>92</td><td class=''>60</td></tr><tr><td class=''>65</td><td class=''>63</td><td class=''>07</td><td class=''>75</td><td class=''>04</td><td class=''>60</td><td class='r'>94</td></tr><tr><td class=''>30</td><td class=''>20</td><td class=''>26</td><td class=''>86</td><td class=''>20</td><td class='r'>33</td><td class=''>37</td></tr><tr><td class='r'>88</td><td class=''>62</td><td class='r'>00</td><td class='r'>94</td><td class=''>47</td><td class=''>71</td><td class=''>43</td></tr><tr><td class=''>24</td><td class=''>42</td><td class='r'>49</td><td class=''>97</td><td class='r'>50</td><td class=''>93</td><td class=''>75</td></tr><tr><td class=''>93</td><td class='r'>00</td><td class=''>46</td><td class='r'>72</td><td class=''>51</td><td class=''>95</td><td class=''>52</td></tr><tr><td class=''>73</td><td class=''>74</td><td class=''>86</td><td class=''>74</td><td class=''>43</td><td class=''>01</td><td class=''>81</td></tr><tr><td class='r'>88</td><td class=''>74</td><td class=''>80</td><td class='r'>27</td><td class=''>81</td><td class=''>75</td><td class=''>45</td></tr><tr><td class=''>37</td><td class='r'>94</td><td class=''>02</td><td class=''>51</td><td class=''>07</td><td class='r'>38</td><td class=''>97</td></tr><tr><td class=''>54</td><td class='r'>38</td><td class=''>39</td><td class=''>91</td><td class=''>87</td><td class=''>60</td><td class=''>23</td></tr><tr><td class='r'>38</td><td class=''>71</td><td class=''>78</td><td class=''>73</td><td class=''>86</td><td class='r'>61</td><td class=''>84</td></tr><tr><td class=''>85</td><td class='r'>33</td><td class=''>17</td><td class=''>42</td><td class='r'>99</td><td class='r'>49</td><td class=''>68</td></tr><tr><td class='r'>99</td><td class='r'>22</td><td class=''>47</td><td class=''>39</td><td class=''>31</td><td class=''>91</td><td class=''>12</td></tr><tr><td class=''>87</td><td class='r'>22</td><td class=''>21</td><td class=''>17</td><td class='r'>77</td><td class=''>91</td><td class='r'>72</td></tr><tr><td class=''>81</td><td class=''>47</td><td class=''>45</td><td class=''>42</td><td class=''>35</td><td class=''>81</td><td class=''>89</td></tr><tr><td class='r'>22</td><td class=''>01</td><td class='r'>50</td><td class='r'>22</td><td class=''>59</td><td class=''>78</td><td class=''>52</td></tr><tr><td class=''>79</td><td class='r'>11</td><td class='r'>22</td><td class=''>19</td><td class=''>84</td><td class=''>30</td><td class=''>14</td></tr><tr><td class=''>30</td><td class=''>79</td><td class=''>34</td><td class=''>13</td><td class=''>46</td><td class=''>04</td><td class=''>92</td></tr><tr><td class=''>08</td><td class=''>37</td><td class=''>40</td><td class=''>60</td><td class=''>37</td><td class=''>47</td><td class=''>98</td></tr><tr><td class='r'>05</td><td class='r'>83</td><td class=''>09</td><td class=''>28</td><td class='r'>66</td><td class=''>23</td><td class=''>62</td></tr><tr><td class=''>09</td><td class=''>92</td><td class='r'>83</td><td class=''>14</td><td class='r'>00</td><td class=''>78</td><td class=''>89</td></tr><tr><td class=''>89</td><td class='r'>66</td><td class=''>08</td><td class=''>67</td><td class=''>70</td><td class=''>46</td><td class=''>85</td></tr><tr><td class=''>31</td><td class=''>60</td><td class=''>48</td><td class=''>01</td><td class=''>48</td><td class=''>30</td><td class=''>57</td></tr><tr><td class=''>71</td><td class=''>45</td><td class='r'>11</td><td class='r'>61</td><td class='r'>61</td><td class=''>43</td><td class=''>48</td></tr><tr><td class='r'>**</td><td class=''>85</td><td class=''>36</td><td class=''>43</td><td class=''>45</td><td class=''>90</td><td class=''>96</td></tr><tr><td class='r'>88</td><td class=''>45</td><td class='r'>66</td><td class=''>90</td><td class=''>41</td><td class='r'>83</td><td class=''>63</td></tr><tr><td class=''>63</td><td class=''>14</td><td class=''>73</td><td class=''>21</td><td class=''>91</td><td class=''>21</td><td class=''>58</td></tr><tr><td class=''>74</td><td class=''>07</td><td class=''>09</td><td class=''>25</td><td class=''>92</td><td class=''>87</td><td class=''>42</td></tr><tr><td class='r'>72</td><td class=''>13</td><td class=''>04</td><td class=''>58</td><td class='r'>99</td><td class=''>07</td><td class=''>56</td></tr><tr><td class='r'>49</td><td class=''>84</td><td class='r'>**</td><td class=''>65</td><td class=''>14</td><td class=''>62</td><td class=''>42</td></tr><tr><td class=''>60</td><td class=''>90</td><td class=''>89</td><td class=''>24</td><td class='r'>88</td><td class=''>89</td><td class=''>62</td></tr>                	</table>
                	
                
                </div>
            </div>
        </div>

    </div>

<div class="chart-result">    
		<div>SRIDEVI</div>
		<span>150-62-390</span><br>
		<a href="sridevi.php">Refresh Result</a>
</div>
	
<div class="container-fluid footer-text-div">
<p>It is quite natural that the best betting website can differ based on individual preferences and geographic location. Additionally, the online betting landscape is dynamic, with new websites emerging and existing ones changing. What may be considered the best for one person might not be the same for another. However, when it comes to DPBoss Services, almost all gamblers on the earth will usually prefer this betting platform not only to play Sridevi but also other Satta Matka games. </p>
<br>
<div class="small-heading">Get Sridevi Jodi Chart Records</div>
<p>When you consider DPBoss Services to play the Sridevi game, you do not need to search for other analogous sites online. Most reputable sources on the earth suggest gamblers choose this Satta Matka website to play not only the Sridevi game but also all other types of Satta Matka games. Whatever variations you need to play your favorite Satta Matka game, you will be capable of finding it easily and quickly on DPBoss Services. Moreover, the only Satta Matka website that has tons of positive feedback and customer reviews is DPBoss Services. Thus, you can rest assured that the website can meet your specific needs, criteria for security, game diversity, bonuses, and customer backing.</p>
<br>
<div class="faq-heading">Frequently Asked Questions (FAQs):</div>
<p class="faq-title">Q1. Can I Play my Sridevi game on DPBoss Services from any part of the world?</p>
<p class="faq-ans">Yes, you can because DPBoss Services provides its website users with the convenience to play not only their Sridevi game but also other Satta Matka games from anywhere on earth.</p>
<p class="faq-title">Q2. Why most gamplaers prefer DPBoss Services?</p>
<p class="faq-ans">It is because the website it meets the entire playing needs of both novice players as well as veteran gamblers.</p>
</div><br><br>	
<center>
	<div id="bottom"></div>
	<a href="#top" class="button2"> Go to Top </a>
</center>
<p>
145</p>
	
	
<!-- adv & links -->
<!-- footer -->
<footer style="font-style: normal;">

  
  <a class="ftr-icon" href="https://dpboss.boston">dpboss.boston</a>
  <p>
    All Rights Reseved®
    <br>
    (1998-2024)
    <br>
    Contact (Astrologer-<span>Dpboss</span>)
  </p>
</footer>

<!--<a class="mp-btn" href="https://dpboss.boston/dpbossplay-matka-online.php"><i>Matka Play</i></a> -->
<a class="mp-btn" href="https://matkabank.mobi/"><i>Matka Play</i></a>

 



</body>
</html>